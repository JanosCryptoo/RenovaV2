-- Run after 01_schema.sql in your own Supabase project (SQL editor).
-- Private buckets; files are served by the site's /api/public/media route.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('furniture-images','furniture-images', false, 8388608, array['image/jpeg','image/png','image/webp']),
  ('furniture-models','furniture-models', false, 20971520, array['model/gltf-binary','application/octet-stream'])
on conflict (id) do nothing;

-- Make yourself admin: add your email, sign up on /admin, confirm the email, sign in.
-- insert into public.admin_invites (email) values ('you@example.com');
