<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules (RENOVA UF)

- Visual design lives in plain CSS classes in `src/styles/renova.css`, `three.css`, `admin.css` (ported from the original site); extend those files rather than adding Tailwind utility styling to components — keeps the editorial look in one place.
- Three.js / React Three Fiber code loads only via `src/components/three/LazyScenes.tsx` (lazy + ClientOnly) — WebGL modules must never run during SSR.
- Media buckets are private; files are served by `/api/public/media/$bucket/$` and stored as app-relative URLs — the workspace blocks public buckets.
- Uploads go only through the `uploadAsset` server function, which re-checks the admin role and file bytes with `src/lib/asset-validation.ts` — browser checks are advisory.
- Prices and stock are authoritative in the database RPCs (`reserve_order`, `apply_checkout_event`, `release_unattached_order`), called only with the service role — the browser never sends prices.
- Admin access = `user_roles` row, granted by `claim_admin_invite()` for verified emails listed in `admin_invites` — users can never grant themselves roles.
- Checkout and contact stay disabled until `checkoutReady`/`contactReady` in `src/lib/shop-rules.ts` pass (explicit enable flag, live-key approval, webhook + Turnstile keys) — keeps the store from taking payments before setup.
- Payment credentials are entered on the admin "Betalningar" tab and stored AES-GCM-encrypted (key: `PAYMENT_SETTINGS_KEY`) in `payment_settings`, which has no browser grants; `readEnv()` merges them over project secrets — rotating that secret makes saved keys unreadable, so admins must re-enter them.
- Scroll/3D motion: chair assembly is driven by an `explode` ref read in `useFrame` (no React state per frame); `WordReveal` observes the unclipped line, never the masked words — masked words never intersect.
- Team-supplied photos and videos are plain files in `public/media/`, listed in `src/lib/team.ts` / `src/lib/workshop.ts`; videos are re-encoded to silent H.264 MP4 — the site is self-hosted on Cloudflare, where Lovable asset URLs do not resolve, and MOV/HEVC does not play everywhere.
