-- RENOVA UF schema, ported from the original Supabase migrations.
-- Monetary values are integer öre. No sample products or customer data.

-- Roles ---------------------------------------------------------------
create type public.app_role as enum ('admin');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "Users read own roles" on public.user_roles for select to authenticated
  using (user_id = (select auth.uid()));

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.user_roles where user_id = _user_id and role = _role) $$;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select auth.uid() is not null and public.has_role(auth.uid(), 'admin') $$;

revoke all on function public.has_role(uuid, public.app_role) from public;
revoke all on function public.is_admin() from public;
grant execute on function public.has_role(uuid, public.app_role) to anon, authenticated, service_role;
grant execute on function public.is_admin() to anon, authenticated, service_role;

create table public.admin_invites (
  email text primary key check (email = lower(email) and char_length(email) between 3 and 254),
  created_at timestamptz not null default now()
);
grant all on public.admin_invites to service_role;
alter table public.admin_invites enable row level security;

create or replace function public.claim_admin_invite()
returns boolean language plpgsql security definer set search_path = public
as $$
declare v_email text; v_confirmed timestamptz;
begin
  if auth.uid() is null then return false; end if;
  select lower(u.email), u.email_confirmed_at into v_email, v_confirmed from auth.users u where u.id = auth.uid();
  if v_email is null or v_confirmed is null then return public.has_role(auth.uid(), 'admin'); end if;
  if exists (select 1 from public.admin_invites i where i.email = v_email) then
    insert into public.user_roles (user_id, role) values (auth.uid(), 'admin') on conflict do nothing;
  end if;
  return public.has_role(auth.uid(), 'admin');
end; $$;
revoke all on function public.claim_admin_invite() from public, anon;
grant execute on function public.claim_admin_invite() to authenticated;

create table public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 120),
  description text not null default '' check (char_length(description) <= 8000),
  price integer not null check (price between 100 and 10000000),
  category text not null check (char_length(category) between 1 and 80),
  condition text not null default '' check (char_length(condition) <= 2000),
  dimensions text not null default '' check (char_length(dimensions) <= 200),
  stock integer not null default 1 check (stock between 0 and 100),
  availability text not null default 'available' check (availability in ('available','reserved','sold')),
  published boolean not null default false,
  featured boolean not null default false,
  model_url text constraint products_model_url_check check (model_url is null or model_url ~ '^(https://|/api/public/media/furniture-models/)'),
  created_at timestamptz not null default now(),
  check ((availability = 'available' and stock > 0) or (availability in ('reserved','sold') and stock = 0))
);
create index products_public_category_idx on public.products(category, created_at desc) where published;
create index products_public_featured_idx on public.products(created_at desc) where published and featured;

create table public.product_images (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  image_url text not null constraint product_images_image_url_check check (image_url ~ '^(https://|/api/public/media/furniture-images/)'),
  sort_order integer not null default 0 check (sort_order between 0 and 1000)
);
create index product_images_product_idx on public.product_images(product_id, sort_order);

create table public.restorations (
  id uuid primary key default gen_random_uuid(),
  product_id uuid references public.products(id) on delete set null,
  title text not null check (char_length(title) between 2 and 160),
  description text not null default '' check (char_length(description) <= 4000),
  before_image_url text not null constraint restorations_before_image_url_check check (before_image_url ~ '^(https://|/api/public/media/furniture-images/)'),
  after_image_url text not null constraint restorations_after_image_url_check check (after_image_url ~ '^(https://|/api/public/media/furniture-images/)'),
  published boolean not null default false,
  created_at timestamptz not null default now()
);
create index restorations_product_idx on public.restorations(product_id);

create table public.company_images (
  id uuid primary key default gen_random_uuid(),
  image_url text not null constraint company_images_image_url_check check (image_url ~ '^(https://|/api/public/media/furniture-images/)'),
  alt text not null check (char_length(alt) between 2 and 250),
  sort_order integer not null default 0,
  published boolean not null default false
);

create table public.orders (
  id uuid primary key,
  customer_name text not null check (char_length(customer_name) between 2 and 120),
  customer_email text not null check (char_length(customer_email) between 3 and 254),
  total integer not null default 0 check (total between 0 and 100000000),
  currency text not null default 'sek' check (currency = 'sek'),
  status text not null default 'creating' check (status in ('creating','reserved','payment_pending','paid','expired','failed','cancelled')),
  request_fingerprint text not null check (char_length(request_fingerprint) = 64),
  stripe_session_id text unique,
  payment_reference text unique,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index orders_active_idx on public.orders(created_at) where status in ('creating','reserved','payment_pending');

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete restrict,
  product_id uuid not null references public.products(id) on delete restrict,
  name text not null,
  quantity integer not null check (quantity between 1 and 10),
  price integer not null check (price > 0),
  unique(order_id, product_id)
);
create index order_items_product_idx on public.order_items(product_id);

create table public.payment_events (
  event_id text primary key,
  order_id uuid not null references public.orders(id),
  action text not null,
  created_at timestamptz not null default now()
);
create index payment_events_order_idx on public.payment_events(order_id);

create table public.contact_messages (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 120),
  email text not null check (char_length(email) between 3 and 254),
  message text not null check (char_length(message) between 10 and 4000),
  product_id uuid references public.products(id) on delete set null,
  created_at timestamptz not null default now()
);
create index contact_messages_product_idx on public.contact_messages(product_id);
create index contact_messages_created_idx on public.contact_messages(created_at desc);

revoke all on public.products, public.product_images, public.restorations, public.company_images,
  public.orders, public.order_items, public.payment_events, public.contact_messages from anon, authenticated;
grant select on public.products, public.product_images, public.restorations, public.company_images to anon, authenticated;
grant insert, update, delete on public.products, public.product_images, public.restorations, public.company_images to authenticated;
grant select on public.orders, public.order_items, public.contact_messages to authenticated;
grant all on public.products, public.product_images, public.restorations, public.company_images,
  public.orders, public.order_items, public.payment_events, public.contact_messages to service_role;

alter table public.products enable row level security;
alter table public.product_images enable row level security;
alter table public.restorations enable row level security;
alter table public.company_images enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.payment_events enable row level security;
alter table public.contact_messages enable row level security;

create policy published_products on public.products for select to anon, authenticated
  using (published or (select public.is_admin()));
create policy admin_products_insert on public.products for insert to authenticated
  with check ((select public.is_admin()));
create policy admin_products_update on public.products for update to authenticated
  using ((select public.is_admin())) with check ((select public.is_admin()));
create policy admin_products_delete on public.products for delete to authenticated
  using ((select public.is_admin()));

create policy published_product_images on public.product_images for select to anon, authenticated
  using (exists(select 1 from public.products p where p.id = product_id and p.published) or (select public.is_admin()));
create policy admin_product_images_insert on public.product_images for insert to authenticated
  with check ((select public.is_admin()));
create policy admin_product_images_update on public.product_images for update to authenticated
  using ((select public.is_admin())) with check ((select public.is_admin()));
create policy admin_product_images_delete on public.product_images for delete to authenticated
  using ((select public.is_admin()));

create policy published_restorations on public.restorations for select to anon, authenticated
  using (published or (select public.is_admin()));
create policy admin_restorations_insert on public.restorations for insert to authenticated
  with check ((select public.is_admin()));
create policy admin_restorations_update on public.restorations for update to authenticated
  using ((select public.is_admin())) with check ((select public.is_admin()));
create policy admin_restorations_delete on public.restorations for delete to authenticated
  using ((select public.is_admin()));

create policy published_company_images on public.company_images for select to anon, authenticated
  using (published or (select public.is_admin()));
create policy admin_company_images_insert on public.company_images for insert to authenticated
  with check ((select public.is_admin()));
create policy admin_company_images_update on public.company_images for update to authenticated
  using ((select public.is_admin())) with check ((select public.is_admin()));
create policy admin_company_images_delete on public.company_images for delete to authenticated
  using ((select public.is_admin()));

create policy admin_orders_read on public.orders for select to authenticated using ((select public.is_admin()));
create policy admin_order_items_read on public.order_items for select to authenticated using ((select public.is_admin()));
create policy admin_contacts_read on public.contact_messages for select to authenticated using ((select public.is_admin()));

create function public.order_json(p_id uuid) returns jsonb
language sql stable security invoker set search_path = '' as $$
  select jsonb_build_object('id',o.id,'total',o.total,'status',o.status,'created_at',o.created_at,
    'stripe_session_id',o.stripe_session_id,'customer_email',o.customer_email,
    'items',coalesce((select jsonb_agg(jsonb_build_object('product_id',i.product_id,'name',i.name,
      'price',i.price,'quantity',i.quantity) order by i.product_id) from public.order_items i where i.order_id=o.id),'[]'::jsonb))
  from public.orders o where o.id=p_id;
$$;

create function public.reserve_order(p_order_id uuid, p_items jsonb, p_customer_name text,
  p_customer_email text, p_fingerprint text) returns jsonb
language plpgsql security invoker set search_path = '' as $$
declare inserted_count integer; current_order public.orders%rowtype; item jsonb;
  product public.products%rowtype; qty integer; computed_total bigint := 0;
begin
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) not between 1 and 10 then
    raise exception 'INVALID_ITEMS';
  end if;
  if (select count(distinct value->>'productId') from jsonb_array_elements(p_items)) <> jsonb_array_length(p_items) then
    raise exception 'DUPLICATE_ITEMS';
  end if;
  insert into public.orders(id,customer_name,customer_email,request_fingerprint)
    values(p_order_id,p_customer_name,p_customer_email,p_fingerprint) on conflict(id) do nothing;
  get diagnostics inserted_count = row_count;
  select * into strict current_order from public.orders where id=p_order_id for update;
  if current_order.request_fingerprint <> p_fingerprint then raise exception 'REQUEST_CONFLICT'; end if;
  if inserted_count=0 then return public.order_json(p_order_id); end if;
  for item in select value from jsonb_array_elements(p_items) order by value->>'productId' loop
    if (item->>'quantity') !~ '^[0-9]+$' then raise exception 'INVALID_QUANTITY'; end if;
    qty := (item->>'quantity')::integer;
    if qty not between 1 and 10 then raise exception 'INVALID_QUANTITY'; end if;
    select * into product from public.products where id=(item->>'productId')::uuid for update;
    if not found or not product.published or product.availability <> 'available' or product.stock < qty then
      raise exception 'OUT_OF_STOCK';
    end if;
    insert into public.order_items(order_id,product_id,name,quantity,price)
      values(p_order_id,product.id,product.name,qty,product.price);
    computed_total := computed_total + product.price::bigint * qty;
    if computed_total > 100000000 then raise exception 'TOTAL_TOO_LARGE'; end if;
    update public.products set stock=stock-qty,
      availability=case when stock-qty=0 then 'reserved' else 'available' end where id=product.id;
  end loop;
  update public.orders set total=computed_total::integer where id=p_order_id;
  return public.order_json(p_order_id);
end; $$;

create function public.attach_checkout_session(p_order_id uuid, p_session_id text) returns void
language plpgsql security invoker set search_path = '' as $$
declare current_order public.orders%rowtype;
begin
  select * into strict current_order from public.orders where id=p_order_id for update;
  if current_order.stripe_session_id is not null and current_order.stripe_session_id <> p_session_id then
    raise exception 'SESSION_CONFLICT';
  end if;
  update public.orders set stripe_session_id=p_session_id,
    status=case when status='creating' then 'reserved' else status end, updated_at=now() where id=p_order_id;
end; $$;

create function public.apply_checkout_event(p_event_id text, p_order_id uuid, p_session_id text,
  p_action text, p_total integer, p_currency text, p_payment_reference text) returns void
language plpgsql security invoker set search_path = '' as $$
declare current_order public.orders%rowtype; item record; inserted_count integer;
begin
  if p_action not in ('paid','pending','expired','failed') then raise exception 'INVALID_ACTION'; end if;
  select * into strict current_order from public.orders where id=p_order_id for update;
  if current_order.stripe_session_id is not null and current_order.stripe_session_id <> p_session_id then
    raise exception 'SESSION_CONFLICT';
  end if;
  if p_total is distinct from current_order.total or p_currency is distinct from 'sek' then raise exception 'AMOUNT_MISMATCH'; end if;
  insert into public.payment_events(event_id,order_id,action) values(p_event_id,p_order_id,p_action) on conflict(event_id) do nothing;
  get diagnostics inserted_count = row_count;
  if inserted_count=0 then return; end if;
  update public.orders set stripe_session_id=p_session_id,updated_at=now() where id=p_order_id;
  if current_order.status='paid' then return; end if;
  if current_order.status in ('expired','failed','cancelled') then
    if p_action='paid' then raise exception 'LATE_PAYMENT_REQUIRES_REVIEW'; end if;
    return;
  end if;
  if p_action='pending' then
    update public.orders set status='payment_pending' where id=p_order_id;
    return;
  end if;
  if p_action='expired' and current_order.status='payment_pending' then return; end if;
  update public.orders set status=case when p_action='paid' then 'paid' else p_action end,
    payment_reference=case when p_action='paid' then p_payment_reference else payment_reference end where id=p_order_id;
  for item in select i.product_id,i.quantity from public.order_items i where i.order_id=p_order_id order by i.product_id loop
    perform 1 from public.products where id=item.product_id for update;
    if p_action in ('expired','failed') then
      update public.products set stock=stock+item.quantity,availability='available' where id=item.product_id;
    else
      update public.products p set availability=case when p.stock>0 then 'available'
        when exists(select 1 from public.order_items oi join public.orders o on o.id=oi.order_id
          where oi.product_id=p.id and o.status in ('creating','reserved','payment_pending')) then 'reserved'
        else 'sold' end where p.id=item.product_id;
    end if;
  end loop;
end; $$;

create function public.release_unattached_order(p_order_id uuid) returns void
language plpgsql security invoker set search_path = '' as $$
declare current_order public.orders%rowtype; item record;
begin
  select * into strict current_order from public.orders where id=p_order_id for update;
  if current_order.status='cancelled' then return; end if;
  if current_order.status <> 'creating' or current_order.stripe_session_id is not null
    or current_order.created_at > now() - interval '45 minutes' then raise exception 'UNSAFE_RELEASE'; end if;
  update public.orders set status='cancelled',updated_at=now() where id=p_order_id;
  for item in select product_id,quantity from public.order_items where order_id=p_order_id order by product_id loop
    perform 1 from public.products where id=item.product_id for update;
    update public.products set stock=stock+item.quantity,availability='available' where id=item.product_id;
  end loop;
end; $$;

create function public.protect_reserved_product() returns trigger
language plpgsql security invoker set search_path = '' as $$
begin
  if current_user = 'service_role' then
    if tg_op='DELETE' then return old; else return new; end if;
  end if;
  if tg_op='DELETE' or new.stock is distinct from old.stock or new.price is distinct from old.price
    or new.availability is distinct from old.availability then
    if exists(select 1 from public.order_items i join public.orders o on o.id=i.order_id
      where i.product_id=old.id and o.status in ('creating','reserved','payment_pending')) then
      raise exception 'ACTIVE_RESERVATION: Avsluta betalningen innan lagret ändras.';
    end if;
  end if;
  if tg_op='DELETE' then return old; else return new; end if;
end; $$;
create trigger protect_reserved_product before update or delete on public.products
  for each row execute function public.protect_reserved_product();

revoke all on function public.order_json(uuid) from public, anon, authenticated;
revoke all on function public.reserve_order(uuid,jsonb,text,text,text) from public, anon, authenticated;
revoke all on function public.attach_checkout_session(uuid,text) from public, anon, authenticated;
revoke all on function public.apply_checkout_event(text,uuid,text,text,integer,text,text) from public, anon, authenticated;
revoke all on function public.release_unattached_order(uuid) from public, anon, authenticated;
revoke all on function public.protect_reserved_product() from public, anon;
grant execute on function public.order_json(uuid) to service_role;
grant execute on function public.reserve_order(uuid,jsonb,text,text,text) to service_role;
grant execute on function public.attach_checkout_session(uuid,text) to service_role;
grant execute on function public.apply_checkout_event(text,uuid,text,text,integer,text,text) to service_role;
grant execute on function public.release_unattached_order(uuid) to service_role;
grant execute on function public.protect_reserved_product() to authenticated, service_role;

create policy renova_assets_admin_read on storage.objects for select to authenticated
  using (bucket_id in ('furniture-images','furniture-models') and (select public.is_admin()));
create policy renova_assets_admin_delete on storage.objects for delete to authenticated
  using (bucket_id in ('furniture-images','furniture-models') and (select public.is_admin()));

CREATE TABLE public.payment_settings (
  id smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  stripe_secret_key_enc text,
  stripe_key_mode text CHECK (stripe_key_mode IN ('test', 'live')),
  stripe_key_hint text,
  stripe_account_name text,
  stripe_webhook_secret_enc text,
  stripe_webhook_hint text,
  turnstile_site_key text,
  turnstile_secret_key_enc text,
  checkout_enabled boolean NOT NULL DEFAULT false,
  allow_live_payments boolean NOT NULL DEFAULT false,
  enable_swish boolean NOT NULL DEFAULT false,
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid
);
GRANT ALL ON public.payment_settings TO service_role;
ALTER TABLE public.payment_settings ENABLE ROW LEVEL SECURITY;
INSERT INTO public.payment_settings (id) VALUES (1) ON CONFLICT DO NOTHING;
REVOKE ALL ON public.payment_settings FROM anon, authenticated;