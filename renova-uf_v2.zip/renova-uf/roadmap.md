# RENOVA UF migration roadmap

- [x] Port all pages, 3D chair, animations and design
- [x] Database, security rules, storage and admin workspace on Lovable Cloud
- [x] Checkout, order status, cancel, reconcile, Stripe webhook, contact form ported
- [ ] Stripe keys + webhook — owner enters them on admin → Betalningar (needs an admin account first)
- [ ] Turnstile keys — owner enters them on admin → Betalningar
- [ ] Existing data exports, if any — waiting on user
- [x] Polish pass: fix errors, richer scroll/3D animations across pages (user request Nov 20)
- [x] Admin email: user chose none for now
- [x] Backend: stays on Lovable Cloud (Supabase-based) per user
- [x] Admin page: Stripe connection panel (enter keys securely, status, webhook URL, enable checkout)
- [x] Footer: 'Site by ElvaStudio' linking to https://www.elvastudio.org/
- [x] Workshop videos + photos: Om oss 'I verkstaden' section, Process 'Verktygslådan' supplies photo (user request Nov 20)
- [x] Own Supabase for exported copy: setup SQL + DEPLOY.md + .env.example
- [x] Audit: pages load, tests pass, production build OK, ZIP exported
