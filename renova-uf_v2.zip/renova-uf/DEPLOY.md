# RENOVA UF — self-hosting on Cloudflare with your own Supabase

The site is a full-stack app (pages + server code for checkout, uploads, webhook).
It deploys to **Cloudflare Workers** (Pages "static only" is not enough — the admin,
uploads and Stripe need the server part).

## 1. Supabase
1. Create a project at supabase.com.
2. SQL editor: run `supabase/self-host/01_schema.sql`, then `02_storage.sql`.
3. Authentication → Providers: enable Email. Authentication → URL configuration: set Site URL to your domain and add `https://your-domain.se/reset-password`.
4. Add your admin email: `insert into public.admin_invites (email) values ('you@example.com');`

## 2. Build
```sh
npm install
npm run build      # output: dist/ (Cloudflare Worker + static assets)
```

## 3. Deploy to Cloudflare
```sh
npx wrangler deploy --config dist/server/wrangler.json
```
Then in Cloudflare → your Worker → Settings → Variables, add every value from `.env.example`
(server ones as **secrets**). `VITE_*` values must also be set when running `npm run build`.

## 4. After deploy
- Sign up on `/admin` with the invited email, confirm it, sign in.
- Stripe Dashboard → Webhooks: add `https://your-domain.se/api/public/stripe-webhook`; enter keys on /admin → Betalningar.
- Turnstile: add your domain to the site's allowed hostnames.
