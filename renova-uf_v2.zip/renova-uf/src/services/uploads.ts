import { AssetError, IMAGE_LIMIT, MODEL_LIMIT, validateAsset, type AssetKind } from '../lib/asset-validation';
import { uploadAsset as uploadAssetFn } from '../lib/admin.functions';

export type UploadKind = AssetKind;

/** Early browser check; the server repeats the same content validation and the admin check. */
export async function validateUpload(file: File, kind: UploadKind) {
  const limit = kind === 'image' ? IMAGE_LIMIT : MODEL_LIMIT;
  if (!file.size || file.size > limit)
    throw new Error(`Filen måste vara mellan 1 byte och ${limit / 1024 / 1024} MB.`);
  try {
    return validateAsset(new Uint8Array(await file.arrayBuffer()), kind);
  } catch (error) {
    if (error instanceof AssetError) throw new Error(error.message);
    throw error;
  }
}

export async function uploadAsset(file: File, kind: UploadKind): Promise<string> {
  await validateUpload(file, kind);
  if (kind === 'image') {
    let bitmap: ImageBitmap;
    try {
      bitmap = await createImageBitmap(file);
    } catch {
      throw new Error('Bilden kunde inte läsas. Välj en annan bild.');
    }
    const tooLarge =
      bitmap.width > 8000 || bitmap.height > 8000 || bitmap.width * bitmap.height > 32_000_000;
    bitmap.close();
    if (tooLarge)
      throw new Error('Bilden är för stor. Använd högst 8 000 pixlar per sida och 32 megapixlar.');
  }
  const body = new FormData();
  body.set('file', file);
  body.set('kind', kind);
  try {
    const result = await uploadAssetFn({ data: body });
    return result.url;
  } catch (error) {
    const message = error instanceof Error ? error.message : '';
    if (/Unauthorized/i.test(message)) throw new Error('Logga in igen innan du laddar upp en fil.');
    throw new Error(message || 'Filen kunde inte laddas upp. Försök igen.');
  }
}
