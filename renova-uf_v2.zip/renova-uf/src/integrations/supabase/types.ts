export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      admin_invites: {
        Row: {
          created_at: string
          email: string
        }
        Insert: {
          created_at?: string
          email: string
        }
        Update: {
          created_at?: string
          email?: string
        }
        Relationships: []
      }
      company_images: {
        Row: {
          alt: string
          id: string
          image_url: string
          published: boolean
          sort_order: number
        }
        Insert: {
          alt: string
          id?: string
          image_url: string
          published?: boolean
          sort_order?: number
        }
        Update: {
          alt?: string
          id?: string
          image_url?: string
          published?: boolean
          sort_order?: number
        }
        Relationships: []
      }
      contact_messages: {
        Row: {
          created_at: string
          email: string
          id: string
          message: string
          name: string
          product_id: string | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          message: string
          name: string
          product_id?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          message?: string
          name?: string
          product_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "contact_messages_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      order_items: {
        Row: {
          id: string
          name: string
          order_id: string
          price: number
          product_id: string
          quantity: number
        }
        Insert: {
          id?: string
          name: string
          order_id: string
          price: number
          product_id: string
          quantity: number
        }
        Update: {
          id?: string
          name?: string
          order_id?: string
          price?: number
          product_id?: string
          quantity?: number
        }
        Relationships: [
          {
            foreignKeyName: "order_items_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      orders: {
        Row: {
          created_at: string
          currency: string
          customer_email: string
          customer_name: string
          id: string
          payment_reference: string | null
          request_fingerprint: string
          status: string
          stripe_session_id: string | null
          total: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          currency?: string
          customer_email: string
          customer_name: string
          id: string
          payment_reference?: string | null
          request_fingerprint: string
          status?: string
          stripe_session_id?: string | null
          total?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          currency?: string
          customer_email?: string
          customer_name?: string
          id?: string
          payment_reference?: string | null
          request_fingerprint?: string
          status?: string
          stripe_session_id?: string | null
          total?: number
          updated_at?: string
        }
        Relationships: []
      }
      payment_events: {
        Row: {
          action: string
          created_at: string
          event_id: string
          order_id: string
        }
        Insert: {
          action: string
          created_at?: string
          event_id: string
          order_id: string
        }
        Update: {
          action?: string
          created_at?: string
          event_id?: string
          order_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "payment_events_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      payment_settings: {
        Row: {
          allow_live_payments: boolean
          checkout_enabled: boolean
          enable_swish: boolean
          id: number
          stripe_account_name: string | null
          stripe_key_hint: string | null
          stripe_key_mode: string | null
          stripe_secret_key_enc: string | null
          stripe_webhook_hint: string | null
          stripe_webhook_secret_enc: string | null
          turnstile_secret_key_enc: string | null
          turnstile_site_key: string | null
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          allow_live_payments?: boolean
          checkout_enabled?: boolean
          enable_swish?: boolean
          id?: number
          stripe_account_name?: string | null
          stripe_key_hint?: string | null
          stripe_key_mode?: string | null
          stripe_secret_key_enc?: string | null
          stripe_webhook_hint?: string | null
          stripe_webhook_secret_enc?: string | null
          turnstile_secret_key_enc?: string | null
          turnstile_site_key?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          allow_live_payments?: boolean
          checkout_enabled?: boolean
          enable_swish?: boolean
          id?: number
          stripe_account_name?: string | null
          stripe_key_hint?: string | null
          stripe_key_mode?: string | null
          stripe_secret_key_enc?: string | null
          stripe_webhook_hint?: string | null
          stripe_webhook_secret_enc?: string | null
          turnstile_secret_key_enc?: string | null
          turnstile_site_key?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      product_images: {
        Row: {
          id: string
          image_url: string
          product_id: string
          sort_order: number
        }
        Insert: {
          id?: string
          image_url: string
          product_id: string
          sort_order?: number
        }
        Update: {
          id?: string
          image_url?: string
          product_id?: string
          sort_order?: number
        }
        Relationships: [
          {
            foreignKeyName: "product_images_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      products: {
        Row: {
          availability: string
          category: string
          condition: string
          created_at: string
          description: string
          dimensions: string
          featured: boolean
          id: string
          model_url: string | null
          name: string
          price: number
          published: boolean
          stock: number
        }
        Insert: {
          availability?: string
          category: string
          condition?: string
          created_at?: string
          description?: string
          dimensions?: string
          featured?: boolean
          id?: string
          model_url?: string | null
          name: string
          price: number
          published?: boolean
          stock?: number
        }
        Update: {
          availability?: string
          category?: string
          condition?: string
          created_at?: string
          description?: string
          dimensions?: string
          featured?: boolean
          id?: string
          model_url?: string | null
          name?: string
          price?: number
          published?: boolean
          stock?: number
        }
        Relationships: []
      }
      restorations: {
        Row: {
          after_image_url: string
          before_image_url: string
          created_at: string
          description: string
          id: string
          product_id: string | null
          published: boolean
          title: string
        }
        Insert: {
          after_image_url: string
          before_image_url: string
          created_at?: string
          description?: string
          id?: string
          product_id?: string | null
          published?: boolean
          title: string
        }
        Update: {
          after_image_url?: string
          before_image_url?: string
          created_at?: string
          description?: string
          id?: string
          product_id?: string | null
          published?: boolean
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "restorations_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      apply_checkout_event: {
        Args: {
          p_action: string
          p_currency: string
          p_event_id: string
          p_order_id: string
          p_payment_reference: string
          p_session_id: string
          p_total: number
        }
        Returns: undefined
      }
      attach_checkout_session: {
        Args: { p_order_id: string; p_session_id: string }
        Returns: undefined
      }
      claim_admin_invite: { Args: never; Returns: boolean }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_admin: { Args: never; Returns: boolean }
      order_json: { Args: { p_id: string }; Returns: Json }
      release_unattached_order: {
        Args: { p_order_id: string }
        Returns: undefined
      }
      reserve_order: {
        Args: {
          p_customer_email: string
          p_customer_name: string
          p_fingerprint: string
          p_items: Json
          p_order_id: string
        }
        Returns: Json
      }
    }
    Enums: {
      app_role: "admin"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin"],
    },
  },
} as const
