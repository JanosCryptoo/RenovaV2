import { createFileRoute } from '@tanstack/react-router';
import { Privacy } from '../components/pages/Information';

export const Route = createFileRoute('/integritet')({
  head: () => ({
    meta: [
      { title: 'Integritet — RENOVA UF' },
      { name: 'description', content: 'Så hanterar RENOVA UF dina uppgifter när du besöker webbplatsen, kontaktar oss eller handlar.' },
      { property: 'og:title', content: 'Integritet — RENOVA UF' },
      { property: 'og:description', content: 'Så hanterar RENOVA UF dina uppgifter när du besöker webbplatsen, kontaktar oss eller handlar.' },
    ],
  }),
  component: Privacy,
});
