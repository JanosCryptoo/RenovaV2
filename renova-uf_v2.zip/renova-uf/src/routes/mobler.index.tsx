import { useMemo, useState } from 'react';
import { createFileRoute, useRouter } from '@tanstack/react-router';
import { useSuspenseQuery } from '@tanstack/react-query';
import { Search, SlidersHorizontal } from 'lucide-react';
import { productsQuery } from '../lib/catalog.functions';
import { Reveal } from '../components/animations/Reveal';
import ProductCard from '../components/products/ProductCard';
import EmptyCatalog from '../components/products/EmptyCatalog';
export const Route = createFileRoute('/mobler/')({
  loader: ({ context }) => context.queryClient.ensureQueryData(productsQuery()),
  head: () => ({
    meta: [
      { title: 'Våra möbler — RENOVA UF' },
      {
        name: 'description',
        content:
          'Omsorgsfullt förnyade, begagnade möbler från RENOVA UF i Eskilstuna. Varje exemplar är unikt.',
      },
      { property: 'og:title', content: 'Våra möbler — RENOVA UF' },
      { property: 'og:description', content: 'Hitta din nästa favorit bland våra förnyade möbler.' },
    ],
  }),
  component: Products,
});

function Products() {
  const router = useRouter();
  const { data, refetch } = useSuspenseQuery(productsQuery());
  const { products, error } = data;
  const loading = false;
  const reload = () => {
    void refetch();
    void router.invalidate();
  };
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('Alla möbler');
  const [sort, setSort] = useState('newest');
  const [availableOnly, setAvailableOnly] = useState(false);
  const categories = ['Alla möbler', ...new Set(products.map((p) => p.category))];
  const filtered = useMemo(
    () =>
      products
        .filter(
          (p) =>
            (category === 'Alla möbler' || p.category === category) &&
            `${p.name} ${p.description}`
              .toLocaleLowerCase('sv')
              .includes(query.toLocaleLowerCase('sv')) &&
            (!availableOnly || (p.stock > 0 && p.availability === 'available')),
        )
        .sort((a, b) =>
          sort === 'price-low'
            ? a.price - b.price
            : sort === 'price-high'
              ? b.price - a.price
              : b.created_at.localeCompare(a.created_at),
        ),
    [products, query, category, sort, availableOnly],
  );
  return (
    <div className="container catalog-page">
      <Reveal className="page-intro">
        <span className="eyebrow">Kollektionen</span>
        <h1>
          Hitta din
          <br />
          <em>nästa favorit.</em>
        </h1>
        <p>
          Omsorgsfullt förnyade möbler med en egen historia. Varje exemplar är unikt, precis som
          hemmet det ska få leva i.
        </p>
      </Reveal>
      <div className="catalog-toolbar">
        <div className="search-field">
          <Search size={18} />
          <label className="sr-only" htmlFor="search">
            Sök möbler
          </label>
          <input
            id="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Sök en möbel…"
          />
        </div>
        <div className="filter-select">
          <SlidersHorizontal size={17} />
          <label className="sr-only" htmlFor="sort">
            Sortera möbler
          </label>
          <select id="sort" value={sort} onChange={(e) => setSort(e.target.value)}>
            <option value="newest">Senast publicerade</option>
            <option value="price-low">Pris: lägst först</option>
            <option value="price-high">Pris: högst först</option>
          </select>
        </div>
      </div>
      <div className="catalog-filter-row">
        <div className="category-tabs" aria-label="Filtrera kategori">
          {categories.map((c) => (
            <button
              key={c}
              className={category === c ? 'active' : ''}
              aria-pressed={category === c}
              onClick={() => setCategory(c)}
            >
              {c}
            </button>
          ))}
        </div>
        <label className="checkbox-label">
          <input
            type="checkbox"
            checked={availableOnly}
            onChange={(e) => setAvailableOnly(e.target.checked)}
          />{' '}
          Bara tillgängliga
        </label>
      </div>
      <p className="result-count" aria-live="polite">
        {loading
          ? 'Hämtar möbler…'
          : `${filtered.length} ${filtered.length === 1 ? 'möbel' : 'möbler'}`}
      </p>
      {error ? (
        <div role="alert" className="notice">
          {error}
          <button className="text-link" onClick={reload}>
            Försök igen
          </button>
        </div>
      ) : loading ? (
        <div className="catalog-skeleton" aria-label="Laddar möbler" />
      ) : products.length === 0 ? (
        <EmptyCatalog />
      ) : filtered.length === 0 ? (
        <div className="empty-search">
          <h2>Inga möbler matchar din sökning.</h2>
          <button
            className="button button-outline"
            onClick={() => {
              setQuery('');
              setCategory('Alla möbler');
              setAvailableOnly(false);
            }}
          >
            Visa alla möbler
          </button>
        </div>
      ) : (
        <div className="product-grid">
          {filtered.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
