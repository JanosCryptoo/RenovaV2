import { useState, type FormEvent } from 'react';
import { createFileRoute, Link } from '@tanstack/react-router';
import { useSuspenseQuery } from '@tanstack/react-query';
import { useServerFn } from '@tanstack/react-start';
import { Instagram, MapPin, CheckCircle2 } from 'lucide-react';
import { Reveal } from '../components/animations/Reveal';
import Turnstile from '../components/Turnstile';
import { productsQuery } from '../lib/catalog.functions';
import { capabilitiesQuery, sendContact as sendContactFn } from '../lib/shop.functions';

export const Route = createFileRoute('/kontakt')({
  validateSearch: (search: Record<string, unknown>): { produkt?: string } =>
    typeof search['produkt'] === 'string' && /^[0-9a-f-]{36}$/i.test(search['produkt'])
      ? { produkt: search['produkt'] }
      : {},
  loader: ({ context }) =>
    Promise.all([
      context.queryClient.ensureQueryData(productsQuery()),
      context.queryClient.ensureQueryData(capabilitiesQuery()),
    ]),
  head: () => ({
    meta: [
      { title: 'Kontakt — RENOVA UF' },
      { name: 'description', content: 'Nyfiken på en möbel, vårt arbete eller RENOVA UF? Skriv till oss eller hör av dig på Instagram.' },
      { property: 'og:title', content: 'Kontakt — RENOVA UF' },
      { property: 'og:description', content: 'Nyfiken på en möbel, vårt arbete eller RENOVA UF? Skriv till oss eller hör av dig på Instagram.' },
    ],
  }),
  component: Contact,
});

function Contact() {
  const search = Route.useSearch();
  const {
    data: { products },
  } = useSuspenseQuery(productsQuery());
  const { data: capabilities } = useSuspenseQuery(capabilitiesQuery());
  const config = { ...capabilities, loading: false };
  const sendContact = useServerFn(sendContactFn);
  const [product, setProduct] = useState(search.produkt ?? '');
  const [status, setStatus] = useState<'idle' | 'sending' | 'sent'>('idle');
  const [error, setError] = useState('');
  const [token, setToken] = useState('');
  const [reset, setReset] = useState(0);
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError('');
    if (!config.contactEnabled) {
      setError('Kontaktformuläret är inte öppet ännu. Skriv gärna till oss på Instagram.');
      return;
    }
    const form = e.currentTarget;
    const values = new FormData(form);
    setStatus('sending');
    try {
      await sendContact({
        data: {
          name: String(values.get('name')).trim(),
          email: String(values.get('email')).trim(),
          message: String(values.get('message')).trim(),
          ...(product ? { product_id: product } : {}),
          website: String(values.get('website') || ''),
          turnstileToken: token,
        },
      });
      setStatus('sent');
      form.reset();
    } catch (err) {
      setStatus('idle');
      setError(err instanceof Error ? err.message : 'Meddelandet kunde inte skickas. Försök igen.');
      setReset((r) => r + 1);
    }
  }
  return (
    <div className="container contact-page">
      <Reveal className="page-intro">
        <span className="eyebrow">Kontakt</span>
        <h1>
          En fråga.
          <br />
          <em>En början.</em>
        </h1>
        <p>Nyfiken på en möbel, vårt arbete eller RENOVA UF? Vi hör gärna från dig.</p>
      </Reveal>
      <div className="contact-grid">
        <Reveal className="contact-details">
          <h2>
            Låt oss prata
            <br />
            <em>om möjligheterna.</em>
          </h2>
          <div>
            <MapPin size={20} strokeWidth={1} />
            <p>
              Eskilstuna, Sverige
              <br />
              <span>JENSEN Gymnasium Eskilstuna</span>
            </p>
          </div>
          <div>
            <Instagram size={20} strokeWidth={1} />
            <a
              href="https://www.instagram.com/uf_renova/"
              target="_blank"
              rel="noopener noreferrer"
            >
              @uf_renova
              <br />
              <span>Följ oss och skicka ett meddelande</span>
            </a>
          </div>
          <p className="small-copy">
            Hämtning av möbler sker efter överenskommelse. Kontakta oss innan du kommer förbi.
          </p>
        </Reveal>
        <Reveal className="contact-form-wrap">
          {status === 'sent' ? (
            <div className="form-success" role="status">
              <CheckCircle2 size={38} strokeWidth={1} />
              <h2>Tack för ditt meddelande.</h2>
              <p>Vi har tagit emot det och återkommer till dig.</p>
              <button
                className="button button-outline"
                onClick={() => {
                  setStatus('idle');
                  setReset((r) => r + 1);
                }}
              >
                Skriv ett nytt meddelande
              </button>
            </div>
          ) : (
            <form onSubmit={submit} className="contact-form">
              <h3>Skriv till oss</h3>
              <label className="form-field">
                Ditt namn
                <input
                  name="name"
                  autoComplete="name"
                  required
                  minLength={2}
                  maxLength={120}
                  placeholder="För- och efternamn"
                />
              </label>
              <label className="form-field">
                E-postadress
                <input
                  name="email"
                  autoComplete="email"
                  required
                  type="email"
                  maxLength={254}
                  placeholder="namn@exempel.se"
                />
              </label>
              <label className="form-field">
                Vad gäller din fråga?
                <select value={product} onChange={(e) => setProduct(e.target.value)}>
                  <option value="">En allmän fråga</option>
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>
              </label>
              <label className="form-field">
                Ditt meddelande
                <textarea
                  name="message"
                  required
                  minLength={10}
                  maxLength={5000}
                  rows={5}
                  placeholder="Berätta vad du funderar på…"
                />
              </label>
              <label className="honeypot" aria-hidden="true">
                Lämna tomt
                <input name="website" tabIndex={-1} autoComplete="off" />
              </label>
              <label className="checkbox-label">
                <input type="checkbox" required /> Jag har läst hur mina uppgifter används i{' '}
                <Link to="/integritet">integritetsinformationen</Link>.
              </label>
              {!config.loading && !config.contactEnabled && (
                <p className="notice">
                  Kontaktformuläret är inte öppet ännu. Du når oss på{' '}
                  <a
                    href="https://www.instagram.com/uf_renova/"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Instagram
                  </a>
                  .
                </p>
              )}
              {config.contactEnabled && config.turnstileSiteKey && (
                <Turnstile siteKey={config.turnstileSiteKey} onToken={setToken} resetKey={reset} />
              )}
              {error && (
                <p className="form-error" role="alert">
                  {error}
                </p>
              )}
              <button
                className="button full-width"
                disabled={
                  status === 'sending' ||
                  config.loading ||
                  (config.contactEnabled && !!config.turnstileSiteKey && !token)
                }
              >
                {status === 'sending'
                  ? 'Skickar…'
                  : config.loading
                    ? 'Kontrollerar formuläret…'
                    : 'Skicka meddelande'}
              </button>
              <p className="small-copy">
                Vi använder dina uppgifter för att besvara ditt meddelande.
              </p>
            </form>
          )}
        </Reveal>
      </div>
    </div>
  );
}
