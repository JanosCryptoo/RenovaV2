import { createFileRoute, Link } from '@tanstack/react-router';
import { useSuspenseQuery } from '@tanstack/react-query';
import { Reveal } from '../components/animations/Reveal';
import { companyImagesQuery } from '../lib/catalog.functions';
import { safeImageUrl } from '../lib/format';
import { TEAM } from '../lib/team';
import { WORKSHOP } from '../lib/workshop';
import { Parallax } from '../components/animations/Parallax';
import { WordReveal } from '../components/animations/WordReveal';
import { WorkshopClip } from '../components/workshop/WorkshopClip';

export const Route = createFileRoute('/om-oss')({
  loader: ({ context }) => context.queryClient.ensureQueryData(companyImagesQuery()),
  head: () => ({
    meta: [
      { title: 'Om oss — RENOVA UF' },
      { name: 'description', content: 'RENOVA UF är ett UF-företag vid JENSEN Gymnasium Eskilstuna som ger begagnade möbler en andra chans.' },
      { property: 'og:title', content: 'Om oss — RENOVA UF' },
      { property: 'og:description', content: 'RENOVA UF är ett UF-företag vid JENSEN Gymnasium Eskilstuna som ger begagnade möbler en andra chans.' },
      { property: 'og:type', content: 'website' },
      { name: 'twitter:card', content: 'summary_large_image' },
    ],
  }),
  component: About,
});

function About() {
  const { data: images } = useSuspenseQuery(companyImagesQuery());
  return (
    <>
      <div className="container">
        <Reveal className="page-intro">
          <span className="eyebrow">Om RENOVA UF</span>
          <h1>
            Nya idéer.
            <br />
            <em>Gamla favoriter.</em>
          </h1>
          <p>
            Vi är RENOVA UF från JENSEN Gymnasium Eskilstuna. Med nyfikenhet, omtanke och en tro på
            återbruk ger vi möbler en andra chans.
          </p>
        </Reveal>
        <section className="about-statement">
          <Reveal>
            <span className="eyebrow">Vår övertygelse</span>
            <h2>
              Det bästa med en möbel
              <br />
              kan vara det som
              <br />
              <em>redan finns.</em>
            </h2>
          </Reveal>
          <Reveal>
            <p>
              En fin form. Ett levande material. Känslan av något som har en historia. Vi vill
              hjälpa fler att upptäcka värdet i begagnade möbler.
            </p>
            <p>
              Vi köper in slitna möbler, rengör, reparerar och fräschar upp dem. Sedan säljer vi dem
              vidare till ett överkomligt pris. På så sätt får de fortsätta användas, istället för
              att slängas.
            </p>
            <Link to="/process" className="text-link">
              Läs om vår process
            </Link>
          </Reveal>
        </section>
      </div>
      <section className="about-quote">
        <Reveal>
          <blockquote>
            “Från gammalt
            <br />
            <em>till nytt.</em>”
          </blockquote>
          <span className="eyebrow">En enkel tanke. Vår drivkraft.</span>
        </Reveal>
      </section>
      <section className="container section team">
        <Reveal className="team__intro">
          <div>
            <span className="eyebrow">Människorna bakom</span>
            <h2>
              Omtanke börjar
              <br />
              <em>med oss.</em>
            </h2>
          </div>
          <div>
            <p>
              RENOVA UF är ett UF-företag vid JENSEN Gymnasium Eskilstuna. Här växer vårt företag
              fram, en möbel i taget.
            </p>
            <Link to="/kontakt" className="button button-outline">
              Säg hej till oss
            </Link>
          </div>
        </Reveal>
        <ul className="team__grid">
          {TEAM.map((member, index) => (
            <li key={member.name}>
              <Reveal delay={index * 0.12}>
                <figure className="team-card">
                  <div className="team-card__frame">
                    <img
                      src={member.photo}
                      alt={`${member.name}, ${member.role} på RENOVA UF`}
                      loading="lazy"
                      width={640}
                      height={880}
                    />
                  </div>
                  <figcaption>
                    <span className="eyebrow">{member.role}</span>
                    <h3>{member.name}</h3>
                  </figcaption>
                </figure>
              </Reveal>
            </li>
          ))}
        </ul>
        {images.length ? (
          <Reveal className="team-gallery">
            {images.map((img) => (
              <img key={img.id} src={safeImageUrl(img.image_url)} alt={img.alt} loading="lazy" />
            ))}
          </Reveal>
        ) : null}
      </section>
      <section className="workshop" aria-labelledby="workshop-title">
        <div className="container workshop__inner">
          <Reveal className="workshop__intro">
            <span className="eyebrow">I verkstaden</span>
            <h2 id="workshop-title">
              <WordReveal text="Händerna bakom" />
              <br />
              <WordReveal text="förvandlingen." italic delay={0.15} />
            </h2>
            <p>
              Så här ser det ut när vi arbetar. En hylla i furu får en ny yta, ribba för ribba, med
              svart lackfärg och en stadig pensel.
            </p>
            <Link to="/process" className="text-link">
              Se hela vår process
            </Link>
          </Reveal>
          <div className="workshop__reel">
            <Parallax className="workshop__item workshop__item--a" distance={36}>
              <Reveal>
                <WorkshopClip
                  src={WORKSHOP.lacquer.src}
                  poster={WORKSHOP.lacquer.poster}
                  label="Penseln doppas i svart lackfärg ovanför en hylla i furu"
                />
                <p className="workshop__caption">
                  <span>01</span> Svart lackfärg
                </p>
              </Reveal>
            </Parallax>
            <Parallax className="workshop__item workshop__item--b" distance={-28}>
              <Reveal delay={0.12}>
                <div className="workshop-photo">
                  <img
                    src={WORKSHOP.pineShelf}
                    alt="En hylla i furu med knoppar, innan den får ny färg"
                    loading="lazy"
                    width={1170}
                    height={1560}
                  />
                </div>
                <p className="workshop__caption">
                  <span>02</span> Före: furu med knoppar
                </p>
              </Reveal>
            </Parallax>
            <Parallax className="workshop__item workshop__item--c" distance={48}>
              <Reveal delay={0.24}>
                <WorkshopClip
                  src={WORKSHOP.brushing.src}
                  poster={WORKSHOP.brushing.poster}
                  label="Svart lack penslas på en ribba"
                />
                <p className="workshop__caption">
                  <span>03</span> Första strykningen
                </p>
              </Reveal>
            </Parallax>
          </div>
        </div>
      </section>
    </>
  );
}
