import { createFileRoute } from "@tanstack/react-router";
import Stripe from "stripe";

const json = (value: unknown, status = 200) =>
  new Response(JSON.stringify(value), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" },
  });

const RELEVANT = [
  "checkout.session.completed",
  "checkout.session.async_payment_succeeded",
  "checkout.session.async_payment_failed",
  "checkout.session.expired",
];
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

/** Stripe webhook. Every event is signature-verified against the webhook secret (admin page or project secret) before use. */
export const Route = createFileRoute("/api/public/stripe-webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { readEnv } = await import("@/lib/renova.server");
        const env = await readEnv();
        const secret = env.STRIPE_WEBHOOK_SECRET;
        const key = env.STRIPE_SECRET_KEY;
        if (!secret || !key) return json({ error: "Webhook är inte konfigurerad." }, 503);
        const signature = request.headers.get("Stripe-Signature");
        if (!signature) return json({ error: "Ogiltig signatur." }, 400);
        const length = Number(request.headers.get("Content-Length") || 0);
        if (length > 262_144) return json({ error: "Begäran är för stor." }, 413);
        const raw = await request.text();
        if (raw.length > 262_144) return json({ error: "Begäran är för stor." }, 413);
        const stripe = new Stripe(key, { httpClient: Stripe.createFetchHttpClient() });
        let event: Stripe.Event;
        try {
          event = await stripe.webhooks.constructEventAsync(
            raw,
            signature,
            secret,
            undefined,
            Stripe.createSubtleCryptoProvider(),
          );
        } catch {
          return json({ error: "Ogiltig signatur." }, 400);
        }
        if (event.livemode !== key.startsWith("sk_live_"))
          return json({ error: "Fel betalningsmiljö." }, 400);
        if (!RELEVANT.includes(event.type)) return json({ received: true });
        const session = event.data.object as Stripe.Checkout.Session;
        const orderId = session.metadata?.["order_id"];
        if (
          !orderId ||
          !UUID.test(orderId) ||
          session.client_reference_id !== orderId ||
          session.mode !== "payment"
        )
          return json({ error: "Orderreferens saknas." }, 400);
        let action = "pending";
        if (event.type === "checkout.session.expired") action = "expired";
        else if (event.type === "checkout.session.async_payment_failed") action = "failed";
        else if (session.payment_status === "paid") action = "paid";
        else if (event.type === "checkout.session.async_payment_succeeded")
          return json({ error: "Betalningen är inte bekräftad." }, 400);
        const paymentReference =
          typeof session.payment_intent === "string"
            ? session.payment_intent
            : session.payment_intent?.id || null;
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { error } = await supabaseAdmin.rpc("apply_checkout_event", {
          p_event_id: event.id,
          p_order_id: orderId,
          p_session_id: session.id,
          p_action: action,
          p_total: session.amount_total ?? -1,
          p_currency: session.currency ?? "",
          p_payment_reference: paymentReference as unknown as string,
        });
        // Non-2xx asks Stripe to retry; nothing is marked applied unless the transaction commits.
        if (error) {
          console.error(JSON.stringify({ event: "webhook_apply_failed" }));
          return json({ error: "Ordern kunde inte uppdateras." }, 503);
        }
        return json({ received: true });
      },
    },
  },
});
