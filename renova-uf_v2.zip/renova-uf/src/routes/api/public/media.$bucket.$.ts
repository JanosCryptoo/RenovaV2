import { createFileRoute } from '@tanstack/react-router';

const BUCKETS = {
  'furniture-images': /^[0-9a-f-]{36}\/[0-9a-f-]{36}\.(jpg|png|webp)$/,
  'furniture-models': /^[0-9a-f-]{36}\/[0-9a-f-]{36}\.glb$/,
} as const;
const TYPES: Record<string, string> = {
  jpg: 'image/jpeg',
  png: 'image/png',
  webp: 'image/webp',
  glb: 'model/gltf-binary',
};

/**
 * Public delivery of marketing media (product photos, before/after images, team photos, GLB models).
 * Only server-validated files in the two RENOVA buckets with random names are served.
 */
export const Route = createFileRoute('/api/public/media/$bucket/$')({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const bucket = params.bucket as keyof typeof BUCKETS;
        const path = params._splat ?? '';
        const pattern = BUCKETS[bucket];
        if (!pattern || !pattern.test(path)) return new Response('Not found', { status: 404 });
        const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
        const { data, error } = await supabaseAdmin.storage.from(bucket).download(path);
        if (error || !data) return new Response('Not found', { status: 404 });
        const ext = path.split('.').pop() ?? '';
        return new Response(data, {
          headers: {
            'Content-Type': TYPES[ext] ?? 'application/octet-stream',
            'Cache-Control': 'public, max-age=31536000, immutable',
            'X-Content-Type-Options': 'nosniff',
          },
        });
      },
    },
  },
});
