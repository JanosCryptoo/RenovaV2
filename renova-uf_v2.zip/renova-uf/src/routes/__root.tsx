import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
  type ErrorComponentProps,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import { MotionConfig } from "motion/react";

import appCss from "../styles.css?url";
import { CartProvider } from "../components/CartProvider";
import Layout from "../components/layout/Layout";
import MotionSystem from "../components/animations/MotionSystem";
import MagneticButtons from "../components/animations/MagneticButtons";
import { NotFound } from "../components/pages/Information";
import { reportLovableError } from "../lib/lovable-error-reporting";

function NotFoundComponent() {
  return <NotFound />;
}

function ErrorComponent({ error, reset }: ErrorComponentProps) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { name: "theme-color", content: "#F3E9D9" },
      { title: "RENOVA UF — Från gammalt till nytt." },
      {
        name: "description",
        content:
          "RENOVA UF i Eskilstuna ger begagnade möbler en andra chans. Upptäck möbler med karaktär, kvalitet och omtanke.",
      },
      { name: "author", content: "RENOVA UF" },
      { property: "og:site_name", content: "RENOVA UF" },
      { property: "og:locale", content: "sv_SE" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "preload", href: "/fonts/co3bmX5slCNuHLi8bLeY9MK7whWMhyjYqXtK.woff2", as: "font", type: "font/woff2", crossOrigin: "anonymous" },
      { rel: "preload", href: "/fonts/xn7gYHE41ni1AdIRggexSg.woff2", as: "font", type: "font/woff2", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: appCss },
      { rel: "icon", href: "/favicon.svg", type: "image/svg+xml" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="sv">
      <head>
        <HeadContent />
        {/* Safety net: scroll animations start hidden; if the page scripts are blocked or slow,
            show everything instead of leaving the visitor with an empty page. */}
        <script
          dangerouslySetInnerHTML={{
            __html:
              "setTimeout(function(){var d=document.documentElement;if(!d.hasAttribute('data-hydrated'))d.classList.add('motion-fallback')},2500)",
          }}
        />
        <noscript>
          <style>{`[style*="opacity:0"],.word-mask>span,.headline-mask>span{opacity:1!important;transform:none!important;clip-path:none!important}`}</style>
        </noscript>
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  useEffect(() => {
    document.documentElement.setAttribute("data-hydrated", "");
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <MotionConfig reducedMotion="user">
        <CartProvider>
          <MotionSystem />
          <MagneticButtons />
          <Layout>
            {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
            <Outlet />
          </Layout>
        </CartProvider>
      </MotionConfig>
    </QueryClientProvider>
  );
}
