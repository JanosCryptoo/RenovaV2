import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { motion, useReducedMotion } from "motion/react";
import { MoveHorizontal, Leaf, Instagram, Image as ImageIcon } from "lucide-react";
import { Reveal } from "../components/animations/Reveal";
import { WordReveal } from "../components/animations/WordReveal";
import { Parallax } from "../components/animations/Parallax";
import EmptyCatalog from "../components/products/EmptyCatalog";
import ProductCard from "../components/products/ProductCard";
import BeforeAfter from "../components/before-after/BeforeAfter";
import { ChairAssembly, ChairScene, RestorationExperience } from "../components/three/LazyScenes";
import { productsQuery, restorationsQuery } from "../lib/catalog.functions";
import { safeImageUrl } from "../lib/format";

export const Route = createFileRoute("/")({
  loader: ({ context }) =>
    Promise.all([
      context.queryClient.ensureQueryData(productsQuery()),
      context.queryClient.ensureQueryData(restorationsQuery()),
    ]),
  head: () => ({
    meta: [
      { title: "RENOVA UF — Från gammalt till nytt." },
      {
        name: "description",
        content:
          "RENOVA UF i Eskilstuna ger begagnade möbler en andra chans. Upptäck noggrant förnyade möbler med karaktär, kvalitet och omtanke.",
      },
      { property: "og:title", content: "RENOVA UF — Från gammalt till nytt." },
      {
        property: "og:description",
        content: "Begagnade möbler med en andra chans, omsorgsfullt förnyade i Eskilstuna.",
      },
    ],
  }),
  component: Home,
});

function Home() {
  const reduced = useReducedMotion();
  const {
    data: { products, error },
  } = useSuspenseQuery(productsQuery());
  const loading = false;
  const {
    data: { items: restorations, error: restorationError },
  } = useSuspenseQuery(restorationsQuery());
  const featured = products.filter((p) => p.featured).slice(0, 3);
  const selection = featured.length ? featured : products.slice(0, 3);
  return (
    <>
      <section className="hero">
        <div className="hero-copy">
          <motion.span
            className="eyebrow hero-eyebrow"
            initial={reduced ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1, duration: 1 }}
          >
            Omsorgsfullt förnyat i Eskilstuna
          </motion.span>
          <h1 aria-label="Från gammalt till nytt.">
            {["Från gammalt", "till nytt."].map((line, i) => (
              <span className="headline-mask" key={line}>
                <motion.span
                  initial={reduced ? false : { y: "105%" }}
                  animate={{ y: 0 }}
                  transition={{ duration: 1.15, delay: 0.2 + i * 0.15, ease: [0.22, 1, 0.36, 1] }}
                >
                  {i === 1 ? <em>{line}</em> : line}
                </motion.span>
              </span>
            ))}
          </h1>
          <motion.div
            initial={reduced ? false : { opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8, duration: 0.8 }}
          >
            <p className="hero-description">
              Vi ger begagnade möbler en andra chans. Upptäck noggrant förnyade möbler med karaktär,
              kvalitet och omtanke.
            </p>
            <div className="hero-buttons">
              <Link className="button" to="/mobler">
                Utforska våra möbler
              </Link>
              <Link className="text-link" to="/om-oss">
                Vår historia
              </Link>
            </div>
          </motion.div>
          <div className="hero-bottom">
            <span className="vertical-line" />
            <span>
              Bevarad karaktär.
              <br />
              Förnyad med omtanke.
            </span>
            <span className="hero-stamp">
              <Leaf size={20} strokeWidth={1} /> ÅTERBRUK
              <br />
              MED OMSORG
            </span>
          </div>
        </div>
        <div className="hero-visual">
          <div className="hero-arch" />
          <span className="hero-visual-caption">ETT NYTT PERSPEKTIV PÅ DET SOM FINNS</span>
          <ChairScene
            variant="hero"
            fallback={<div className="scene-loading">Möbeln tar form…</div>}
          />
          <div className="hero-model-caption">
            <div>
              <span>En studie i nytt liv</span>
              <small>Illustrativ 3D-modell · inte en vara till försäljning</small>
            </div>
            <span className="drag-hint">
              <MoveHorizontal size={22} strokeWidth={1} /> Dra & utforska
            </span>
          </div>
        </div>
      </section>
      <div
        className="brand-strip"
        role="marquee"
        aria-label="Våra värden: Utvalt med känsla, förnyat för hand, skapat för att leva vidare"
      >
        <div className="brand-strip__track" aria-hidden="true">
          {[0, 1, 2, 3].map((copy) => (
            <div className="brand-strip__group" key={copy}>
              <span>Utvalt med känsla</span>
              <i />
              <span>Förnyat för hand</span>
              <i />
              <span>Skapat för att leva vidare</span>
              <i />
            </div>
          ))}
        </div>
      </div>
      <section className="section container introduction">
        <Reveal>
          <span className="eyebrow">Möbler med en fortsättning</span>
          <h2>
            <WordReveal text="Vackra saker förtjänar" />
            <br />
            <WordReveal text="mer än ett liv." italic delay={0.2} />
          </h2>
        </Reveal>
        <Reveal delay={0.15}>
          <p>
            Vi ser möjligheterna i det som redan finns. En sliten yta. Ett stabilt hantverk. En form
            som håller över tid.
          </p>
          <p>
            Med rengöring, reparation och omsorg ger RENOVA UF begagnade möbler ett nytt kapitel —
            och dig chansen att hitta något med personlighet.
          </p>
          <Link to="/process" className="text-link">
            Upptäck vårt hantverk
          </Link>
        </Reveal>
      </section>
      <ChairAssembly fallback={<div className="scene-loading">Delarna hittar sin plats…</div>} />
      <section className="section collection-section">
        <div className="container">
          <Reveal className="section-heading">
            <div>
              <span className="eyebrow">Omsorgsfullt utvalt</span>
              <h2>
                <WordReveal text="Redo för" />{" "}
                <WordReveal text="ett nytt hem." italic delay={0.14} />
              </h2>
            </div>
            <Link to="/mobler" className="text-link">
              Alla våra möbler
            </Link>
          </Reveal>
          {loading ? (
            <p role="status" className="loading-state">
              Vi hämtar möblerna…
            </p>
          ) : error ? (
            <p role="alert" className="notice">
              {error}
            </p>
          ) : selection.length ? (
            <div className="product-grid">
              {selection.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          ) : (
            <Reveal>
              <EmptyCatalog compact />
            </Reveal>
          )}
        </div>
      </section>
      <RestorationExperience
        fallback={<div className="scene-loading">En förvandling tar form…</div>}
      />
      <section className="section container photo-section">
        <Reveal className="section-heading">
          <div>
            <span className="eyebrow">Hantverket, på riktigt</span>
            <h2>
              <WordReveal text="Små detaljer." />
              <br />
              <WordReveal text="Stor skillnad." italic delay={0.16} />
            </h2>
          </div>
          <p>
            Se samma möbel före och efter.
            <br />
            Ett nytt kapitel, med karaktären kvar.
          </p>
        </Reveal>
        {restorationError ? (
          <p role="alert">Bilderna kunde inte hämtas just nu.</p>
        ) : restorations.length ? (
          restorations.map((r) => (
            <Reveal key={r.id}>
              <BeforeAfter
                before={safeImageUrl(r.before_image_url) ?? ""}
                after={safeImageUrl(r.after_image_url) ?? ""}
                title={r.title}
              />
              <p className="comparison-description">{r.description}</p>
            </Reveal>
          ))
        ) : (
          <Reveal>
            <div className="photo-empty">
              <div className="photo-empty-line" />
              <ImageIcon size={40} strokeWidth={0.8} />
              <span className="eyebrow">Före / Efter</span>
              <h3>Varje förvandling har en historia.</h3>
              <p>
                Här kommer vi att visa våra egna bilder från restaureringarna. De första
                fotografierna är ännu inte publicerade.
              </p>
              <Link to="/process" className="text-link">
                Så går förvandlingen till
              </Link>
            </div>
          </Reveal>
        )}
      </section>
      <section className="process-preview section">
        <div className="container">
          <Reveal className="section-heading">
            <div>
              <span className="eyebrow">Från fynd till favorit</span>
              <h2>
                <WordReveal text="Omtanke i" />{" "}
                <WordReveal text="varje steg." italic delay={0.14} />
              </h2>
            </div>
            <Link to="/process" className="text-link">
              Lär känna vår process
            </Link>
          </Reveal>
          <div className="process-list">
            {[
              {
                t: "Hitta",
                d: "Vi letar efter möbler med potential och en historia värd att fortsätta.",
              },
              {
                t: "Förnya",
                d: "Vi rengör, reparerar och fräschar upp med känsla för material och form.",
              },
              {
                t: "Ge nytt liv",
                d: "Vi tar vara på det som finns och låter möbeln få en andra chans.",
              },
              {
                t: "Sälj vidare",
                d: "En möbel med karaktär får hitta hem igen, till ett överkomligt pris.",
              },
            ].map((s, i) => (
              <Reveal key={s.t} className="process-preview-item" delay={i * 0.06}>
                <span className="process-number">0{i + 1}</span>
                <h3>{s.t}</h3>
                <p>{s.d}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <section className="section container sustainability">
        <Reveal>
          <div className="material-art" aria-hidden="true">
            <Parallax className="material-art__rings" distance={50} rotate={14}>
              <div className="wood-ring ring-one" />
              <div className="wood-ring ring-two" />
            </Parallax>
            <span>
              En ny början.
              <br />
              Samma rötter.
            </span>
          </div>
        </Reveal>
        <Reveal>
          <span className="eyebrow">Vår tanke är enkel</span>
          <h2>
            <WordReveal text="Ta vara på" />
            <br />
            <WordReveal text="det som finns." italic delay={0.16} />
          </h2>
          <p>
            En möbel behöver inte vara ny för att kännas rätt. Genom att förlänga livet på
            befintliga möbler vill vi uppmuntra till återbruk och minska onödigt avfall.
          </p>
          <Link to="/om-oss" className="button button-outline">
            Möt RENOVA UF
          </Link>
        </Reveal>
      </section>
      <section className="instagram-band">
        <div className="container">
          <Instagram size={32} strokeWidth={1} />
          <div>
            <span className="eyebrow">Bakom ytan</span>
            <h3>Följ nästa förvandling.</h3>
          </div>
          <a
            className="text-link"
            href="https://www.instagram.com/uf_renova/"
            target="_blank"
            rel="noopener noreferrer"
          >
            @uf_renova
          </a>
        </div>
      </section>
    </>
  );
}
