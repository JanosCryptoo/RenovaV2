import { useEffect, useState } from 'react';
import { createFileRoute, Link } from '@tanstack/react-router';
import { useSuspenseQuery } from '@tanstack/react-query';
import { Armchair, Check, Rotate3d } from 'lucide-react';
import { useCart } from '../components/CartProvider';
import { formatPrice, safeImageUrl } from '../lib/format';
import { ChairScene } from '../components/three/LazyScenes';
import { productQuery } from '../lib/catalog.functions';

export const Route = createFileRoute('/mobler/$id')({
  loader: ({ context, params }) => context.queryClient.ensureQueryData(productQuery(params.id)),
  head: ({ loaderData }) => {
    const product = loaderData?.product;
    const title = product ? `${product.name} — RENOVA UF` : 'Möbeln finns inte här — RENOVA UF';
    const description = product
      ? product.description.slice(0, 155) || `${product.category} från RENOVA UF, omsorgsfullt förnyad.`
      : 'Möbeln kan ha tagits bort eller ännu inte publicerats.';
    const image = product?.product_images[0]?.image_url;
    const absoluteImage = image?.startsWith('https://') ? image : undefined;
    return {
      meta: [
        { title },
        { name: 'description', content: description },
        { property: 'og:title', content: title },
        { property: 'og:description', content: description },
        { property: 'og:type', content: 'product' },
        ...(absoluteImage
          ? [
              { property: 'og:image', content: absoluteImage },
              { name: 'twitter:image', content: absoluteImage },
            ]
          : []),
      ],
    };
  },
  component: ProductDetail,
});

function ProductDetail() {
  const { id } = Route.useParams();
  const {
    data: { product, error: loadError },
  } = useSuspenseQuery(productQuery(id));
  const error = loadError ?? '';
  const [active, setActive] = useState(0);
  const [model, setModel] = useState(false);
  const { add } = useCart();
  useEffect(() => {
    setActive(0);
    setModel(false);
  }, [id]);
  if (!product)
    return (
      <div className="container section">
        <h1>{error ? 'Något gick fel.' : 'Möbeln finns inte här.'}</h1>
        <p>{error || 'Den kan ha tagits bort eller ännu inte publicerats.'}</p>
        <Link to="/mobler" className="button">
          Till våra möbler
        </Link>
      </div>
    );
  const available = product.stock > 0 && product.availability === 'available';
  return (
    <div className="container product-detail">
      <nav className="breadcrumbs" aria-label="Brödsmulor">
        <Link to="/mobler">Våra möbler</Link>
        <span>/</span>
        <span>{product.name}</span>
      </nav>
      <div className="product-detail-grid">
        <div>
          <div className="product-main-image">
            {model && product.model_url ? (
              <ChairScene modelUrl={product.model_url} fallback={<p>Laddar 3D-modellen…</p>} />
            ) : product.product_images.length ? (
              <img
                src={safeImageUrl(product.product_images[active]?.image_url)}
                alt={`${product.name}, bild ${active + 1}`}
              />
            ) : (
              <div className="product-no-image">
                <Armchair size={96} strokeWidth={0.6} />
                <span>Fotografi kommer</span>
              </div>
            )}
          </div>
          <div className="product-thumbnails">
            {product.product_images.map((img, i) => (
              <button
                key={img.id || img.image_url}
                aria-label={`Visa bild ${i + 1}`}
                aria-pressed={active === i && !model}
                onClick={() => {
                  setActive(i);
                  setModel(false);
                }}
              >
                <img src={safeImageUrl(img.image_url)} alt="" />
              </button>
            ))}
            {product.model_url && (
              <button
                className="model-toggle"
                aria-pressed={model}
                onClick={() => setModel(!model)}
              >
                <Rotate3d size={24} />
                Visa i 3D
              </button>
            )}
          </div>
        </div>
        <div className="product-detail-copy">
          <span className="eyebrow">{product.category} · Omsorgsfullt förnyad</span>
          <h1>{product.name}</h1>
          <p className="product-price">{formatPrice(product.price)}</p>
          <p className="product-description">{product.description}</p>
          <span className="availability">
            <Check size={16} />
            {available
              ? 'Tillgänglig — ett unikt exemplar'
              : product.availability === 'reserved'
                ? 'Reserverad just nu'
                : 'Såld'}
          </span>
          <button className="button full-width" onClick={() => add(product)} disabled={!available}>
            {available ? 'Lägg i varukorgen' : 'Inte tillgänglig'}
          </button>
          <Link className="text-link" to="/kontakt" search={{ produkt: product.id }}>
            Fråga oss om möbeln
          </Link>
          <dl className="product-facts">
            <div>
              <dt>Skick</dt>
              <dd>{product.condition}</dd>
            </div>
            <div>
              <dt>Mått</dt>
              <dd>{product.dimensions}</dd>
            </div>
            <div>
              <dt>Hämtning</dt>
              <dd>Eskilstuna, efter överenskommelse</dd>
            </div>
          </dl>
          <p className="small-copy">
            Begagnade möbler bär spår av sitt tidigare liv. Läs beskrivningen och titta på bilderna
            före köp.
          </p>
        </div>
      </div>
    </div>
  );
}
