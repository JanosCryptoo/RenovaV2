import { createFileRoute } from '@tanstack/react-router';
import { PurchaseInfo } from '../components/pages/Information';

export const Route = createFileRoute('/kopinformation')({
  head: () => ({
    meta: [
      { title: 'Köpinformation — RENOVA UF' },
      { name: 'description', content: 'Bra att veta om unika, begagnade möbler, tillgänglighet, hämtning i Eskilstuna och betalning.' },
      { property: 'og:title', content: 'Köpinformation — RENOVA UF' },
      { property: 'og:description', content: 'Bra att veta om unika, begagnade möbler, tillgänglighet, hämtning i Eskilstuna och betalning.' },
    ],
  }),
  component: PurchaseInfo,
});
