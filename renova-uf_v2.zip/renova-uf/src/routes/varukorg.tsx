import { useEffect, useState, type FormEvent } from 'react';
import { createFileRoute, Link } from '@tanstack/react-router';
import { useSuspenseQuery } from '@tanstack/react-query';
import { useServerFn } from '@tanstack/react-start';
import { ShoppingBag, X, LockKeyhole } from 'lucide-react';
import { useCart } from '../components/CartProvider';
import { formatPrice, safeImageUrl } from '../lib/format';
import Turnstile from '../components/Turnstile';
import { readAttempt, saveAttempt, type CheckoutAttempt } from '../lib/checkoutAttempt';
import { productsQuery } from '../lib/catalog.functions';
import { capabilitiesQuery, createCheckout as createCheckoutFn } from '../lib/shop.functions';

export const Route = createFileRoute('/varukorg')({
  loader: ({ context }) =>
    Promise.all([
      context.queryClient.ensureQueryData(productsQuery()),
      context.queryClient.ensureQueryData(capabilitiesQuery()),
    ]),
  head: () => ({
    meta: [
      { title: 'Varukorg — RENOVA UF' },
      { name: 'description', content: 'Din varukorg hos RENOVA UF. Hämtning i Eskilstuna efter överenskommelse.' },
      { property: 'og:title', content: 'Varukorg — RENOVA UF' },
      { property: 'og:description', content: 'Snart börjar ett nytt kapitel.' },
      { name: 'robots', content: 'noindex' },
    ],
  }),
  component: Cart,
});

function Cart() {
  const { items, remove } = useCart();
  const {
    data: { products, error: catalogError },
  } = useSuspenseQuery(productsQuery());
  const loading = false;
  const { data: config } = useSuspenseQuery(capabilitiesQuery());
  const createCheckout = useServerFn(createCheckoutFn);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [token, setToken] = useState('');
  const [reset, setReset] = useState(0);
  const [attempt, setAttempt] = useState<CheckoutAttempt | null>(null);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  // Session storage is read after hydration so the server and first client render match.
  useEffect(() => {
    const restored = readAttempt();
    if (!restored) return;
    setAttempt(restored);
    setName((n) => n || restored.customer.name);
    setEmail((e) => e || restored.customer.email);
  }, []);
  const resolved = items.map((i) => ({
    item: i,
    product: products.find((p) => p.id === i.productId),
  }));
  const valid = resolved.every(
    (r) =>
      r.product && r.product.stock >= r.item.quantity && r.product.availability === 'available',
  );
  const total = resolved.reduce((sum, r) => sum + (r.product?.price || 0) * r.item.quantity, 0);
  const customer = { name: name.trim(), email: email.trim() };
  const signature = JSON.stringify({ items, customer });
  const resumable = !!attempt && attempt.signature === signature;
  async function checkout(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!config.checkoutEnabled || (!valid && !resumable) || !items.length || busy) return;
    setBusy(true);
    setError('');
    const next = resumable
      ? attempt!
      : { id: crypto.randomUUID(), signature, createdAt: Date.now(), items, customer };
    setAttempt(next);
    saveAttempt(next);
    try {
      const result = await createCheckout({
        data: { items, customer, requestId: next.id, turnstileToken: token },
      });
      const url = new URL(result.url);
      if (url.protocol !== 'https:' || url.hostname !== 'checkout.stripe.com')
        throw new Error('Betalningslänken kunde inte verifieras.');
      window.location.assign(url.href);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Betalningen kunde inte startas. Försök igen.');
      setReset((r) => r + 1);
      setBusy(false);
    }
  }
  return (
    <div className="container cart-page">
      <div className="page-intro">
        <span className="eyebrow">Utvalt av dig</span>
        <h1>
          Din <em>varukorg.</em>
        </h1>
        <p>Snart börjar ett nytt kapitel.</p>
      </div>
      {!items.length ? (
        <div className="empty-cart">
          <ShoppingBag size={52} strokeWidth={0.7} />
          <h2>Plats för en ny favorit.</h2>
          <p>Din varukorg är tom. Utforska våra möbler och se vad som kan passa hemma hos dig.</p>
          <Link to="/mobler" className="button">
            Utforska våra möbler
          </Link>
        </div>
      ) : loading ? (
        <p role="status">Vi kontrollerar dina möbler…</p>
      ) : catalogError ? (
        <p className="form-error" role="alert">
          {catalogError} Ladda om sidan innan du går vidare.
        </p>
      ) : (
        <div className="cart-grid">
          <div>
            {resolved.map(({ item, product }) => (
              <article className="cart-line" key={item.productId}>
                {product?.product_images[0] && (
                  <img src={safeImageUrl(product.product_images[0].image_url)} alt={product.name} />
                )}
                <div>
                  <h3>{product?.name || 'Möbeln är inte längre publicerad'}</h3>
                  <p>{product?.category || 'Ta bort möbeln för att fortsätta'}</p>
                  <p>
                    {product ? formatPrice(product.price) : '—'} · {item.quantity} st
                  </p>
                  {(!product ||
                    product.stock < item.quantity ||
                    product.availability !== 'available') && (
                    <p className="form-error">Inte tillgänglig just nu.</p>
                  )}
                </div>
                <button
                  className="icon-button"
                  onClick={() => {
                    remove(item.productId);
                    setAttempt(null);
                    saveAttempt(null);
                  }}
                  aria-label={`Ta bort ${product?.name || 'möbeln'}`}
                >
                  <X size={20} />
                </button>
              </article>
            ))}
            <p className="small-copy">
              Möbler reserveras först när en betalning startas. Tillgänglighet och pris kontrolleras
              då på nytt.
            </p>
            <Link className="text-link" to="/mobler">
              Fortsätt upptäcka
            </Link>
          </div>
          <form className="checkout-panel" onSubmit={checkout}>
            <h2>Ditt nästa kapitel</h2>
            <div className="order-total">
              <span>Summa</span>
              <strong>{formatPrice(total)}</strong>
            </div>
            <p className="small-copy">
              Hämtning i Eskilstuna efter överenskommelse. Ingen frakt tillkommer.
            </p>
            <label className="form-field">
              Namn
              <input
                name="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                autoComplete="name"
                required
                minLength={2}
                maxLength={120}
              />
            </label>
            <label className="form-field">
              E-post
              <input
                name="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
                type="email"
                required
                maxLength={254}
              />
            </label>
            <label className="checkbox-label">
              <input type="checkbox" required /> Jag har läst{' '}
              <Link to="/kopinformation">köpinformationen</Link> och godkänner hämtning i
              Eskilstuna.
            </label>
            {!config.checkoutEnabled && (
              <p className="notice">
                Onlinebetalning är inte tillgänglig ännu. <Link to="/kontakt">Kontakta oss</Link> om
                du är intresserad av en möbel.
              </p>
            )}
            {resumable && (
              <p className="notice">
                En tidigare betalning kan återupptas. Samma reservation kontrolleras säkert när du
                fortsätter.
              </p>
            )}
            {!valid && !resumable && (
              <p className="form-error">
                Ta bort möbler som inte är tillgängliga innan du fortsätter.
              </p>
            )}
            {config.checkoutEnabled && config.turnstileSiteKey && (
              <Turnstile siteKey={config.turnstileSiteKey} onToken={setToken} resetKey={reset} />
            )}
            {error && (
              <p role="alert" className="form-error">
                {error}
              </p>
            )}
            <button
              className="button full-width"
              disabled={
                !config.checkoutEnabled ||
                (!valid && !resumable) ||
                busy ||
                (!!config.turnstileSiteKey && !token)
              }
            >
              <LockKeyhole size={16} />
              {busy
                ? 'Förbereder betalning…'
                : resumable
                  ? 'Återuppta säker betalning'
                  : 'Till säker betalning'}
            </button>
            <p className="small-copy">
              Betalningen slutförs hos Stripe. Inga kortuppgifter sparas på vår webbplats.
            </p>
          </form>
        </div>
      )}
    </div>
  );
}
