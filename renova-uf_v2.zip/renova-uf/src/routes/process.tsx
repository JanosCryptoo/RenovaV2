import { createFileRoute, Link } from "@tanstack/react-router";
import { Search, Hammer, Leaf, Heart } from "lucide-react";
import { Reveal } from "../components/animations/Reveal";
import { ChairAssembly, RestorationExperience } from "../components/three/LazyScenes";
import { Parallax } from "../components/animations/Parallax";
import { WordReveal } from "../components/animations/WordReveal";
import { SuppliesMap } from "../components/workshop/SuppliesMap";
import { WorkshopClip } from "../components/workshop/WorkshopClip";
import { WORKSHOP } from "../lib/workshop";

export const Route = createFileRoute("/process")({
  head: () => ({
    meta: [
      { title: "Vår process — RENOVA UF" },
      {
        name: "description",
        content:
          "Från första fyndet till ett nytt hem: så hittar, förnyar och säljer RENOVA UF begagnade möbler.",
      },
      { property: "og:title", content: "Vår process — RENOVA UF" },
      {
        property: "og:description",
        content:
          "Från första fyndet till ett nytt hem: så hittar, förnyar och säljer RENOVA UF begagnade möbler.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Process,
});
const steps = [
  {
    title: "Hitta",
    quote: "Vi köper in begagnade och slitna möbler.",
    body: "Allt börjar med att se potentialen. Vi letar efter former, material och detaljer som förtjänar att bevaras, även när ytan har sett bättre dagar.",
    icon: Search,
    word: "Potential.",
  },
  {
    title: "Förnya",
    quote: "Vi rengör, reparerar och fräschar upp möblerna.",
    body: "Varje möbel har olika behov. Vi tar hand om den med respekt för dess material och karaktär. Det handlar om att lyfta fram det som redan gör möbeln speciell.",
    icon: Hammer,
    word: "Omsorg.",
  },
  {
    title: "Ge nytt liv",
    quote: "Istället för att möblerna slängs får de en ny chans och längre livslängd.",
    body: "Vi tror på att använda det som redan finns. När en möbel får leva vidare kan dess berättelse fortsätta i en ny miljö.",
    icon: Leaf,
    word: "Förvandling.",
  },
  {
    title: "Sälj vidare",
    quote: "Vi säljer de uppfräschade möblerna till ett överkomligt pris.",
    body: "En genomtänkt möbel ska kunna få plats i fler hem. Vi presenterar skick, mått och detaljer så att du kan hitta en möbel som passar dig.",
    icon: Heart,
    word: "Ett nytt hem.",
  },
];
function Process() {
  return (
    <>
      <div className="container">
        <Reveal className="page-intro">
          <span className="eyebrow">Vår process</span>
          <h1>
            Vi börjar inte om.
            <br />
            <em>Vi tar vid.</em>
          </h1>
          <p>
            Bakom varje förnyad möbel finns omtanke. Från det första fyndet till dess nästa plats i
            vardagen.
          </p>
        </Reveal>
      </div>
      <ChairAssembly fallback={<p className="container">Delarna hittar sin plats…</p>} />
      <div className="process-chapters">
        {steps.map((s, i) => (
          <section className={`process-chapter chapter-${i + 1}`} key={s.title}>
            <div className="container chapter-grid">
              <Reveal className="chapter-art">
                <Parallax className="chapter-art__float" distance={40} rotate={i % 2 ? -8 : 8}>
                  <s.icon strokeWidth={0.55} />
                </Parallax>
                <span>{s.word}</span>
              </Reveal>
              <Reveal className="chapter-copy">
                <span className="eyebrow">
                  0{i + 1} — {s.title.toLocaleUpperCase("sv")}
                </span>
                <h2>{s.quote}</h2>
                <p>{s.body}</p>
              </Reveal>
            </div>
          </section>
        ))}
      </div>
      <section className="container section toolkit" aria-labelledby="toolkit-title">
        <div className="toolkit__head">
          <Reveal>
            <span className="eyebrow">Verktygslådan</span>
            <h2 id="toolkit-title">
              <WordReveal text="Enkla verktyg." />
              <br />
              <WordReveal text="Noggranna händer." italic delay={0.15} />
            </h2>
          </Reveal>
          <Reveal className="toolkit__aside">
            <p>
              Det här är materialet vi använder i verkstaden. Peka på en siffra för att se vad det
              är och vad vi använder det till.
            </p>
            <WorkshopClip
              className="toolkit__clip"
              src={WORKSHOP.brushing.src}
              poster={WORKSHOP.brushing.poster}
              label="Svart lack penslas på en ribba"
            />
          </Reveal>
        </div>
        <Reveal>
          <SuppliesMap />
        </Reveal>
      </section>
      <RestorationExperience fallback={<p className="container">Förvandlingen tar form…</p>} />
      <section className="container section centered">
        <span className="eyebrow">Nästa steg</span>
        <h2>
          Kanske väntar din
          <br />
          <em>nästa favorit här.</em>
        </h2>
        <Link to="/mobler" className="button">
          Utforska våra möbler
        </Link>
      </section>
    </>
  );
}
