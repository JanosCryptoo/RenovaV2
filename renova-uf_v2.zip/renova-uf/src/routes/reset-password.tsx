import { useEffect, useState, type FormEvent } from 'react';
import { createFileRoute, Link, useNavigate } from '@tanstack/react-router';
import { supabase } from '@/integrations/supabase/client';

export const Route = createFileRoute('/reset-password')({
  head: () => ({
    meta: [
      { title: 'Välj nytt lösenord — RENOVA UF' },
      { name: 'description', content: 'Välj ett nytt lösenord för ditt RENOVA UF-konto.' },
      { property: 'og:title', content: 'Välj nytt lösenord — RENOVA UF' },
      { property: 'og:description', content: 'Välj ett nytt lösenord för ditt RENOVA UF-konto.' },
      { name: 'robots', content: 'noindex' },
    ],
  }),
  component: ResetPassword,
});

function ResetPassword() {
  const navigate = useNavigate();
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => {
    const { data } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'PASSWORD_RECOVERY' || event === 'SIGNED_IN') setReady(true);
    });
    if (window.location.hash.includes('type=recovery')) setReady(true);
    void supabase.auth.getSession().then(({ data: s }) => s.session && setReady(true));
    return () => data.subscription.unsubscribe();
  }, []);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const values = new FormData(event.currentTarget);
    const password = String(values.get('password') ?? '');
    if (password !== String(values.get('confirm') ?? '')) {
      setError('Lösenorden matchar inte.');
      return;
    }
    setBusy(true);
    setError('');
    const { error: updateError } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (updateError) {
      setError('Lösenordet kunde inte sparas. Begär en ny länk och försök igen.');
      return;
    }
    void navigate({ to: '/admin' });
  }
  return (
    <div className="container admin-page">
      <div className="admin-login">
        <p className="eyebrow">RENOVA UF · Konto</p>
        <h1>Välj ett nytt lösenord.</h1>
        {!ready ? (
          <p>
            Öppna länken från e-postmeddelandet för att fortsätta. <Link to="/admin">Till inloggningen</Link>
          </p>
        ) : (
          <form className="admin-form" onSubmit={submit}>
            <label>
              Nytt lösenord
              <input name="password" type="password" required minLength={8} autoComplete="new-password" />
            </label>
            <label>
              Upprepa lösenordet
              <input name="confirm" type="password" required minLength={8} autoComplete="new-password" />
            </label>
            {error && (
              <p role="alert" className="admin-error">
                {error}
              </p>
            )}
            <button className="button" disabled={busy}>
              {busy ? 'Sparar…' : 'Spara lösenord'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
