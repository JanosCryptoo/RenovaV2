import { useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { SUPPLIES, WORKSHOP } from '../../lib/workshop';

/** The team's own supplies photo with numbered markers linked to a list. */
export function SuppliesMap() {
  const [active, setActive] = useState<number | null>(null);
  const reduced = useReducedMotion();
  return (
    <div className="supplies">
      <div className="supplies__photo">
        <img
          src={WORKSHOP.supplies}
          alt="RENOVA UF:s material: lackfärg, sealer, målartvätt, penslar, sandpapper, slipklossar och nitrilhandskar framför en hylla i furu."
          loading="lazy"
          width={1170}
          height={900}
        />
        {SUPPLIES.map((s, i) => (
          <motion.button
            type="button"
            key={s.name}
            className={`supplies__pin${active === i ? ' is-active' : ''}`}
            style={{ left: `${s.x}%`, top: `${s.y}%` }}
            onMouseEnter={() => setActive(i)}
            onMouseLeave={() => setActive(null)}
            onFocus={() => setActive(i)}
            onBlur={() => setActive(null)}
            onClick={() => setActive(active === i ? null : i)}
            aria-label={`${i + 1}. ${s.name}`}
            initial={reduced ? false : { scale: 0, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.3 + i * 0.09, type: 'spring', stiffness: 320, damping: 18 }}
          >
            {i + 1}
          </motion.button>
        ))}
      </div>
      <ol className="supplies__list">
        {SUPPLIES.map((s, i) => (
          <li
            key={s.name}
            className={active === i ? 'is-active' : ''}
            onMouseEnter={() => setActive(i)}
            onMouseLeave={() => setActive(null)}
          >
            <span className="supplies__num">{String(i + 1).padStart(2, '0')}</span>
            <div>
              <h3>{s.name}</h3>
              <p>{s.use}</p>
            </div>
          </li>
        ))}
      </ol>
    </div>
  );
}
