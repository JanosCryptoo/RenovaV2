import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { CartItem, Product } from '../types';
import { parseCart } from '../lib/cart';

const CART_KEY = 'renova-cart-v1';

type CartContextValue = {
  items: CartItem[];
  add: (p: Product) => void;
  remove: (id: string) => void;
  clear: () => void;
  notice: string;
  dismiss: () => void;
};
const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [notice, setNotice] = useState('');
  // Browser storage is read after hydration so server and first client render match.
  useEffect(() => {
    try {
      setItems(parseCart(localStorage.getItem(CART_KEY)));
    } catch {
      /* Browsing still works without storage. */
    }
  }, []);
  function update(next: CartItem[]) {
    setItems(next);
    try {
      localStorage.setItem(CART_KEY, JSON.stringify(next));
    } catch {
      /* Browsing still works without storage. */
    }
  }
  function add(p: Product) {
    if (p.stock < 1 || p.availability !== 'available') {
      setNotice('Möbeln är inte tillgänglig just nu.');
      return;
    }
    if (items.some((i) => i.productId === p.id)) {
      setNotice('Möbeln finns redan i din varukorg.');
      return;
    }
    update([...items, { productId: p.id, quantity: 1 }]);
    setNotice(`${p.name} har lagts i din varukorg.`);
  }
  return (
    <CartContext.Provider
      value={{
        items,
        add,
        remove: (id) => update(items.filter((i) => i.productId !== id)),
        clear: () => update([]),
        notice,
        dismiss: () => setNotice(''),
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

// eslint-disable-next-line react-refresh/only-export-components
export function useCart() {
  const value = useContext(CartContext);
  if (!value) throw new Error('CartProvider saknas');
  return value;
}
