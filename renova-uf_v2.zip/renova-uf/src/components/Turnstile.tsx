import { useEffect, useRef } from 'react';
type TurnstileAPI = {
  render: (
    element: HTMLElement,
    options: {
      sitekey: string;
      theme: string;
      callback: (token: string) => void;
      'expired-callback': () => void;
      'error-callback': () => void;
    },
  ) => string;
  remove: (id: string) => void;
};
declare global {
  interface Window {
    turnstile?: TurnstileAPI;
  }
}
let scriptPromise: Promise<void> | null = null;
function loadScript() {
  if (window.turnstile) return Promise.resolve();
  if (!scriptPromise)
    scriptPromise = new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
      script.async = true;
      script.onload = () => resolve();
      script.onerror = () => {
        scriptPromise = null;
        script.remove();
        reject(new Error('Kunde inte ladda säkerhetskontrollen.'));
      };
      document.head.appendChild(script);
    });
  return scriptPromise;
}
export default function Turnstile({
  siteKey,
  onToken,
  resetKey = 0,
}: {
  siteKey: string;
  onToken: (token: string) => void;
  resetKey?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const callbackRef = useRef(onToken);
  callbackRef.current = onToken;
  useEffect(() => {
    let active = true;
    let widget: string | undefined;
    callbackRef.current('');
    loadScript()
      .then(() => {
        if (active && ref.current && window.turnstile)
          widget = window.turnstile.render(ref.current, {
            sitekey: siteKey,
            theme: 'light',
            callback: (token) => callbackRef.current(token),
            'expired-callback': () => callbackRef.current(''),
            'error-callback': () => callbackRef.current(''),
          });
      })
      .catch(() => {
        if (active && ref.current)
          ref.current.textContent =
            'Säkerhetskontrollen kunde inte laddas. Ladda om sidan och försök igen.';
      });
    return () => {
      active = false;
      if (widget && window.turnstile) window.turnstile.remove(widget);
    };
  }, [siteKey, resetKey]);
  return <div ref={ref} className="turnstile" aria-label="Säkerhetskontroll" />;
}
