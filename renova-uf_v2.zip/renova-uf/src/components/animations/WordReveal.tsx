import { Fragment } from 'react';
import { motion, useReducedMotion, type Variants } from 'motion/react';

const word: Variants = {
  hidden: { y: '110%', rotate: 4 },
  show: { y: 0, rotate: 0 },
};

/**
 * Words rise one by one from behind a mask when the heading scrolls into view.
 * The in-view observer sits on the unclipped line, not on the masked words: a word hidden
 * below its mask never "intersects", so observing it directly would keep it hidden forever.
 */
export function WordReveal({
  text,
  delay = 0,
  italic = false,
}: {
  text: string;
  delay?: number;
  italic?: boolean;
}) {
  const reduced = useReducedMotion();
  const words = text.split(' ');
  const Line = italic ? motion.em : motion.span;
  return (
    <Line
      className="word-line"
      aria-label={text}
      initial={reduced ? false : 'hidden'}
      whileInView="show"
      viewport={{ once: true, margin: '-40px' }}
      transition={{ staggerChildren: 0.07, delayChildren: delay }}
    >
      {words.map((w, i) => (
        // The space sits outside the inline-block mask; inside it, trailing whitespace collapses.
        <Fragment key={`${w}-${i}`}>
          <span className="word-mask" aria-hidden="true">
            <motion.span variants={word} transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}>
              {w}
            </motion.span>
          </span>
          {i < words.length - 1 ? ' ' : null}
        </Fragment>
      ))}
    </Line>
  );
}
