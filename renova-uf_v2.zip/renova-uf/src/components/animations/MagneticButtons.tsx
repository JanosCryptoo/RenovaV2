import { useEffect } from 'react';
import { gsap } from 'gsap';
export default function MagneticButtons() {
  useEffect(() => {
    const fine = matchMedia('(pointer:fine)'),
      reduced = matchMedia('(prefers-reduced-motion:reduce)');
    let current: HTMLElement | null = null;
    function reset() {
      if (current)
        gsap.to(current, { x: 0, y: 0, duration: 0.45, ease: 'power3.out', overwrite: true });
      current = null;
    }
    function move(event: PointerEvent) {
      if (!fine.matches || reduced.matches) {
        reset();
        return;
      }
      const element =
        event.target instanceof Element
          ? event.target.closest<HTMLElement>('.button:not(:disabled)')
          : null;
      if (current !== element) reset();
      if (!element) return;
      current = element;
      const rect = element.getBoundingClientRect();
      gsap.to(element, {
        x: (event.clientX - rect.left - rect.width / 2) * 0.055,
        y: (event.clientY - rect.top - rect.height / 2) * 0.11,
        duration: 0.4,
        ease: 'power3.out',
        overwrite: true,
      });
    }
    document.addEventListener('pointermove', move, { passive: true });
    document.addEventListener('pointerleave', reset);
    reduced.addEventListener('change', reset);
    return () => {
      reset();
      document.removeEventListener('pointermove', move);
      document.removeEventListener('pointerleave', reset);
      reduced.removeEventListener('change', reset);
    };
  }, []);
  return null;
}
