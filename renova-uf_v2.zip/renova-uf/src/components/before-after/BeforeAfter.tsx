import { useEffect, useId, useRef, useState, type PointerEvent } from 'react';
import { MoveHorizontal } from 'lucide-react';
import { animate, useReducedMotion } from 'motion/react';

const clamp = (value: number) => Math.min(100, Math.max(0, value));

/**
 * Före/efter-jämförelse. Drag anywhere on the photo (mouse, touch or pen); the hidden range
 * input keeps keyboard and screen-reader control. A short sweep hints that it can be dragged.
 */
export default function BeforeAfter({
  before,
  after,
  title,
  hint = true,
}: {
  before: string;
  after: string;
  title: string;
  /** Play the one-time "drag me" sweep when the slider first scrolls into view. */
  hint?: boolean;
}) {
  const [position, setPosition] = useState(50);
  const [dragging, setDragging] = useState(false);
  const [gliding, setGliding] = useState(false);
  const stageRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const sweep = useRef<{ stop: () => void } | null>(null);
  const touched = useRef(false);
  const reduced = useReducedMotion();
  const id = useId();

  useEffect(() => {
    const stage = stageRef.current;
    if (!hint || reduced || !stage || typeof IntersectionObserver === 'undefined') return;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry?.isIntersecting) return;
        observer.disconnect();
        timer = setTimeout(() => {
          if (touched.current) return;
          sweep.current = animate(50, [50, 36, 64, 50], {
            duration: 2.2,
            ease: 'easeInOut',
            onUpdate: (value) => setPosition(value),
          });
        }, 450);
      },
      { threshold: 0.55 },
    );
    observer.observe(stage);
    return () => {
      observer.disconnect();
      if (timer) clearTimeout(timer);
      sweep.current?.stop();
    };
  }, [hint, reduced]);

  const stopSweep = () => {
    touched.current = true;
    sweep.current?.stop();
    sweep.current = null;
  };

  const moveTo = (clientX: number) => {
    const rect = stageRef.current?.getBoundingClientRect();
    if (!rect || rect.width === 0) return;
    setPosition(clamp(((clientX - rect.left) / rect.width) * 100));
  };

  const onPointerDown = (event: PointerEvent<HTMLDivElement>) => {
    if (event.pointerType === 'mouse' && event.button !== 0) return;
    stopSweep();
    event.currentTarget.setPointerCapture(event.pointerId);
    setDragging(true);
    setGliding(true);
    moveTo(event.clientX);
    inputRef.current?.focus({ preventScroll: true });
  };
  const onPointerMove = (event: PointerEvent<HTMLDivElement>) => {
    if (!dragging) return;
    setGliding(false);
    moveTo(event.clientX);
  };
  const endDrag = () => {
    setDragging(false);
    setGliding(false);
  };

  const rounded = Math.round(position);
  const stageClass = [
    'comparison-stage',
    dragging ? 'is-dragging' : '',
    gliding ? 'is-gliding' : '',
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <figure className="comparison">
      <div
        ref={stageRef}
        className={stageClass}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
        onLostPointerCapture={endDrag}
      >
        <img src={after} alt={`${title} efter restaurering`} loading="lazy" decoding="async" draggable={false} />
        <div className="comparison-before" style={{ clipPath: `inset(0 ${100 - position}% 0 0)` }}>
          <img src={before} alt={`${title} före restaurering`} loading="lazy" decoding="async" draggable={false} />
        </div>
        <span className="comparison-label before-label" data-hidden={position < 14 || undefined}>
          Före
        </span>
        <span className="comparison-label after-label" data-hidden={position > 86 || undefined}>
          Efter
        </span>
        <div className="comparison-line" style={{ left: `${position}%` }}>
          <span>
            <MoveHorizontal size={22} />
          </span>
        </div>
        <label className="sr-only" htmlFor={id}>
          Dra för att jämföra {title} före och efter restaurering
        </label>
        <input
          ref={inputRef}
          id={id}
          type="range"
          min="0"
          max="100"
          step="1"
          value={rounded}
          onChange={(e) => {
            stopSweep();
            setPosition(Number(e.target.value));
          }}
          aria-valuetext={`${rounded} procent före restaurering`}
        />
      </div>
      <figcaption>
        {title}
        <span>Dra i bilden eller använd piltangenterna.</span>
      </figcaption>
    </figure>
  );
}
