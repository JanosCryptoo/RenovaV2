import { useEffect, useState, type ReactNode } from "react";
import { Link, useLocation } from "@tanstack/react-router";
import { AnimatePresence, motion, useReducedMotion, useScroll, useSpring } from "motion/react";
import { ShoppingBag, Menu, X, Instagram } from "lucide-react";
import { useCart } from "../CartProvider";
import { Reveal } from "../animations/Reveal";

const links = [
  { to: "/mobler", label: "Våra möbler" },
  { to: "/process", label: "Vår process" },
  { to: "/om-oss", label: "Om oss" },
  { to: "/kontakt", label: "Kontakt" },
] as const;

export default function Layout({ children }: { children: ReactNode }) {
  const [menu, setMenu] = useState(false);
  const { items, notice, dismiss } = useCart();
  const pathname = useLocation({ select: (l) => l.pathname });
  const reduced = useReducedMotion();
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 140, damping: 30, mass: 0.3 });
  useEffect(() => {
    setMenu(false);
  }, [pathname]);
  useEffect(() => {
    if (!notice) return;
    const timer = setTimeout(dismiss, 5000);
    return () => clearTimeout(timer);
  }, [notice, dismiss]);
  useEffect(() => {
    if (!menu) return;
    const close = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setMenu(false);
        document.getElementById("menu-toggle")?.focus();
      }
    };
    document.addEventListener("keydown", close);
    return () => document.removeEventListener("keydown", close);
  }, [menu]);
  return (
    <>
      <motion.div className="scroll-progress" style={{ scaleX: progress }} aria-hidden="true" />
      <a href="#main" className="skip-link">
        Hoppa till innehållet
      </a>
      <div className="announcement">
        <span>En andra chans. Ett nytt kapitel.</span>
        <span>Hantverk & återbruk · Eskilstuna</span>
      </div>
      <header className="site-header">
        <Link className="wordmark" to="/" aria-label="RENOVA UF startsida">
          RENOVA<span>UF</span>
        </Link>
        <nav className="desktop-nav" aria-label="Huvudnavigation">
          {links.map((l) => (
            <Link key={l.to} to={l.to} activeProps={{ className: "active" }}>
              {l.label}
            </Link>
          ))}
        </nav>
        <div className="header-actions">
          <Link to="/varukorg" className="bag-link" aria-label={`Varukorg, ${items.length} möbler`}>
            <ShoppingBag size={19} strokeWidth={1.3} />
            <span className="bag-label">Varukorg</span>
            <span className="bag-count">{items.length}</span>
          </Link>
          <button
            className="icon-button menu-toggle"
            id="menu-toggle"
            aria-label={menu ? "Stäng meny" : "Öppna meny"}
            aria-expanded={menu}
            aria-controls="mobile-menu"
            onClick={() => setMenu(!menu)}
          >
            {menu ? <X /> : <Menu />}
          </button>
        </div>
        <AnimatePresence>
          {menu && (
            <motion.nav
              initial={reduced ? false : { opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mobile-menu"
              id="mobile-menu"
              aria-label="Mobilnavigation"
            >
              {links.map((l) => (
                <Link key={l.to} to={l.to} activeProps={{ className: "active" }}>
                  {l.label}
                </Link>
              ))}
              <p>Från gammalt till nytt.</p>
            </motion.nav>
          )}
        </AnimatePresence>
      </header>
      <main id="main" tabIndex={-1}>
        <motion.div
          key={pathname}
          initial={reduced ? false : { opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        >
          {children}
        </motion.div>
      </main>
      <footer className="site-footer">
        <div className="container">
          <Reveal>
            <div className="footer-top">
              <div>
                <span className="eyebrow">Det finns mer att upptäcka</span>
                <h2>
                  Låt historien
                  <br />
                  <em>fortsätta.</em>
                </h2>
              </div>
              <div className="footer-invitation">
                <p>
                  Gamla möbler. Nya möjligheter.
                  <br />
                  Följ arbetet bakom varje nytt kapitel.
                </p>
                <a
                  className="button button-light"
                  href="https://www.instagram.com/uf_renova/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Instagram size={18} /> Följ @uf_renova
                </a>
              </div>
            </div>
            <div className="footer-wordmark" aria-hidden="true">
              RENOVA<span>UF</span>
            </div>
          </Reveal>
          <div className="footer-bottom">
            <span>© {new Date().getFullYear()} RENOVA UF · Eskilstuna</span>
            <nav aria-label="Sidfotsnavigation">
              <Link to="/integritet">Integritet</Link>
              <Link to="/kopinformation">Köpinformation</Link>
              <Link to="/admin">Administration</Link>
            </nav>
            <div className="footer-meta">
              <span className="footer-school">JENSEN Gymnasium Eskilstuna</span>
              <span className="footer-credit">
                Site by{' '}
                <a href="https://www.elvastudio.org/" target="_blank" rel="noopener noreferrer">
                  ElvaStudio
                </a>
              </span>
            </div>
          </div>
        </div>
      </footer>
      <AnimatePresence>
        {notice && (
          <motion.div
            role="status"
            className="toast"
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <span>{notice}</span>
            <Link to="/varukorg">Visa varukorg</Link>
            <button aria-label="Stäng meddelande" onClick={dismiss}>
              <X size={18} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
