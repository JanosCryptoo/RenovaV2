import { useCallback, useEffect, useState, type FormEvent } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Check, Copy, CreditCard, KeyRound, ShieldCheck, Webhook, X } from "lucide-react";
import {
  getPaymentStatus as getPaymentStatusFn,
  savePaymentSettings as savePaymentSettingsFn,
  type PaymentStatus,
  type PaymentUpdate,
} from "../../lib/admin.functions";

type Update = PaymentUpdate;

/** Admin tab: connect the shop's own Stripe account. Keys go straight to the server and are never shown again. */
export default function PaymentsPanel() {
  const getStatus = useServerFn(getPaymentStatusFn);
  const save = useServerFn(savePaymentSettingsFn);
  const [status, setStatus] = useState<PaymentStatus | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [secretKey, setSecretKey] = useState("");
  const [webhook, setWebhook] = useState("");
  const [siteKey, setSiteKey] = useState("");
  const [turnstileSecret, setTurnstileSecret] = useState("");
  const [copied, setCopied] = useState(false);

  const load = useCallback(async () => {
    try {
      setStatus(await getStatus());
    } catch (e) {
      setError(e instanceof Error ? e.message : "Statusen kunde inte hämtas.");
    }
  }, [getStatus]);
  useEffect(() => {
    void load();
  }, [load]);

  const submit = async (data: Update, done: string, reset?: () => void) => {
    setBusy(true);
    setError("");
    setNotice("");
    try {
      setStatus(await save({ data }));
      reset?.();
      setNotice(done);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Något gick fel.");
      void load();
    } finally {
      setBusy(false);
    }
  };
  const onForm = (handler: () => void) => (event: FormEvent) => {
    event.preventDefault();
    handler();
  };

  if (!status)
    return (
      <section className="payments" aria-label="Betalningar">
        {error ? (
          <p className="admin-error">{error}</p>
        ) : (
          <p className="admin-caption">Hämtar status…</p>
        )}
      </section>
    );

  return (
    <section className="payments" aria-label="Betalningar">
      <div className="payments__summary" data-ready={status.ready}>
        <CreditCard size={26} strokeWidth={1.2} />
        <div>
          <h2>
            {status.ready
              ? "Kassan är öppen."
              : status.checkoutEnabled
                ? "Kassan väntar."
                : "Kassan är stängd."}
          </h2>
          <p>
            {status.ready
              ? status.stripe.mode === "live"
                ? "Kunder kan betala på riktigt med kort" + (status.swish ? " och Swish." : ".")
                : "Testläge: inga riktiga pengar dras. Använd Stripes testkort 4242 4242 4242 4242."
              : status.missing.length
                ? `Saknas innan kassan kan öppnas: ${status.missing.join(", ")}.`
                : "Allt är anslutet. Slå på kassan när ni är redo."}
          </p>
        </div>
      </div>
      {error && (
        <p className="admin-error" role="alert">
          {error}
        </p>
      )}
      {notice && (
        <p className="admin-success" role="status">
          <Check size={18} />
          {notice}
        </p>
      )}

      <div className="payments__grid">
        <article className="payments__card">
          <header>
            <KeyRound size={20} strokeWidth={1.4} />
            <h3>1. Stripe-nyckel</h3>
            <Badge
              on={status.stripe.connected}
              label={
                status.stripe.mode === "live"
                  ? "Live"
                  : status.stripe.mode === "test"
                    ? "Test"
                    : null
              }
            />
          </header>
          {status.stripe.connected ? (
            <p className="payments__current">
              Ansluten{status.stripe.account ? ` till ${status.stripe.account}` : ""} · nyckel{" "}
              {status.stripe.hint}
            </p>
          ) : (
            <p className="payments__help">
              I Stripe: <strong>Developers → API keys</strong>. Kopiera <em>Secret key</em> (börjar
              med sk_test_ för test eller sk_live_ för riktiga betalningar).
            </p>
          )}
          <form
            className="admin-form"
            onSubmit={onForm(
              () =>
                void submit({ stripeSecretKey: secretKey }, "Stripe är anslutet.", () =>
                  setSecretKey(""),
                ),
            )}
          >
            <label>
              {status.stripe.connected ? "Byt nyckel" : "Hemlig nyckel"}
              <input
                type="password"
                autoComplete="off"
                spellCheck={false}
                placeholder="sk_test_…"
                value={secretKey}
                onChange={(e) => setSecretKey(e.target.value)}
                required
              />
            </label>
            <div className="payments__actions">
              <button className="button" disabled={busy || !secretKey.trim()}>
                {busy ? "Kontrollerar…" : "Anslut Stripe"}
              </button>
              {status.stripe.fromAdmin && (
                <button
                  type="button"
                  className="admin-text-button"
                  disabled={busy}
                  onClick={() => void submit({ clear: "stripe" }, "Stripe-nyckeln är borttagen.")}
                >
                  Koppla från
                </button>
              )}
            </div>
          </form>
        </article>

        <article className="payments__card">
          <header>
            <Webhook size={20} strokeWidth={1.4} />
            <h3>2. Webhook</h3>
            <Badge on={status.webhook.connected} />
          </header>
          <p className="payments__help">
            I Stripe: <strong>Developers → Webhooks → Add endpoint</strong>. Klistra in adressen
            nedan och välj händelserna <em>checkout.session.completed</em>,{" "}
            <em>…async_payment_succeeded</em>, <em>…async_payment_failed</em> och <em>…expired</em>.
            Kopiera sedan <em>Signing secret</em>.
          </p>
          <div className="payments__copy">
            <code>{status.webhook.url}</code>
            <button
              type="button"
              className="admin-icon-button"
              aria-label="Kopiera webhook-adressen"
              onClick={() => {
                void navigator.clipboard.writeText(status.webhook.url);
                setCopied(true);
                setTimeout(() => setCopied(false), 1800);
              }}
            >
              {copied ? <Check size={16} /> : <Copy size={16} />}
            </button>
          </div>
          {status.webhook.connected && (
            <p className="payments__current">Sparad hemlighet {status.webhook.hint}</p>
          )}
          <form
            className="admin-form"
            onSubmit={onForm(
              () =>
                void submit({ webhookSecret: webhook }, "Webhooken är sparad.", () =>
                  setWebhook(""),
                ),
            )}
          >
            <label>
              Signing secret
              <input
                type="password"
                autoComplete="off"
                spellCheck={false}
                placeholder="whsec_…"
                value={webhook}
                onChange={(e) => setWebhook(e.target.value)}
                required
              />
            </label>
            <div className="payments__actions">
              <button className="button" disabled={busy || !webhook.trim()}>
                Spara webhook
              </button>
              {status.webhook.connected && (
                <button
                  type="button"
                  className="admin-text-button"
                  disabled={busy}
                  onClick={() =>
                    void submit({ clear: "webhook" }, "Webhook-hemligheten är borttagen.")
                  }
                >
                  Ta bort
                </button>
              )}
            </div>
          </form>
        </article>

        <article className="payments__card">
          <header>
            <ShieldCheck size={20} strokeWidth={1.4} />
            <h3>3. Spamskydd</h3>
            <Badge on={status.turnstile.connected} />
          </header>
          <p className="payments__help">
            Kassan och kontaktformuläret skyddas mot robotar med Cloudflare Turnstile. I Cloudflare:{" "}
            <strong>Turnstile → Add site</strong>, lägg till er webbadress och kopiera båda
            nycklarna.
          </p>
          {status.turnstile.connected && (
            <p className="payments__current">Ansluten · {status.turnstile.siteKey}</p>
          )}
          <form
            className="admin-form"
            onSubmit={onForm(
              () =>
                void submit(
                  { turnstileSiteKey: siteKey, turnstileSecretKey: turnstileSecret },
                  "Spamskyddet är sparat.",
                  () => {
                    setSiteKey("");
                    setTurnstileSecret("");
                  },
                ),
            )}
          >
            <label>
              Site key
              <input
                autoComplete="off"
                spellCheck={false}
                value={siteKey}
                onChange={(e) => setSiteKey(e.target.value)}
                required
              />
            </label>
            <label>
              Secret key
              <input
                type="password"
                autoComplete="off"
                spellCheck={false}
                value={turnstileSecret}
                onChange={(e) => setTurnstileSecret(e.target.value)}
                required
              />
            </label>
            <div className="payments__actions">
              <button
                className="button"
                disabled={busy || !siteKey.trim() || !turnstileSecret.trim()}
              >
                Spara spamskydd
              </button>
              {status.turnstile.connected && (
                <button
                  type="button"
                  className="admin-text-button"
                  disabled={busy}
                  onClick={() => void submit({ clear: "turnstile" }, "Spamskyddet är borttaget.")}
                >
                  Ta bort
                </button>
              )}
            </div>
          </form>
        </article>

        <article className="payments__card payments__card--switches">
          <header>
            <CreditCard size={20} strokeWidth={1.4} />
            <h3>4. Öppna kassan</h3>
          </header>
          {status.stripe.mode === "live" && (
            <label className="admin-checkbox">
              <input
                type="checkbox"
                checked={status.allowLive}
                disabled={busy}
                onChange={(e) =>
                  void submit(
                    { allowLive: e.target.checked },
                    e.target.checked
                      ? "Riktiga betalningar är godkända."
                      : "Riktiga betalningar är avstängda.",
                  )
                }
              />
              Jag godkänner riktiga betalningar med live-nyckeln.
            </label>
          )}
          <label className="admin-checkbox">
            <input
              type="checkbox"
              checked={status.swish}
              disabled={busy}
              onChange={(e) =>
                void submit(
                  { swish: e.target.checked },
                  e.target.checked ? "Swish erbjuds i kassan." : "Swish är avstängt.",
                )
              }
            />
            Erbjud Swish (måste vara aktiverat i ert Stripe-konto)
          </label>
          <label className="admin-checkbox payments__master">
            <input
              type="checkbox"
              checked={status.checkoutEnabled}
              disabled={busy}
              onChange={(e) =>
                void submit(
                  { checkoutEnabled: e.target.checked },
                  e.target.checked ? "Kassan är öppen." : "Kassan är stängd.",
                )
              }
            />
            Kassan är öppen för kunder
          </label>
          <p className="payments__help">
            Nycklarna sparas krypterat och visas aldrig igen — bara de fyra sista tecknen.
          </p>
        </article>
      </div>
    </section>
  );
}

function Badge({ on, label }: { on: boolean; label?: string | null }) {
  return (
    <span className="payments__badge" data-on={on}>
      {on ? <Check size={13} /> : <X size={13} />}
      {on ? (label ?? "Ansluten") : "Saknas"}
    </span>
  );
}
