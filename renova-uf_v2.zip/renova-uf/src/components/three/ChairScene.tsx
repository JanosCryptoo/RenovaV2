import {
  Component,
  Suspense,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
  type RefObject,
} from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Center, Environment, Lightformer, Sparkles, useGLTF } from "@react-three/drei";
import * as THREE from "three";
import { RotateCcw, ChevronLeft, ChevronRight } from "lucide-react";
import ChairGeometry from "./ChairGeometry";
import { createWoodMaterial, restorationProgress } from "./materials";

export type ChairSceneProps = {
  progress?: number;
  interactive?: boolean;
  className?: string;
  variant?: "hero" | "restoration" | "assembly";
  modelUrl?: string | undefined;
  /** Assembly variant only: 0 = assembled, 1 = exploded into parts. */
  explode?: number;
};
type Interaction = { rotation: number; pointerX: number; pointerY: number; dragging: boolean };

function Fallback({ failed = false, product = false }: { failed?: boolean; product?: boolean }) {
  return (
    <div className="chair-fallback">
      {product ? (
        <span className="chair-fallback__product">3D-visningen är inte tillgänglig.</span>
      ) : (
        <img src="/models/chair-fallback.svg" alt="Illustration av en skandinavisk trästol" />
      )}
      <p>
        {failed
          ? product
            ? "Du kan fortfarande se produktens fotografier."
            : "En stillbild visas eftersom 3D inte stöds i din webbläsare."
          : "Ljuset faller på plats…"}
      </p>
    </div>
  );
}

class SceneBoundary extends Component<
  { children: ReactNode; product: boolean; onFailure: () => void },
  { failed: boolean }
> {
  override state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  override componentDidCatch(error: Error) {
    console.warn("RENOVA 3D fallback:", error.message);
    this.props.onFailure();
  }
  override render() {
    return this.state.failed ? (
      <Fallback failed product={this.props.product} />
    ) : (
      this.props.children
    );
  }
}

function UploadedModel({ url }: { url: string }) {
  // Upload validation requires ordinary embedded GLB, avoiding runtime decoder/CDN requests.
  const model = useGLTF(url, false, false);
  const scene = useMemo(() => {
    const clone = model.scene.clone(true);
    clone.traverse((child) => {
      if (child instanceof THREE.Mesh) {
        child.castShadow = true;
        child.receiveShadow = true;
      }
    });
    const box = new THREE.Box3().setFromObject(clone),
      size = box.getSize(new THREE.Vector3());
    const scale = 2.9 / Math.max(size.y, size.x, size.z, 0.001);
    clone.scale.setScalar(scale);
    return clone;
  }, [model.scene]);
  return (
    <Center top>
      <primitive object={scene} />
    </Center>
  );
}

function Scene({
  progress,
  variant,
  interaction,
  reduced,
  visible,
  modelUrl,
  onReady,
  interactionVersion,
  explode,
}: {
  explode: number;
  progress: number;
  variant: string;
  interaction: RefObject<Interaction>;
  reduced: boolean;
  visible: boolean;
  modelUrl?: string | undefined;
  onReady: () => void;
  interactionVersion: number;
}) {
  const group = useRef<THREE.Group>(null),
    light = useRef<THREE.DirectionalLight>(null);
  const lowDetail = useMemo(() => matchMedia("(pointer: coarse)").matches, []);
  const wood = useMemo(() => createWoodMaterial(lowDetail ? 256 : 512), [lowDetail]);
  const elapsed = useRef(0),
    frameProgress = useRef(progress),
    entrance = useRef(reduced ? 1 : 0),
    explodeRef = useRef(explode);
  const { camera, invalidate } = useThree();
  const target = useMemo(() => new THREE.Vector3(), []);
  const lightColors = useMemo(() => [new THREE.Color("#f2f1eb"), new THREE.Color("#fff1db")], []);
  useEffect(() => {
    onReady();
    return () => wood.dispose();
  }, [wood, onReady]);
  useEffect(() => {
    wood.setProgress(progress);
    invalidate();
  }, [progress, wood, invalidate, reduced]);
  useEffect(() => {
    if (visible) invalidate();
  }, [visible, interactionVersion, invalidate]);
  useFrame((_state, delta) => {
    if (!visible) return;
    const dt = Math.min(delta, 0.05);
    elapsed.current += dt;
    const blend = reduced ? 1 : 1 - Math.exp(-dt * 5);
    frameProgress.current = THREE.MathUtils.lerp(frameProgress.current, progress, blend);
    const p = frameProgress.current;
    wood.setProgress(p);
    explodeRef.current = THREE.MathUtils.lerp(
      explodeRef.current,
      explode,
      reduced ? 1 : 1 - Math.exp(-dt * 6),
    );
    const ex = explodeRef.current;
    entrance.current = reduced ? 1 : Math.min(1, entrance.current + dt * 0.45);
    const intro = 1 - Math.pow(1 - entrance.current, 3);
    if (group.current) {
      const idle =
        reduced || interaction.current.dragging ? 0 : Math.sin(elapsed.current * 0.28) * 0.025;
      const heroScroll =
        variant === "hero" && !reduced
          ? Math.min(window.scrollY / Math.max(window.innerHeight, 1), 1.2)
          : 0;
      const turn =
        variant === "restoration"
          ? -0.36 + p * 0.64
          : variant === "assembly"
            ? -0.5 + ex * 1.1
            : heroScroll * 0.9;
      group.current.rotation.y = THREE.MathUtils.lerp(
        group.current.rotation.y,
        interaction.current.rotation +
          turn +
          (reduced ? 0 : interaction.current.pointerX * 0.1) +
          idle -
          (1 - intro) * 0.24,
        blend,
      );
      group.current.rotation.x = THREE.MathUtils.lerp(
        group.current.rotation.x,
        reduced ? 0 : interaction.current.pointerY * 0.022,
        blend,
      );
    }
    const scroll =
      variant === "hero" && !reduced
        ? Math.min(window.scrollY / Math.max(window.innerHeight, 1), 1)
        : 0;
    if (variant === "assembly") target.set(4.4 + ex * 1.2, 3.4 + ex * 0.9, 7.2 + ex * 2.2);
    else
      target.set(
        3.8 + (variant === "restoration" ? (1 - p) * 0.8 : scroll * 0.45),
        3.15 + scroll * 0.35,
        6.3 + (1 - intro) * 0.65 - (variant === "restoration" ? p * 0.2 : 0),
      );
    camera.position.lerp(target, reduced ? 1 : blend * 0.6);
    camera.lookAt(0, variant === "assembly" ? 1.7 : 1.5, 0);
    if (light.current) {
      light.current.intensity = (2.25 + p * 0.55) * (0.72 + intro * 0.28);
      light.current.color.lerpColors(lightColors[0]!, lightColors[1]!, p);
    }
  });
  return (
    <>
      <ambientLight intensity={0.8} color="#f9edda" />
      <directionalLight
        ref={light}
        position={[-3.5, 6, 4.5]}
        intensity={2.8}
        color="#fff1db"
        castShadow
        shadow-mapSize={[1024, 1024]}
        shadow-camera-left={-4}
        shadow-camera-right={4}
        shadow-camera-top={4}
        shadow-camera-bottom={-4}
        shadow-normalBias={0.025}
        shadow-bias={-0.0001}
        shadow-radius={4}
      />
      <directionalLight position={[5, 3, -2]} intensity={1.2} color="#f3dec3" />
      <directionalLight position={[-4, 2, -3]} intensity={0.45} color="#ffffff" />
      <Environment resolution={128}>
        <Lightformer
          form="rect"
          intensity={2.8}
          position={[-3, 3, 4]}
          rotation={[0, Math.PI / 4, 0]}
          scale={[3, 5, 1]}
        />
        <Lightformer
          form="rect"
          intensity={1.2}
          position={[5, 4, -2]}
          rotation={[0, -Math.PI / 2, 0]}
          scale={[4, 5, 1]}
        />
        <Lightformer
          form="rect"
          intensity={0.6}
          position={[0, 6, 0]}
          rotation={[Math.PI / 2, 0, 0]}
          scale={[6, 6, 1]}
        />
      </Environment>
      <group ref={group}>
        {modelUrl ? (
          <UploadedModel url={modelUrl} />
        ) : (
          <ChairGeometry
            material={wood.material}
            lowDetail={lowDetail}
            explode={variant === "assembly" ? explodeRef : undefined}
          />
        )}
      </group>
      {variant !== "restoration" && (
        // Drifting wood dust in the light — sand-toned, slowed to a stop for reduced motion.
        <Sparkles
          count={lowDetail ? 28 : 55}
          scale={[5, 3.6, 4]}
          position={[0, 1.9, 0]}
          size={variant === "assembly" ? 3 : 2.4}
          speed={reduced ? 0 : 0.25}
          opacity={0.75}
          noise={0.6}
          color="#d9b990"
        />
      )}
      <mesh receiveShadow rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.005, 0]}>
        <planeGeometry args={[200, 200]} />
        <shadowMaterial color="#38291e" opacity={0.17} transparent />
      </mesh>
    </>
  );
}

export default function ChairScene({
  progress = 1,
  interactive = true,
  className = "",
  variant = "hero",
  modelUrl,
  explode = 0,
}: ChairSceneProps) {
  const container = useRef<HTMLDivElement>(null),
    lastPointer = useRef(0);
  const interaction = useRef<Interaction>({
    rotation: 0,
    pointerX: 0,
    pointerY: 0,
    dragging: false,
  });
  const [supported, setSupported] = useState<boolean | null>(null),
    [visible, setVisible] = useState(false),
    [ready, setReady] = useState(false);
  const [reduced, setReduced] = useState(false),
    [contextLost, setContextLost] = useState(false);
  const [documentVisible, setDocumentVisible] = useState(true);
  const [interactionTick, setInteractionTick] = useState(0);
  const [coarse, setCoarse] = useState(false);
  const readyCallback = useMemo(() => () => setReady(true), []);
  useEffect(() => {
    const media = matchMedia("(prefers-reduced-motion: reduce)"),
      pointer = matchMedia("(pointer: coarse)");
    const update = () => {
      setReduced(media.matches);
      setCoarse(pointer.matches);
    };
    update();
    media.addEventListener("change", update);
    pointer.addEventListener("change", update);
    try {
      const canvas = document.createElement("canvas");
      const context = canvas.getContext("webgl2");
      setSupported(Boolean(context));
      context?.getExtension("WEBGL_lose_context")?.loseContext();
    } catch {
      setSupported(false);
    }
    return () => {
      media.removeEventListener("change", update);
      pointer.removeEventListener("change", update);
    };
  }, []);
  useEffect(() => {
    const update = () => setDocumentVisible(!document.hidden);
    document.addEventListener("visibilitychange", update);
    return () => document.removeEventListener("visibilitychange", update);
  }, []);
  useEffect(() => {
    if (!container.current) return;
    const observer = new IntersectionObserver(
      ([entry]) => setVisible(Boolean(entry?.isIntersecting)),
      {
        rootMargin: "80px",
      },
    );
    observer.observe(container.current);
    return () => observer.disconnect();
  }, []);
  const turn = (amount: number) => {
    interaction.current.rotation += amount;
    setInteractionTick((value) => value + 1);
  };
  return (
    <div
      className={`chair-scene chair-scene--${variant} ${className}`}
      ref={container}
      data-three-ready={ready}
      data-three-fallback={supported === false || contextLost}
      data-restoration-progress={Math.round(restorationProgress(progress) * 100)}
    >
      <div
        className="chair-scene__viewport"
        role="group"
        tabIndex={interactive ? 0 : undefined}
        aria-label={
          modelUrl
            ? "Interaktiv 3D-modell av produkten. Använd vänster och höger piltangent för att rotera."
            : "Illustrativ skandinavisk trästol i 3D. Dra i sidled eller använd vänster och höger piltangent för att rotera."
        }
        onKeyDown={(event) => {
          if (!interactive) return;
          if (event.key === "ArrowLeft") {
            event.preventDefault();
            turn(-0.2);
          }
          if (event.key === "ArrowRight") {
            event.preventDefault();
            turn(0.2);
          }
          if (event.key === "Home") {
            event.preventDefault();
            interaction.current.rotation = 0;
            setInteractionTick((v) => v + 1);
          }
        }}
        onPointerDown={(event) => {
          if (!interactive || event.button !== 0) return;
          interaction.current.dragging = true;
          lastPointer.current = event.clientX;
          event.currentTarget.setPointerCapture(event.pointerId);
        }}
        onPointerMove={(event) => {
          if (!interactive) return;
          if (interaction.current.dragging) {
            turn((event.clientX - lastPointer.current) * 0.009);
            lastPointer.current = event.clientX;
          } else {
            const rect = event.currentTarget.getBoundingClientRect();
            interaction.current.pointerX = (event.clientX - rect.left) / rect.width - 0.5;
            interaction.current.pointerY = (event.clientY - rect.top) / rect.height - 0.5;
          }
        }}
        onPointerUp={() => {
          interaction.current.dragging = false;
        }}
        onPointerCancel={() => {
          interaction.current.dragging = false;
        }}
        onPointerLeave={() => {
          interaction.current.pointerX = 0;
          interaction.current.pointerY = 0;
        }}
      >
        {supported === false || contextLost ? (
          <Fallback failed product={Boolean(modelUrl)} />
        ) : supported === null ? (
          <Fallback product={Boolean(modelUrl)} />
        ) : (
          <SceneBoundary
            key={modelUrl ?? "illustration"}
            product={Boolean(modelUrl)}
            onFailure={() => setContextLost(true)}
          >
            <Suspense fallback={<Fallback product={Boolean(modelUrl)} />}>
              <Canvas
                shadows
                dpr={coarse ? [1, 1.25] : [1, 1.5]}
                camera={{ position: [3.8, 3.15, 6.5], fov: 32, near: 0.1, far: 100 }}
                frameloop={visible && documentVisible ? (reduced ? "demand" : "always") : "never"}
                gl={{ antialias: !coarse, alpha: true, powerPreference: "low-power" }}
                onCreated={({ gl }) => {
                  gl.setClearColor(0x000000, 0);
                  gl.domElement.addEventListener(
                    "webglcontextlost",
                    (event) => {
                      event.preventDefault();
                      setContextLost(true);
                    },
                    { once: true },
                  );
                }}
              >
                <Scene
                  progress={restorationProgress(progress)}
                  variant={variant}
                  interaction={interaction}
                  reduced={reduced}
                  visible={visible && documentVisible}
                  modelUrl={modelUrl}
                  onReady={readyCallback}
                  interactionVersion={interactionTick}
                  explode={explode}
                />
              </Canvas>
            </Suspense>
          </SceneBoundary>
        )}
      </div>
      {interactive && supported && !contextLost && (
        <div
          className="chair-scene__tools"
          aria-label="Rotera möbeln"
          data-interactions={interactionTick}
        >
          <button type="button" aria-label="Vrid möbeln åt vänster" onClick={() => turn(-0.35)}>
            <ChevronLeft size={16} />
          </button>
          <span>Dra för att utforska</span>
          <button type="button" aria-label="Vrid möbeln åt höger" onClick={() => turn(0.35)}>
            <ChevronRight size={16} />
          </button>
          <button
            type="button"
            aria-label="Återställ möbelns vinkel"
            onClick={() => {
              interaction.current.rotation = 0;
              setInteractionTick((v) => v + 1);
            }}
          >
            <RotateCcw size={14} />
          </button>
        </div>
      )}
    </div>
  );
}
