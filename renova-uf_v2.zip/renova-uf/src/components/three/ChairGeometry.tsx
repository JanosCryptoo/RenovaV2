import { createContext, useContext, useEffect, useMemo, useRef, type ReactNode } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

/** 0 = assembled, 1 = fully exploded. Read every frame, so it lives in a ref, not React state. */
export type ExplodeRef = { current: number };
const ExplodeContext = createContext<ExplodeRef | null>(null);
const PIVOT = new THREE.Vector3(0, 1.45, 0);
const smooth = (edge0: number, edge1: number, x: number) => {
  const t = Math.min(1, Math.max(0, (x - edge0) / (edge1 - edge0)));
  return t * t * (3 - 2 * t);
};

/** Moves one chair part away from the chair centre (and spins it) as the explode value rises. */
function Part({
  center,
  order,
  children,
}: {
  center: THREE.Vector3;
  order: number;
  children: ReactNode;
}) {
  const explode = useContext(ExplodeContext);
  const outer = useRef<THREE.Group>(null);
  const { direction, spin } = useMemo(() => {
    const dir = center.clone().sub(PIVOT);
    dir.y *= 0.6;
    if (dir.lengthSq() < 0.04) dir.set(0, 1, 0.25);
    dir.normalize().multiplyScalar(1.35 + (order % 3) * 0.35);
    dir.y += 0.55;
    const seed =
      Math.sin((center.x + 1.3) * 12.9898 + (center.z + 2.1) * 78.233 + order) * 43758.5453;
    const r = seed - Math.floor(seed);
    return {
      direction: dir,
      spin: new THREE.Euler((r - 0.5) * 1.6, (r - 0.3) * 2.2, (0.5 - r) * 1.2),
    };
  }, [center, order]);
  useFrame(() => {
    if (!outer.current || !explode) return;
    // Later parts (higher order) settle last when assembling, so the chair builds from the floor up.
    const e = smooth(order * 0.07, order * 0.07 + 0.55, explode.current);
    outer.current.position.set(
      center.x + direction.x * e,
      center.y + direction.y * e,
      center.z + direction.z * e,
    );
    outer.current.rotation.set(spin.x * e, spin.y * e, spin.z * e);
  });
  if (!explode) return <>{children}</>;
  return (
    <group ref={outer} position={center}>
      <group position={[-center.x, -center.y, -center.z]}>{children}</group>
    </group>
  );
}

function roundedRectangle(width: number, height: number, radius: number) {
  const x = -width / 2,
    y = -height / 2,
    s = new THREE.Shape();
  s.moveTo(x + radius, y);
  s.lineTo(x + width - radius, y);
  s.quadraticCurveTo(x + width, y, x + width, y + radius);
  s.lineTo(x + width, y + height - radius);
  s.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  s.lineTo(x + radius, y + height);
  s.quadraticCurveTo(x, y + height, x, y + height - radius);
  s.lineTo(x, y + radius);
  s.quadraticCurveTo(x, y, x + radius, y);
  return s;
}

function sculptedSeat(lowDetail = false) {
  const shape = roundedRectangle(1.53, 1.37, 0.24);
  const geometry = new THREE.ExtrudeGeometry(shape, {
    depth: 0.085,
    bevelEnabled: true,
    bevelSize: 0.052,
    bevelThickness: 0.035,
    bevelSegments: lowDetail ? 2 : 3,
    curveSegments: lowDetail ? 10 : 20,
    steps: 2,
  });
  geometry.rotateX(-Math.PI / 2);
  const vertices = geometry.getAttribute("position");
  for (let i = 0; i < vertices.count; i++) {
    const x = vertices.getX(i),
      z = vertices.getZ(i);
    vertices.setY(i, vertices.getY(i) + 0.045 * (x * x + z * z));
  }
  geometry.computeVertexNormals();
  return geometry;
}

function curvedBack(lowDetail = false) {
  const geometry = new THREE.BoxGeometry(
    1.9,
    0.41,
    0.14,
    lowDetail ? 24 : 48,
    lowDetail ? 3 : 6,
    3,
  );
  const vertices = geometry.getAttribute("position");
  const core = new THREE.Vector3(),
    normal = new THREE.Vector3();
  for (let i = 0; i < vertices.count; i++) {
    const x = vertices.getX(i),
      y = vertices.getY(i),
      z = vertices.getZ(i);
    core.set(
      THREE.MathUtils.clamp(x, -0.9, 0.9),
      THREE.MathUtils.clamp(y, -0.155, 0.155),
      THREE.MathUtils.clamp(z, -0.02, 0.02),
    );
    normal.set(x, y, z).sub(core).normalize().multiplyScalar(0.05);
    const px = core.x + normal.x;
    vertices.setXYZ(i, px, core.y + normal.y - px * px * 0.09, core.z + normal.z + px * px * 0.32);
  }
  const uv = geometry.getAttribute("uv");
  for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getY(i), uv.getX(i));
  geometry.computeVertexNormals();
  return geometry;
}

function Beam({
  from,
  to,
  radiusTop,
  radiusBottom,
  material,
  order = 0,
}: {
  order?: number;
  from: [number, number, number];
  to: [number, number, number];
  radiusTop: number;
  radiusBottom: number;
  material: THREE.Material;
}) {
  const { middle, rotation, length } = useMemo(() => {
    const start = new THREE.Vector3(...from),
      end = new THREE.Vector3(...to);
    const delta = end.clone().sub(start);
    return {
      middle: start.clone().add(end).multiplyScalar(0.5),
      rotation: new THREE.Quaternion().setFromUnitVectors(
        new THREE.Vector3(0, 1, 0),
        delta.clone().normalize(),
      ),
      length: delta.length(),
    };
  }, [from, to]);
  return (
    <Part center={middle} order={order}>
      <mesh position={middle} quaternion={rotation} material={material} castShadow receiveShadow>
        <cylinderGeometry args={[radiusTop, radiusBottom, length, 12, 1]} />
      </mesh>
    </Part>
  );
}

/** An original procedural Scandinavian chair: all surfaces are actual 3D geometry. */
export default function ChairGeometry({
  material,
  lowDetail = false,
  explode,
}: {
  material: THREE.Material;
  lowDetail?: boolean;
  explode?: ExplodeRef | undefined;
}) {
  const seatCenter = useMemo(() => new THREE.Vector3(0, 1.6, 0.06), []),
    backCenter = useMemo(() => new THREE.Vector3(0, 2.86, -0.73), []);
  const seat = useMemo(() => sculptedSeat(lowDetail), [lowDetail]),
    back = useMemo(() => curvedBack(lowDetail), [lowDetail]);
  useEffect(
    () => () => {
      seat.dispose();
      back.dispose();
    },
    [seat, back],
  );
  return (
    <ExplodeContext.Provider value={explode ?? null}>
      <group>
        <Part center={seatCenter} order={6}>
          <mesh
            geometry={seat}
            material={material}
            position={[0, 1.56, 0.06]}
            castShadow
            receiveShadow
          />
        </Part>
        <Part center={backCenter} order={8}>
          <mesh
            geometry={back}
            material={material}
            position={[0, 2.86, -0.73]}
            rotation={[-0.12, 0, 0]}
            castShadow
            receiveShadow
          />
        </Part>
        {/* Tapered legs, continuous rear uprights, and pegged cross rails. */}
        <Beam
          order={0}
          from={[-0.79, 0.055, 0.75]}
          to={[-0.62, 1.58, 0.55]}
          radiusTop={0.085}
          radiusBottom={0.044}
          material={material}
        />
        <Beam
          order={0}
          from={[0.79, 0.055, 0.75]}
          to={[0.62, 1.58, 0.55]}
          radiusTop={0.085}
          radiusBottom={0.044}
          material={material}
        />
        <Beam
          order={1}
          from={[-0.8, 0.055, -0.76]}
          to={[-0.64, 1.6, -0.5]}
          radiusTop={0.08}
          radiusBottom={0.045}
          material={material}
        />
        <Beam
          order={1}
          from={[0.8, 0.055, -0.76]}
          to={[0.64, 1.6, -0.5]}
          radiusTop={0.08}
          radiusBottom={0.045}
          material={material}
        />
        <Beam
          order={7}
          from={[-0.64, 1.48, -0.5]}
          to={[-0.67, 2.91, -0.55]}
          radiusTop={0.055}
          radiusBottom={0.075}
          material={material}
        />
        <Beam
          order={7}
          from={[0.64, 1.48, -0.5]}
          to={[0.67, 2.91, -0.55]}
          radiusTop={0.055}
          radiusBottom={0.075}
          material={material}
        />
        <Beam
          order={4}
          from={[-0.61, 1.41, 0.54]}
          to={[0.61, 1.41, 0.54]}
          radiusTop={0.065}
          radiusBottom={0.065}
          material={material}
        />
        <Beam
          order={4}
          from={[-0.61, 1.41, -0.5]}
          to={[0.61, 1.41, -0.5]}
          radiusTop={0.065}
          radiusBottom={0.065}
          material={material}
        />
        <Beam
          order={5}
          from={[-0.65, 1.41, -0.5]}
          to={[-0.65, 1.41, 0.54]}
          radiusTop={0.065}
          radiusBottom={0.065}
          material={material}
        />
        <Beam
          order={5}
          from={[0.65, 1.41, -0.5]}
          to={[0.65, 1.41, 0.54]}
          radiusTop={0.065}
          radiusBottom={0.065}
          material={material}
        />
        <Beam
          order={2}
          from={[-0.72, 0.6, -0.62]}
          to={[-0.72, 0.6, 0.64]}
          radiusTop={0.032}
          radiusBottom={0.032}
          material={material}
        />
        <Beam
          order={2}
          from={[0.72, 0.6, -0.62]}
          to={[0.72, 0.6, 0.64]}
          radiusTop={0.032}
          radiusBottom={0.032}
          material={material}
        />
        <Beam
          order={3}
          from={[-0.72, 0.61, -0.06]}
          to={[0.72, 0.61, -0.06]}
          radiusTop={0.032}
          radiusBottom={0.032}
          material={material}
        />
        {/* Two rounded lumbar slats make the construction legible from every angle. */}
        <Beam
          order={8}
          from={[-0.24, 1.63, -0.49]}
          to={[-0.25, 2.72, -0.66]}
          radiusTop={0.035}
          radiusBottom={0.045}
          material={material}
        />
        <Beam
          order={8}
          from={[0.24, 1.63, -0.49]}
          to={[0.25, 2.72, -0.66]}
          radiusTop={0.035}
          radiusBottom={0.045}
          material={material}
        />
      </group>
    </ExplodeContext.Provider>
  );
}
