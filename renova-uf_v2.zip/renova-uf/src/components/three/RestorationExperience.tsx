import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import ChairScene from './ChairScene';
import { restorationProgress } from './materials';

gsap.registerPlugin(ScrollTrigger);

export default function RestorationExperience({ compact = false }: { compact?: boolean }) {
  const section = useRef<HTMLElement>(null);
  const [progress, setProgress] = useState(0),
    [manual, setManual] = useState(false),
    [reduced, setReduced] = useState(false);
  useEffect(() => {
    const media = matchMedia('(prefers-reduced-motion: reduce)');
    const update = () => setReduced(media.matches);
    update();
    media.addEventListener('change', update);
    return () => media.removeEventListener('change', update);
  }, []);
  useEffect(() => {
    if (!section.current || reduced || manual) return;
    const state = { value: 0 };
    const small = matchMedia('(max-width: 640px)').matches;
    const animation = gsap.to(state, {
      value: 1,
      ease: 'none',
      scrollTrigger: {
        trigger: section.current,
        start: compact || small ? 'top 75%' : 'top 35%',
        end: compact || small ? 'bottom 65%' : 'bottom 85%',
        scrub: 0.65,
        invalidateOnRefresh: true,
      },
      onUpdate: () => setProgress(restorationProgress(state.value)),
    });
    return () => {
      animation.scrollTrigger?.kill();
      animation.kill();
    };
  }, [manual, reduced, compact]);
  return (
    <section
      ref={section}
      className={`restoration-experience ${compact ? 'restoration-experience--compact' : ''}`}
      aria-labelledby="restoration-heading"
    >
      <div className="restoration-experience__sticky">
        <div className="restoration-experience__copy">
          <span className="restoration-experience__eyebrow">ETT NYTT KAPITEL</span>
          <h2 id="restoration-heading">
            Se skillnaden<span>.</span>
          </h2>
          <p>Från slitet och bortglömt till förnyat och uppskattat.</p>
          <div className="restoration-experience__detail" aria-hidden="true">
            <span>
              {progress < 0.33
                ? 'Ytan berättar sin historia.'
                : progress < 0.75
                  ? 'Omsorg, lager för lager.'
                  : 'Karaktären får leva vidare.'}
            </span>
            <div className="restoration-experience__rule">
              <i style={{ transform: `scaleX(${progress})` }} />
            </div>
          </div>
          <p className="restoration-experience__note">
            Illustrativ 3D-modell. Visar principen för en förnyelse, inte en möbel till försäljning.
          </p>
        </div>
        <div className="restoration-experience__object">
          <div className="restoration-experience__state" aria-hidden="true">
            <span>FÖRE</span>
            <span>EFTER</span>
          </div>
          <ChairScene variant="restoration" progress={progress} />
          <div className="restoration-experience__control">
            <label htmlFor="restoration-progress">
              {reduced
                ? 'Välj yta i egen takt'
                : manual
                  ? 'Du styr förvandlingen'
                  : 'Scrolla och följ förvandlingen'}
            </label>
            <input
              id="restoration-progress"
              aria-label="Förvandling från sliten till förnyad möbel"
              type="range"
              min="0"
              max="100"
              step="1"
              value={Math.round(progress * 100)}
              aria-valuetext={`${Math.round(progress * 100)} procent förnyad`}
              onChange={(event) => {
                setManual(true);
                setProgress(Number(event.target.value) / 100);
              }}
            />
            <div className="restoration-experience__control-labels">
              <span>Sliten</span>
              <span>Förnyad</span>
            </div>
            {manual && !reduced && (
              <button type="button" onClick={() => setManual(false)}>
                Följ scrollningen igen
              </button>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
