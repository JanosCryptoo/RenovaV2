import * as THREE from 'three';

/** Clamp all externally controlled restoration progress before touching shaders. */
export const restorationProgress = (value: number) =>
  Number.isFinite(value) ? Math.max(0, Math.min(1, value)) : 0;

function grainTexture(worn: boolean, size: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = size;
  const context = canvas.getContext('2d');
  if (!context) throw new Error('Canvas textures are unavailable');
  const pixels = context.createImageData(size, size);
  // Deterministic, original grain. No downloaded assets or runtime CDN requests.
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = x / size,
        v = y / size;
      const bend = Math.sin(v * 6.283) * 0.038 + Math.sin(v * 18.85) * 0.008;
      const ring = Math.sin((u + bend) * 172 + Math.sin(v * 12.566) * 1.4);
      const fine = Math.sin((u + bend * 0.52) * 1650) * 0.04;
      const mottling = Math.sin(u * 31.416) * Math.sin(v * 18.85) * 0.055;
      const pore =
        Math.pow(Math.abs((Math.sin(x * 12.9898 + y * 78.233) * 43758.5453) % 1), 5) * 0.055;
      const shade = 1 + ring * 0.115 + fine + mottling - pore;
      const offset = (y * size + x) * 4;
      const base = worn ? [160, 145, 119] : [122, 75, 42];
      for (let channel = 0; channel < 3; channel++)
        pixels.data[offset + channel] = base[channel]! * shade;
      pixels.data[offset + 3] = 255;
    }
  }
  context.putImageData(pixels, 0, 0);
  if (worn) {
    for (let i = 0; i < 135; i++) {
      const x = (i * 137.507) % size,
        y = (i * 73.91) % size;
      context.strokeStyle = i % 3 === 0 ? 'rgba(65, 52, 37, 0.34)' : 'rgba(238, 225, 199, 0.44)';
      context.lineWidth = i % 7 === 0 ? 1.5 : 0.65;
      context.beginPath();
      context.moveTo(x, y);
      context.lineTo(x + 4 + (i % 13), y + 14 + (i % 47));
      context.stroke();
    }
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 4;
  return texture;
}

export function createWoodMaterial(size = 512) {
  const clean = grainTexture(false, size),
    worn = grainTexture(true, size);
  const progress = { value: 1 };
  const material = new THREE.MeshStandardMaterial({
    map: clean,
    roughness: 0.36,
    metalness: 0,
    bumpMap: clean,
    bumpScale: 0.006,
    envMapIntensity: 0.5,
  });
  material.onBeforeCompile = (shader) => {
    shader.uniforms['uRestoration'] = progress;
    shader.uniforms['uWornMap'] = { value: worn };
    shader.fragmentShader =
      'uniform float uRestoration;\nuniform sampler2D uWornMap;\n' + shader.fragmentShader;
    shader.fragmentShader = shader.fragmentShader.replace(
      '#include <map_fragment>',
      `
      #ifdef USE_MAP
        vec4 renewedWood = texture2D(map, vMapUv);
        vec4 agedWood = texture2D(uWornMap, vMapUv);
        diffuseColor *= mix(agedWood, renewedWood, uRestoration);
      #endif
    `,
    );
  };
  material.customProgramCacheKey = () => 'renova-restoration-v1';
  return {
    material,
    setProgress(value: number) {
      const p = restorationProgress(value);
      progress.value = p;
      material.roughness = THREE.MathUtils.lerp(0.94, 0.33, p);
      material.bumpScale = THREE.MathUtils.lerp(0.014, 0.006, p);
    },
    dispose() {
      material.dispose();
      clean.dispose();
      worn.dispose();
    },
  };
}
