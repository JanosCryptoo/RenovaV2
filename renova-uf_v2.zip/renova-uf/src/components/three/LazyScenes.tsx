import { lazy, Suspense, type ComponentProps } from 'react';
import { ClientOnly } from '@tanstack/react-router';

// WebGL/Three.js modules load only in the browser, after hydration.
const ChairSceneImpl = lazy(() => import('./ChairScene'));
const RestorationExperienceImpl = lazy(() => import('./RestorationExperience'));
const ChairAssemblyImpl = lazy(() => import('./ChairAssembly'));

export function ChairScene({
  fallback,
  ...props
}: ComponentProps<typeof ChairSceneImpl> & { fallback: React.ReactNode }) {
  return (
    <ClientOnly fallback={fallback}>
      <Suspense fallback={fallback}>
        <ChairSceneImpl {...props} />
      </Suspense>
    </ClientOnly>
  );
}

export function RestorationExperience({ fallback }: { fallback: React.ReactNode }) {
  return (
    <ClientOnly fallback={fallback}>
      <Suspense fallback={fallback}>
        <RestorationExperienceImpl />
      </Suspense>
    </ClientOnly>
  );
}

export function ChairAssembly({ fallback }: { fallback: React.ReactNode }) {
  return (
    <ClientOnly fallback={fallback}>
      <Suspense fallback={fallback}>
        <ChairAssemblyImpl />
      </Suspense>
    </ClientOnly>
  );
}
