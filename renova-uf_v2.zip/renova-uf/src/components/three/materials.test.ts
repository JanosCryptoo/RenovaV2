import { describe, expect, it } from 'vitest';
import { restorationProgress } from './materials';

describe('restoration material bounds', () => {
  it('supports reversible intermediate values without replacing the geometry', () => {
    expect([0, 0.2, 0.8, 1, 0.8, 0.2, 0].map(restorationProgress)).toEqual([
      0, 0.2, 0.8, 1, 0.8, 0.2, 0,
    ]);
  });
  it('prevents non-finite or out-of-bounds values from reaching the shader', () => {
    expect(restorationProgress(-5)).toBe(0);
    expect(restorationProgress(10)).toBe(1);
    expect(restorationProgress(NaN)).toBe(0);
    expect(restorationProgress(Infinity)).toBe(0);
  });
});
