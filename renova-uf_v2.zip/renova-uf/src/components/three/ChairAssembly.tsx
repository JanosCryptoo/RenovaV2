import { useEffect, useRef, useState } from "react";
import { gsap } from 'gsap';
import { ScrollTrigger } from "gsap/ScrollTrigger";
import ChairScene from "./ChairScene";

gsap.registerPlugin(ScrollTrigger);

const stages = [
  { at: 0, label: "Ben och stag", text: "Grunden ska stå stadigt." },
  { at: 0.35, label: "Sarg och sits", text: "Fogarna får nytt grepp." },
  { at: 0.7, label: "Ryggstöd", text: "Formen tar plats igen." },
  { at: 0.95, label: "Hel igen", text: "Redo för ett nytt kapitel." },
];

/** Scroll-driven exploded view: the illustrative chair assembles part by part as you scroll. */
export default function ChairAssembly() {
  const section = useRef<HTMLElement>(null);
  const [progress, setProgress] = useState(0);
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const media = matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReduced(media.matches);
    update();
    media.addEventListener("change", update);
    return () => media.removeEventListener("change", update);
  }, []);
  useEffect(() => {
    if (!section.current) return;
    if (reduced) {
      setProgress(1);
      return;
    }
    const state = { value: 0 };
    const small = matchMedia("(max-width: 640px)").matches;
    const animation = gsap.to(state, {
      value: 1,
      ease: "none",
      scrollTrigger: {
        trigger: section.current,
        start: small ? "top 70%" : "top 30%",
        end: small ? "bottom 75%" : "bottom 90%",
        scrub: 0.8,
        invalidateOnRefresh: true,
      },
      onUpdate: () => setProgress(state.value),
    });
    return () => {
      animation.scrollTrigger?.kill();
      animation.kill();
    };
  }, [reduced]);
  const active = stages.reduce((found, stage, index) => (progress >= stage.at ? index : found), 0);
  return (
    <section ref={section} className="assembly" aria-labelledby="assembly-heading">
      <div className="assembly__sticky">
        <div className="assembly__copy">
          <span className="assembly__eyebrow">DEL FÖR DEL</span>
          <h2 id="assembly-heading">
            Byggd för att <em>hålla.</em>
          </h2>
          <p>
            En bra möbel är summan av sina delar. Vi går igenom varje ben, fog och sarg — och låter
            det som håller få vara kvar.
          </p>
          <ol className="assembly__stages">
            {stages.map((stage, index) => (
              <li key={stage.label} data-active={index === active} data-done={index < active}>
                <span className="assembly__index">0{index + 1}</span>
                <span>
                  <strong>{stage.label}</strong>
                  <small>{stage.text}</small>
                </span>
              </li>
            ))}
          </ol>
          <p className="assembly__note">Illustrativ 3D-modell · inte en vara till försäljning</p>
        </div>
        <div className="assembly__object">
          <span className="assembly__counter" aria-hidden="true">
            {String(Math.round(progress * 100)).padStart(2, "0")}
            <small>%</small>
          </span>
          <ChairScene variant="assembly" explode={1 - progress} />
        </div>
      </div>
    </section>
  );
}
