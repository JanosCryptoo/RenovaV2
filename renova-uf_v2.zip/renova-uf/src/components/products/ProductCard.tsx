import { Link } from "@tanstack/react-router";
import { Plus, Armchair } from "lucide-react";
import type { Product } from "../../types";
import { formatPrice, safeImageUrl } from "../../lib/format";
import { useCart } from "../CartProvider";
export default function ProductCard({ product }: { product: Product }) {
  const { add } = useCart();
  const image = safeImageUrl(product.product_images[0]?.image_url);
  const available = product.stock > 0 && product.availability === "available";
  return (
    <article
      className="product-card"
      onPointerMove={(event) => {
        if (event.pointerType !== "mouse") return;
        const el = event.currentTarget;
        const rect = el.getBoundingClientRect();
        el.style.setProperty(
          "--tilt-x",
          `${((event.clientY - rect.top) / rect.height - 0.5) * -7}deg`,
        );
        el.style.setProperty(
          "--tilt-y",
          `${((event.clientX - rect.left) / rect.width - 0.5) * 9}deg`,
        );
        el.style.setProperty("--glare-x", `${((event.clientX - rect.left) / rect.width) * 100}%`);
      }}
      onPointerLeave={(event) => {
        event.currentTarget.style.setProperty("--tilt-x", "0deg");
        event.currentTarget.style.setProperty("--tilt-y", "0deg");
      }}
    >
      <Link to="/mobler/$id" params={{ id: product.id }} className="product-image">
        {image ? (
          <img src={image} alt={product.name} loading="lazy" />
        ) : (
          <div className="product-no-image">
            <Armchair size={62} strokeWidth={0.8} />
            <span>Fotografi kommer</span>
          </div>
        )}
        <span className="product-tag">
          {available
            ? "Ett unikt exemplar"
            : product.availability === "reserved"
              ? "Reserverad"
              : "Såld"}
        </span>
      </Link>
      <div className="product-info">
        <div>
          <span className="eyebrow">{product.category}</span>
          <Link to="/mobler/$id" params={{ id: product.id }}>
            <h3>{product.name}</h3>
          </Link>
          <span>{formatPrice(product.price)}</span>
        </div>
        <button
          className="product-add icon-button"
          aria-label={`Lägg ${product.name} i varukorgen`}
          disabled={!available}
          onClick={() => add(product)}
        >
          <Plus size={22} />
        </button>
      </div>
    </article>
  );
}
