import { Link } from '@tanstack/react-router';
import { Armchair } from 'lucide-react';
export default function EmptyCatalog({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`empty-catalog ${compact ? 'compact' : ''}`}>
      <div className="empty-art" aria-hidden="true">
        <span className="empty-circle" />
        <Armchair strokeWidth={0.65} />
      </div>
      <div>
        <span className="eyebrow">Nästa kapitel är på väg</span>
        <h3>
          Gammal själ.
          <br />
          <em>Snart ett nytt hem.</em>
        </h3>
        <p>
          Här samlar vi möblerna som är redo att leva vidare. Just nu finns inga publicerade möbler.
          Följ vårt arbete på Instagram eller hör av dig till oss.
        </p>
        <Link to="/kontakt" className="text-link">
          Håll kontakten
        </Link>
      </div>
    </div>
  );
}
