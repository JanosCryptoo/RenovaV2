export type TeamMember = { name: string; role: string; photo: string };

/** The RENOVA UF team as given by the company. */
export const TEAM: TeamMember[] = [
  { name: 'Georgik Bahni', role: 'Ekonomiansvarig', photo: '/media/team/georgik_bahni.jpg' },
  { name: 'Helin Shukri', role: 'VD', photo: '/media/team/helin_shukri.jpg' },
  { name: 'Lianna Gharibyan', role: 'Marknadsföring', photo: '/media/team/lianna_gharibyan.jpg' },
];
