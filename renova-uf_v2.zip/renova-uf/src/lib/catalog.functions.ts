import { createServerFn } from '@tanstack/react-start';
import { queryOptions } from '@tanstack/react-query';
import { createClient } from '@supabase/supabase-js';
import type { Database } from '@/integrations/supabase/types';
import type { CompanyImage, Product, Restoration } from '../types';

/** Public read-only client: anonymous role, RLS shows published rows only. */
function publicDb() {
  const url = process.env['SUPABASE_URL']!;
  const key = process.env['SUPABASE_PUBLISHABLE_KEY']!;
  return createClient<Database>(url, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (key.startsWith('sb_') && h.get('Authorization') === `Bearer ${key}`) h.delete('Authorization');
        h.set('apikey', key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
}

function sortImages(product: Product): Product {
  return {
    ...product,
    product_images: [...(product.product_images ?? [])].sort((a, b) => a.sort_order - b.sort_order),
  };
}

export const getPublishedProducts = createServerFn({ method: 'GET' }).handler(
  async (): Promise<{ products: Product[]; error: string | null }> => {
    const { data, error } = await publicDb()
      .from('products')
      .select('*, product_images(*)')
      .eq('published', true)
      .order('created_at', { ascending: false });
    if (error) {
      console.error(JSON.stringify({ event: 'catalog_failure' }));
      return { products: [], error: 'Vi kunde inte hämta möblerna. Försök igen om en stund.' };
    }
    return { products: (data as unknown as Product[]).map(sortImages), error: null };
  },
);

export const getPublishedProduct = createServerFn({ method: 'GET' })
  .inputValidator((input: { id: string }) => ({ id: String(input.id) }))
  .handler(async ({ data }): Promise<{ product: Product | null; error: string | null }> => {
    if (!/^[0-9a-f-]{36}$/i.test(data.id)) return { product: null, error: null };
    const { data: row, error } = await publicDb()
      .from('products')
      .select('*, product_images(*)')
      .eq('id', data.id)
      .eq('published', true)
      .maybeSingle();
    if (error) return { product: null, error: 'Möbeln kunde inte hämtas just nu. Försök igen senare.' };
    return { product: row ? sortImages(row as unknown as Product) : null, error: null };
  });

export const getPublishedRestorations = createServerFn({ method: 'GET' }).handler(
  async (): Promise<{ items: Restoration[]; error: boolean }> => {
    const { data, error } = await publicDb()
      .from('restorations')
      .select('id,product_id,title,description,before_image_url,after_image_url,published')
      .eq('published', true)
      .order('created_at', { ascending: true });
    if (error) return { items: [], error: true };
    return { items: data as Restoration[], error: false };
  },
);

export const getPublishedCompanyImages = createServerFn({ method: 'GET' }).handler(
  async (): Promise<CompanyImage[]> => {
    const { data, error } = await publicDb()
      .from('company_images')
      .select('*')
      .eq('published', true)
      .order('sort_order');
    if (error) return [];
    return data as CompanyImage[];
  },
);

export const productsQuery = () =>
  queryOptions({ queryKey: ['catalog', 'products'], queryFn: () => getPublishedProducts() });
export const productQuery = (id: string) =>
  queryOptions({ queryKey: ['catalog', 'product', id], queryFn: () => getPublishedProduct({ data: { id } }) });
export const restorationsQuery = () =>
  queryOptions({ queryKey: ['catalog', 'restorations'], queryFn: () => getPublishedRestorations() });
export const companyImagesQuery = () =>
  queryOptions({ queryKey: ['catalog', 'company-images'], queryFn: () => getPublishedCompanyImages() });
