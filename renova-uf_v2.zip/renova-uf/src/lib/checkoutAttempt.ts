import type { CartItem } from '../types';
export type CheckoutAttempt = {
  id: string;
  signature: string;
  createdAt: number;
  items: CartItem[];
  customer: { name: string; email: string };
};
export const CHECKOUT_ATTEMPT_KEY = 'renova-checkout-attempt-v1';
export function restoreAttempt(value: string | null, now = Date.now()): CheckoutAttempt | null {
  try {
    const a = JSON.parse(value || 'null');
    if (
      !a ||
      !/^[a-f0-9-]{36}$/i.test(a.id) ||
      !Number.isFinite(a.createdAt) ||
      now - a.createdAt > 45 * 60 * 1000 ||
      a.createdAt > now ||
      !Array.isArray(a.items) ||
      a.items.length > 20 ||
      !a.customer ||
      typeof a.customer.name !== 'string' ||
      typeof a.customer.email !== 'string' ||
      a.customer.name.length > 120 ||
      a.customer.email.length > 254 ||
      typeof a.signature !== 'string'
    )
      return null;
    if (
      a.items.some(
        (i: CartItem) =>
          !i ||
          typeof i.productId !== 'string' ||
          !Number.isInteger(i.quantity) ||
          i.quantity < 1 ||
          i.quantity > 10,
      )
    )
      return null;
    if (a.signature !== JSON.stringify({ items: a.items, customer: a.customer })) return null;
    return a;
  } catch {
    return null;
  }
}
export function readAttempt() {
  try {
    return restoreAttempt(sessionStorage.getItem(CHECKOUT_ATTEMPT_KEY));
  } catch {
    return null;
  }
}
export function saveAttempt(a: CheckoutAttempt | null) {
  try {
    if (a) sessionStorage.setItem(CHECKOUT_ATTEMPT_KEY, JSON.stringify(a));
    else sessionStorage.removeItem(CHECKOUT_ATTEMPT_KEY);
  } catch {
    /* A private browser may disable session storage. */
  }
}
