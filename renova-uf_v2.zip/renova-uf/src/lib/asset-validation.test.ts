import { describe, expect, it } from 'vitest';
import { validateAsset } from './asset-validation';

function glb(document: object) {
  const json = new TextEncoder().encode(JSON.stringify(document));
  const padded = Math.ceil(json.length / 4) * 4;
  const bytes = new Uint8Array(20 + padded);
  const view = new DataView(bytes.buffer);
  bytes.set(new TextEncoder().encode('glTF'));
  view.setUint32(4, 2, true);
  view.setUint32(8, bytes.length, true);
  view.setUint32(12, padded, true);
  view.setUint32(16, 0x4e4f534a, true);
  bytes.fill(32, 20);
  bytes.set(json, 20);
  return bytes;
}

describe('admin upload validation', () => {
  it('rejects SVG disguised as a JPEG', () => {
    expect(() =>
      validateAsset(new TextEncoder().encode('<svg><script>alert(1)</script></svg>'), 'image'),
    ).toThrow('JPEG');
  });
  it('accepts real PNG headers regardless of file name', () => {
    expect(validateAsset(new Uint8Array([137, 80, 78, 71, 13, 10, 26, 10, 0]), 'image')).toEqual({
      bucket: 'furniture-images',
      extension: 'png',
      mime: 'image/png',
    });
  });
  it('rejects empty images and images over 8 MB', () => {
    expect(() => validateAsset(new Uint8Array(0), 'image')).toThrow('1 byte');
    expect(() => validateAsset(new Uint8Array(8 * 1024 * 1024 + 1), 'image')).toThrow('8 MB');
  });
  it('rejects models with external resources or compression codecs', () => {
    expect(() =>
      validateAsset(glb({ asset: { version: '2.0' }, images: [{ uri: 'https://x.test/t.jpg' }] }), 'model'),
    ).toThrow('samma GLB-fil');
    expect(() =>
      validateAsset(
        glb({ asset: { version: '2.0' }, extensionsRequired: ['KHR_draco_mesh_compression'] }),
        'model',
      ),
    ).toThrow('Draco');
  });
  it('accepts self-contained GLB 2.0 models', () => {
    expect(validateAsset(glb({ asset: { version: '2.0' }, buffers: [{ byteLength: 0 }] }), 'model')).toEqual({
      bucket: 'furniture-models',
      extension: 'glb',
      mime: 'model/gltf-binary',
    });
  });
});
