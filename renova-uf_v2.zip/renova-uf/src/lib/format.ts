export function formatPrice(ore: number) {
  return new Intl.NumberFormat('sv-SE', {
    style: 'currency',
    currency: 'SEK',
    maximumFractionDigits: ore % 100 === 0 ? 0 : 2,
  }).format(ore / 100);
}

/**
 * Only render https URLs or this app's own media route. Pure (no window access),
 * so the server-rendered HTML and the first browser render always match.
 */
export function safeImageUrl(value?: string | null): string | undefined {
  if (!value) return undefined;
  if (value.startsWith('/api/public/media/') && !value.includes('..')) return value;
  try {
    const url = new URL(value);
    return url.protocol === 'https:' ? url.href : undefined;
  } catch {
    return undefined;
  }
}
