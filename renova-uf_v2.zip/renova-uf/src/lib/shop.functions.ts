import { createServerFn } from '@tanstack/react-start';
import { queryOptions } from '@tanstack/react-query';
import {
  ApiError,
  checkoutReady,
  contactReady,
  emailField,
  record,
  textField,
  uuid,
  validateCheckout,
  type ReservedOrder,
} from './shop-rules';
import {
  adminDb,
  guarded,
  orderToken,
  readEnv,
  sha256,
  siteOrigin,
  stripeClient,
  verifyHuman,
  verifyOrderToken,
} from './renova.server';

export type Capabilities = {
  checkoutEnabled: boolean;
  contactEnabled: boolean;
  turnstileSiteKey: string | null;
};

/** Public capability probe (was /api/config). Reports conservatively; never exposes secrets. */
export const getCapabilities = createServerFn({ method: 'GET' }).handler(async (): Promise<Capabilities> => {
  const env = await readEnv();
  const contact = contactReady(env);
  return {
    checkoutEnabled: checkoutReady(env),
    contactEnabled: contact,
    turnstileSiteKey: contact ? (env.TURNSTILE_SITE_KEY ?? null) : null,
  };
});
export const capabilitiesQuery = () =>
  queryOptions({ queryKey: ['capabilities'], queryFn: () => getCapabilities(), staleTime: 60_000 });

export const sendContact = createServerFn({ method: 'POST' })
  .inputValidator((input: unknown) => record(input))
  .handler(async ({ data: body }) =>
    guarded('contact', async () => {
      const env = await readEnv();
      if (!contactReady(env))
        throw new ApiError(503, 'Kontaktformuläret är inte aktiverat ännu. Kontakta oss via Instagram.');
      const name = textField(body['name'], 2, 120);
      const email = emailField(body['email']);
      const message = textField(body['message'], 10, 4000);
      if (body['website']) throw new ApiError(400, 'Meddelandet kunde inte skickas.');
      const product_id = body['product_id'] ? uuid(body['product_id']) : null;
      await verifyHuman(body['turnstileToken'], env);
      const db = await adminDb();
      const { error } = await db.from('contact_messages').insert({ name, email, message, product_id });
      if (error) throw new ApiError(503, 'Meddelandet kunde inte sparas. Försök igen senare.');
      return { ok: true, message: 'Tack! Ditt meddelande har sparats till RENOVA UF.' };
    }),
  );

export const createCheckout = createServerFn({ method: 'POST' })
  .inputValidator((input: unknown) => input)
  .handler(async ({ data }) =>
    guarded('checkout', async () => {
      const env = await readEnv();
      if (!checkoutReady(env)) throw new ApiError(503, 'Betalningar är inte aktiverade ännu.');
      const input = validateCheckout(data);
      await verifyHuman(input.turnstileToken, env);
      const db = await adminDb();
      const fingerprint = await sha256(JSON.stringify({ items: input.items, customer: input.customer }));
      const { data: reserved, error } = await db.rpc('reserve_order', {
        p_order_id: input.requestId,
        p_items: input.items,
        p_customer_name: input.customer.name,
        p_customer_email: input.customer.email,
        p_fingerprint: fingerprint,
      });
      if (error) {
        if (error.message.includes('OUT_OF_STOCK'))
          throw new ApiError(409, 'En möbel är redan såld eller reserverad. Uppdatera varukorgen.');
        if (error.message.includes('REQUEST_CONFLICT'))
          throw new ApiError(409, 'Varukorgen har ändrats. Börja om i kassan.');
        throw new ApiError(503, 'Beställningen kunde inte reserveras. Försök igen.');
      }
      const order = reserved as unknown as ReservedOrder;
      const stripe = stripeClient(env);
      const token = await orderToken(order.id, env);
      if (order.stripe_session_id) {
        const session = await stripe.checkout.sessions.retrieve(order.stripe_session_id);
        if (session.status === 'open' && session.url)
          return { url: session.url, orderId: order.id, statusToken: token };
        throw new ApiError(409, 'Den här betalningen har avslutats. Kontrollera din beställning.');
      }
      if (order.status !== 'creating') throw new ApiError(409, 'Den här beställningen har redan avslutats.');
      // Stable across retries. Never create a second Stripe Session for the same reservation.
      const expiresAt = Math.floor(new Date(order.created_at).getTime() / 1000) + 40 * 60;
      if (expiresAt < Math.floor(Date.now() / 1000) + 30 * 60 + 10)
        throw new ApiError(
          409,
          'Reservationen behöver kontrolleras av RENOVA UF. Kontakta oss innan du försöker igen.',
        );
      const resultUrl = `${siteOrigin(env)}/bestallning?orderId=${order.id}&token=${token}`;
      const session = await stripe.checkout.sessions.create(
        {
          mode: 'payment',
          locale: 'sv',
          client_reference_id: order.id,
          customer_email: order.customer_email,
          payment_method_types: env.STRIPE_ENABLE_SWISH === 'true' ? ['card', 'swish'] : ['card'],
          line_items: order.items.map((item) => ({
            quantity: item.quantity,
            price_data: { currency: 'sek', unit_amount: item.price, product_data: { name: item.name } },
          })),
          metadata: { order_id: order.id },
          payment_intent_data: { metadata: { order_id: order.id } },
          expires_at: expiresAt,
          success_url: `${resultUrl}&result=success`,
          cancel_url: `${resultUrl}&result=cancel`,
          custom_text: {
            submit: { message: 'Upphämtning i Eskilstuna efter överenskommelse med RENOVA UF.' },
          },
        },
        { idempotencyKey: `renova-checkout-${order.id}` },
      );
      if (!session.url) throw new ApiError(503, 'Betalningssidan kunde inte öppnas.');
      const { error: attachError } = await db.rpc('attach_checkout_session', {
        p_order_id: order.id,
        p_session_id: session.id,
      });
      if (attachError)
        // Do not release inventory on an ambiguous outcome; a retry or the webhook recovers it.
        throw new ApiError(
          503,
          'Betalningen förbereddes men kunde inte bekräftas. Försök igen med samma varukorg.',
        );
      return { url: session.url, orderId: order.id, statusToken: token };
    }),
  );

export const getOrderStatus = createServerFn({ method: 'GET' })
  .inputValidator((input: { orderId: string; token: string }) => ({
    orderId: String(input.orderId),
    token: String(input.token),
  }))
  .handler(async ({ data }) =>
    guarded('order-status', async () => {
      const env = await readEnv();
      const orderId = uuid(data.orderId);
      await verifyOrderToken(orderId, data.token, env);
      const db = await adminDb();
      const { data: row, error } = await db.from('orders').select('status,total').eq('id', orderId).maybeSingle();
      if (error) throw new ApiError(503, 'Beställningen kunde inte kontrolleras.');
      if (!row) throw new ApiError(404, 'Beställningen kunde inte hittas.');
      return { status: row.status, total: row.total, currency: 'sek' as const };
    }),
  );

export const cancelCheckout = createServerFn({ method: 'POST' })
  .inputValidator((input: { orderId: string; statusToken: string }) => ({
    orderId: String(input.orderId),
    statusToken: String(input.statusToken),
  }))
  .handler(async ({ data }) =>
    guarded('cancel', async () => {
      const env = await readEnv();
      const orderId = uuid(data.orderId);
      await verifyOrderToken(orderId, data.statusToken, env);
      const db = await adminDb();
      const { data: order, error } = await db
        .from('orders')
        .select('stripe_session_id,status')
        .eq('id', orderId)
        .maybeSingle();
      if (error || !order) throw new ApiError(404, 'Beställningen kunde inte hittas.');
      if (['paid', 'payment_pending'].includes(order.status))
        throw new ApiError(409, 'Betalningen behandlas eller är redan klar. Kontakta RENOVA UF.');
      if (['expired', 'failed', 'cancelled'].includes(order.status)) return { ok: true, status: order.status };
      if (!order.stripe_session_id) throw new ApiError(409, 'Reservationen behöver kontrolleras av RENOVA UF.');
      const stripe = stripeClient(env);
      let session = await stripe.checkout.sessions.retrieve(order.stripe_session_id);
      if (session.status === 'open') {
        try {
          session = await stripe.checkout.sessions.expire(session.id);
        } catch {
          session = await stripe.checkout.sessions.retrieve(session.id);
        }
      }
      // A concurrent successful payment wins. Never release from a browser's claim alone.
      if (session.status !== 'expired' || session.payment_status === 'paid')
        throw new ApiError(409, 'Betalningen behandlas eller är redan klar.');
      const { error: releaseError } = await db.rpc('apply_checkout_event', {
        p_event_id: `cancel:${session.id}`,
        p_order_id: orderId,
        p_session_id: session.id,
        p_action: 'expired',
        p_total: session.amount_total ?? -1,
        p_currency: session.currency ?? '',
        p_payment_reference: null as unknown as string,
      });
      if (releaseError) throw new ApiError(503, 'Reservationen kunde inte avslutas. Försök igen.');
      return { ok: true, status: 'expired' };
    }),
  );
