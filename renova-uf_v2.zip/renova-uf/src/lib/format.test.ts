import { describe, expect, it } from 'vitest';
import { formatPrice, safeImageUrl } from './format';

describe('formatting', () => {
  it('formats integer öre as Swedish kronor', () => {
    expect(formatPrice(125000).replace(/\s/g, ' ')).toBe('1 250 kr');
  });
  it('allows https and app media URLs but rejects scripts and plain http', () => {
    expect(safeImageUrl('https://example.com/a.jpg')).toBe('https://example.com/a.jpg');
    expect(safeImageUrl('/api/public/media/furniture-images/a/b.jpg')).toBe(
      '/api/public/media/furniture-images/a/b.jpg',
    );
    expect(safeImageUrl('javascript:alert(1)')).toBeUndefined();
    expect(safeImageUrl('http://example.com/a.jpg')).toBeUndefined();
    expect(safeImageUrl('/api/public/media/../secret')).toBeUndefined();
  });
});
