import { createServerFn } from "@tanstack/react-start";
import Stripe from "stripe";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { AssetError, validateAsset } from "./asset-validation";
import {
  ApiError,
  checkoutMissing,
  checkoutReady,
  keyHint,
  record,
  stripeKeyMode,
  turnstileKeyValid,
  uuid,
  webhookSecretValid,
} from "./shop-rules";
import { adminDb, assertAdmin, guarded, readEnv, siteOrigin, stripeClient } from "./renova.server";

/**
 * Admin-only upload. Re-checks the admin role and the file contents on the server,
 * then writes to private storage. Files are served through /api/public/media/.
 */
export const uploadAsset = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => {
    if (!(input instanceof FormData)) throw new Error("Välj en fil.");
    const file = input.get("file");
    const kind = input.get("kind");
    if (!(file instanceof File) || (kind !== "image" && kind !== "model"))
      throw new Error("Välj en fil.");
    return { file, kind };
  })
  .handler(async ({ data, context }) =>
    guarded("admin-upload", async () => {
      await assertAdmin(context.supabase, context.userId);
      if (data.file.size > 20 * 1024 * 1024 + 65536) throw new ApiError(413, "Filen är för stor.");
      const bytes = new Uint8Array(await data.file.arrayBuffer());
      let format;
      try {
        format = validateAsset(bytes, data.kind);
      } catch (error) {
        if (error instanceof AssetError) throw new ApiError(400, error.message);
        throw error;
      }
      const path = `${context.userId}/${crypto.randomUUID()}.${format.extension}`;
      const db = await adminDb();
      const { error } = await db.storage
        .from(format.bucket)
        .upload(path, bytes, { contentType: format.mime, cacheControl: "31536000", upsert: false });
      if (error) throw new ApiError(503, "Filen kunde inte sparas. Försök igen.");
      return { url: `/api/public/media/${format.bucket}/${path}` };
    }),
  );

/** Explicit admin-only recovery. Time alone is never evidence that Stripe cannot collect money. */
export const reconcileOrder = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => ({ orderId: uuid(record(input)["orderId"]) }))
  .handler(async ({ data, context }) =>
    guarded("admin-reconcile", async () => {
      await assertAdmin(context.supabase, context.userId);
      const env = await readEnv();
      const orderId = data.orderId;
      const db = await adminDb();
      const { data: order, error } = await db
        .from("orders")
        .select("id,total,status,stripe_session_id,created_at")
        .eq("id", orderId)
        .single();
      if (error) throw new ApiError(404, "Beställningen kunde inte hittas.");
      if (["paid", "expired", "failed", "cancelled"].includes(order.status))
        return { status: order.status, message: "Beställningen är redan avslutad." };
      const stripe = stripeClient(env);
      let session: Stripe.Checkout.Session | undefined;
      if (order.stripe_session_id)
        session = await stripe.checkout.sessions.retrieve(order.stripe_session_id);
      else {
        const created = Math.floor(new Date(order.created_at).getTime() / 1000);
        if (Date.now() / 1000 < created + 45 * 60)
          throw new ApiError(
            409,
            "Vänta minst 45 minuter innan en ofullständig reservation frigörs.",
          );
        let starting_after: string | undefined;
        let finished = false;
        for (let page = 0; page < 20; page++) {
          const list = await stripe.checkout.sessions.list({
            created: { gte: created - 60, lte: created + 45 * 60 },
            limit: 100,
            ...(starting_after ? { starting_after } : {}),
          });
          const matches = list.data.filter(
            (c) => c.metadata?.["order_id"] === orderId && c.client_reference_id === orderId,
          );
          if (matches.length > 1 || (session && matches.length))
            throw new ApiError(
              409,
              "Flera betalningar hittades. Kontrollera dem i Stripe innan lagret ändras.",
            );
          if (matches[0]) session = matches[0];
          if (!list.has_more) {
            finished = true;
            break;
          }
          starting_after = list.data.at(-1)?.id;
          if (!starting_after) break;
        }
        if (!finished)
          throw new ApiError(
            503,
            "Betalningshistoriken kunde inte kontrolleras helt. Lagret är fortsatt reserverat.",
          );
        if (!session) {
          const { error: releaseError } = await db.rpc("release_unattached_order", {
            p_order_id: orderId,
          });
          if (releaseError)
            throw new ApiError(409, "Reservationen ändrades under kontrollen. Försök igen.");
          return {
            status: "cancelled",
            message: "Ingen betalning hittades i Stripe. Reservationen har frigjorts.",
          };
        }
        const { error: attachError } = await db.rpc("attach_checkout_session", {
          p_order_id: orderId,
          p_session_id: session.id,
        });
        if (attachError) throw new ApiError(409, "Betalningsreferensen kunde inte kopplas.");
      }
      if (session.status === "open" && session.expires_at <= Date.now() / 1000) {
        try {
          session = await stripe.checkout.sessions.expire(session.id);
        } catch {
          session = await stripe.checkout.sessions.retrieve(session.id);
        }
      }
      let action: "paid" | "expired" | "pending" | "failed" | undefined;
      const intentId =
        typeof session.payment_intent === "string"
          ? session.payment_intent
          : session.payment_intent?.id;
      if (session.payment_status === "paid") action = "paid";
      else if (session.status === "expired") action = "expired";
      else if (session.status === "complete") {
        action = "pending";
        // Failed delayed payments are released only after reading the authoritative PaymentIntent.
        if (intentId) {
          const intent = await stripe.paymentIntents.retrieve(intentId);
          if (intent.status === "canceled") action = "failed";
        }
      }
      if (action) {
        const { error: applyError } = await db.rpc("apply_checkout_event", {
          p_event_id: `reconcile:${session.id}:${action}`,
          p_order_id: orderId,
          p_session_id: session.id,
          p_action: action,
          p_total: session.amount_total ?? -1,
          p_currency: session.currency ?? "",
          p_payment_reference: (intentId ?? null) as unknown as string,
        });
        if (applyError)
          throw new ApiError(
            409,
            "Ordern kunde inte stämmas av. Kontrollera belopp och betalning i Stripe.",
          );
      }
      return {
        status: action === "pending" ? "payment_pending" : action || "reserved",
        message: "Reservationen har kontrollerats mot Stripe.",
      };
    }),
  );

export type PaymentStatus = {
  stripe: {
    connected: boolean;
    mode: "test" | "live" | null;
    hint: string | null;
    account: string | null;
    fromAdmin: boolean;
  };
  webhook: { connected: boolean; hint: string | null; url: string };
  turnstile: { connected: boolean; siteKey: string | null };
  checkoutEnabled: boolean;
  allowLive: boolean;
  swish: boolean;
  ready: boolean;
  missing: string[];
  updatedAt: string | null;
};

async function paymentStatus(): Promise<PaymentStatus> {
  const env = await readEnv();
  const { loadPaymentSettings } = await import("./payment-settings.server");
  const row = await loadPaymentSettings();
  const key = env.STRIPE_SECRET_KEY;
  const mode = key ? (key.includes("_live_") ? "live" : "test") : null;
  return {
    stripe: {
      connected: Boolean(key),
      mode,
      hint: key ? keyHint(key) : null,
      account: row?.stripe_account_name ?? null,
      fromAdmin: Boolean(row?.stripe_secret_key_enc),
    },
    webhook: {
      connected: Boolean(env.STRIPE_WEBHOOK_SECRET),
      hint: env.STRIPE_WEBHOOK_SECRET ? keyHint(env.STRIPE_WEBHOOK_SECRET) : null,
      url: `${siteOrigin(env)}/api/public/stripe-webhook`,
    },
    turnstile: {
      connected: Boolean(env.TURNSTILE_SECRET_KEY && env.TURNSTILE_SITE_KEY),
      siteKey: env.TURNSTILE_SITE_KEY ?? null,
    },
    checkoutEnabled: env.CHECKOUT_ENABLED === "true",
    allowLive: env.ALLOW_LIVE_PAYMENTS === "true",
    swish: env.STRIPE_ENABLE_SWISH === "true",
    ready: checkoutReady(env),
    missing: checkoutMissing(env),
    updatedAt: row?.updated_at ?? null,
  };
}

/** Admin-only. Reports what is connected; secrets are never returned, only their last four characters. */
export const getPaymentStatus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) =>
    guarded("admin-payment-status", async () => {
      await assertAdmin(context.supabase, context.userId);
      return paymentStatus();
    }),
  );

export type PaymentUpdate = {
  stripeSecretKey?: string;
  webhookSecret?: string;
  turnstileSiteKey?: string;
  turnstileSecretKey?: string;
  checkoutEnabled?: boolean;
  allowLive?: boolean;
  swish?: boolean;
  clear?: "stripe" | "webhook" | "turnstile";
};

/** Admin-only. Verifies a Stripe key against Stripe before storing it encrypted. */
export const savePaymentSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown): PaymentUpdate => {
    const body = record(input);
    const out: PaymentUpdate = {};
    const text = (k: string) =>
      typeof body[k] === "string" && (body[k] as string).trim()
        ? (body[k] as string).trim()
        : undefined;
    const flag = (k: string) => (typeof body[k] === "boolean" ? (body[k] as boolean) : undefined);
    const sk = text("stripeSecretKey"),
      wh = text("webhookSecret"),
      ts = text("turnstileSiteKey"),
      tk = text("turnstileSecretKey");
    if (sk) out.stripeSecretKey = sk;
    if (wh) out.webhookSecret = wh;
    if (ts) out.turnstileSiteKey = ts;
    if (tk) out.turnstileSecretKey = tk;
    const ce = flag("checkoutEnabled"),
      al = flag("allowLive"),
      sw = flag("swish");
    if (ce !== undefined) out.checkoutEnabled = ce;
    if (al !== undefined) out.allowLive = al;
    if (sw !== undefined) out.swish = sw;
    if (body["clear"] === "stripe" || body["clear"] === "webhook" || body["clear"] === "turnstile")
      out.clear = body["clear"];
    return out;
  })
  .handler(async ({ data, context }) =>
    guarded("admin-payment-save", async () => {
      await assertAdmin(context.supabase, context.userId);
      const { encryptSecret } = await import("./payment-settings.server");
      const patch: Record<string, unknown> = {
        updated_at: new Date().toISOString(),
        updated_by: context.userId,
      };
      if (data.stripeSecretKey) {
        const mode = stripeKeyMode(data.stripeSecretKey);
        let account: string | null = null;
        try {
          const stripe = new Stripe(data.stripeSecretKey, {
            httpClient: Stripe.createFetchHttpClient(),
          });
          const me = await stripe.accounts.retrieve();
          account =
            me.settings?.dashboard?.display_name || me.business_profile?.name || me.email || me.id;
        } catch (error) {
          if (error instanceof Stripe.errors.StripeAuthenticationError)
            throw new ApiError(
              400,
              "Stripe godkände inte nyckeln. Kopiera den igen från Stripe och försök på nytt.",
            );
          if (!(error instanceof Stripe.errors.StripePermissionError))
            throw new ApiError(503, "Stripe kunde inte nås just nu. Försök igen om en stund.");
          // Restricted keys may lack account read access; the key itself authenticated.
        }
        patch["stripe_secret_key_enc"] = await encryptSecret(data.stripeSecretKey);
        patch["stripe_key_mode"] = mode;
        patch["stripe_key_hint"] = keyHint(data.stripeSecretKey);
        patch["stripe_account_name"] = account ? account.slice(0, 120) : null;
        // A new key never inherits an earlier approval to take real money.
        patch["allow_live_payments"] = false;
        if (mode === "live") patch["checkout_enabled"] = false;
      }
      if (data.webhookSecret) {
        const secret = webhookSecretValid(data.webhookSecret);
        patch["stripe_webhook_secret_enc"] = await encryptSecret(secret);
        patch["stripe_webhook_hint"] = keyHint(secret);
      }
      if (data.turnstileSiteKey || data.turnstileSecretKey) {
        if (!data.turnstileSiteKey || !data.turnstileSecretKey)
          throw new ApiError(
            400,
            "Fyll i både webbplatsnyckeln och den hemliga nyckeln för spamskyddet.",
          );
        patch["turnstile_site_key"] = turnstileKeyValid(data.turnstileSiteKey, "webbplatsnyckeln");
        patch["turnstile_secret_key_enc"] = await encryptSecret(
          turnstileKeyValid(data.turnstileSecretKey, "den hemliga nyckeln"),
        );
      }
      if (data.clear === "stripe")
        Object.assign(patch, {
          stripe_secret_key_enc: null,
          stripe_key_mode: null,
          stripe_key_hint: null,
          stripe_account_name: null,
          checkout_enabled: false,
          allow_live_payments: false,
        });
      if (data.clear === "webhook")
        Object.assign(patch, {
          stripe_webhook_secret_enc: null,
          stripe_webhook_hint: null,
          checkout_enabled: false,
        });
      if (data.clear === "turnstile")
        Object.assign(patch, {
          turnstile_site_key: null,
          turnstile_secret_key_enc: null,
          checkout_enabled: false,
        });
      if (data.allowLive !== undefined) patch["allow_live_payments"] = data.allowLive;
      if (data.swish !== undefined) patch["enable_swish"] = data.swish;
      if (data.checkoutEnabled !== undefined) patch["checkout_enabled"] = data.checkoutEnabled;
      const db = await adminDb();
      const { error } = await db.from("payment_settings").upsert({ id: 1, ...patch });
      if (error) throw new ApiError(503, "Inställningarna kunde inte sparas. Försök igen.");
      const status = await paymentStatus();
      if (data.checkoutEnabled && !status.ready) {
        await db.from("payment_settings").update({ checkout_enabled: false }).eq("id", 1);
        throw new ApiError(409, `Kassan kan inte öppnas än. Saknas: ${status.missing.join(", ")}.`);
      }
      return status;
    }),
  );
