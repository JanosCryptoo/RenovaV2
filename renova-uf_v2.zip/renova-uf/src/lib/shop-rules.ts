/** Pure business rules shared by server code and tests. No env or network access here. */

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}

export type ShopEnv = {
  STRIPE_SECRET_KEY: string | undefined;
  STRIPE_WEBHOOK_SECRET: string | undefined;
  ORDER_TOKEN_SECRET: string | undefined;
  SITE_URL: string | undefined;
  CHECKOUT_ENABLED: string | undefined;
  ALLOW_LIVE_PAYMENTS: string | undefined;
  STRIPE_ENABLE_SWISH: string | undefined;
  TURNSTILE_SECRET_KEY: string | undefined;
  TURNSTILE_SITE_KEY: string | undefined;
};

/** Contact form opens only when the human check (Turnstile) is fully configured. */
export function contactReady(env: ShopEnv): boolean {
  return Boolean(env.TURNSTILE_SECRET_KEY && env.TURNSTILE_SITE_KEY);
}

/**
 * Checkout opens only when explicitly enabled, with webhook + order-link secrets,
 * a Stripe test key, or a live key *and* the extra ALLOW_LIVE_PAYMENTS guard.
 */
export function checkoutReady(env: ShopEnv): boolean {
  return Boolean(
    contactReady(env) &&
    env.CHECKOUT_ENABLED === "true" &&
    env.STRIPE_WEBHOOK_SECRET &&
    env.ORDER_TOKEN_SECRET &&
    env.ORDER_TOKEN_SECRET.length >= 32 &&
    (env.STRIPE_SECRET_KEY?.startsWith("sk_test_") ||
      (env.STRIPE_SECRET_KEY?.startsWith("sk_live_") && env.ALLOW_LIVE_PAYMENTS === "true")),
  );
}

/** What is still missing before checkout can open — shown to admins as a checklist. */
export function checkoutMissing(env: ShopEnv): string[] {
  const missing: string[] = [];
  const key = env.STRIPE_SECRET_KEY;
  if (!key) missing.push("Stripe hemlig nyckel");
  else if (key.startsWith("sk_live_") && env.ALLOW_LIVE_PAYMENTS !== "true")
    missing.push("Godkännande av riktiga betalningar");
  if (!env.STRIPE_WEBHOOK_SECRET) missing.push("Stripe webhook-hemlighet");
  if (!contactReady(env)) missing.push("Spamskydd (Turnstile)");
  if (!env.ORDER_TOKEN_SECRET || env.ORDER_TOKEN_SECRET.length < 32)
    missing.push("Säker orderlänk");
  return missing;
}

/**
 * Validates a pasted Stripe secret key. Only secret (sk_) or restricted (rk_) keys work server-side;
 * the publishable pk_ key is a common mix-up, so it gets its own message.
 */
export function stripeKeyMode(value: unknown): "test" | "live" {
  if (typeof value !== "string") throw new ApiError(400, "Klistra in din hemliga Stripe-nyckel.");
  const key = value.trim();
  if (/^pk_(test|live)_/.test(key))
    throw new ApiError(
      400,
      "Det där är den publicerbara nyckeln (pk_). Använd den hemliga nyckeln som börjar med sk_test_ eller sk_live_.",
    );
  const match = /^(?:sk|rk)_(test|live)_[A-Za-z0-9]{16,250}$/.exec(key);
  if (!match) throw new ApiError(400, "Nyckeln ska börja med sk_test_ eller sk_live_.");
  return match[1] as "test" | "live";
}

export function webhookSecretValid(value: unknown): string {
  const secret = typeof value === "string" ? value.trim() : "";
  if (!/^whsec_[A-Za-z0-9+/=]{16,250}$/.test(secret))
    throw new ApiError(400, "Webhook-hemligheten ska börja med whsec_.");
  return secret;
}

export function turnstileKeyValid(value: unknown, label: string): string {
  const key = typeof value === "string" ? value.trim() : "";
  if (!/^[0-9A-Za-z_-]{10,120}$/.test(key)) throw new ApiError(400, `Kontrollera ${label}.`);
  return key;
}

/** Last four characters only — enough for an admin to recognise a key, useless to anyone else. */
export const keyHint = (value: string) => `••••${value.slice(-4)}`;

export const uuidPattern =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export function record(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new ApiError(400, "Ogiltig begäran.");
  return value as Record<string, unknown>;
}
export function uuid(value: unknown): string {
  if (typeof value !== "string" || !uuidPattern.test(value))
    throw new ApiError(400, "Ogiltig referens.");
  return value.toLowerCase();
}
export function textField(value: unknown, min: number, max: number): string {
  if (typeof value !== "string") throw new ApiError(400, "Kontrollera uppgifterna i formuläret.");
  const text = value.trim();
  const hasControl = Array.from(text).some(
    (char) => char.charCodeAt(0) < 32 && !["\t", "\n", "\r"].includes(char),
  );
  if (text.length < min || text.length > max || hasControl)
    throw new ApiError(400, "Kontrollera uppgifterna i formuläret.");
  return text;
}
export function emailField(value: unknown): string {
  const email = textField(value, 3, 254).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    throw new ApiError(400, "Ange en giltig e-postadress.");
  return email;
}

export type CheckoutInput = {
  requestId: string;
  items: { productId: string; quantity: number }[];
  customer: { name: string; email: string };
  turnstileToken: unknown;
};

/** The client sends only product IDs and quantities; prices always come from the database. */
export function validateCheckout(value: unknown): CheckoutInput {
  const body = record(value);
  const customer = record(body["customer"]);
  const rawItems = body["items"];
  if (!Array.isArray(rawItems) || rawItems.length < 1 || rawItems.length > 10)
    throw new ApiError(400, "Välj mellan en och tio möbler.");
  const items = rawItems
    .map((value) => {
      const item = record(value);
      const quantity = item["quantity"];
      if (!Number.isInteger(quantity) || Number(quantity) < 1 || Number(quantity) > 10)
        throw new ApiError(400, "Ogiltigt antal.");
      return { productId: uuid(item["productId"]), quantity: Number(quantity) };
    })
    .sort((a, b) => a.productId.localeCompare(b.productId));
  if (new Set(items.map((item) => item.productId)).size !== items.length)
    throw new ApiError(400, "En möbel kan bara förekomma en gång.");
  return {
    requestId: uuid(body["requestId"]),
    items,
    customer: { name: textField(customer["name"], 2, 120), email: emailField(customer["email"]) },
    turnstileToken: body["turnstileToken"],
  };
}

export type ReservedOrder = {
  id: string;
  total: number;
  status: string;
  created_at: string;
  stripe_session_id: string | null;
  customer_email: string;
  items: { product_id: string; name: string; price: number; quantity: number }[];
};
