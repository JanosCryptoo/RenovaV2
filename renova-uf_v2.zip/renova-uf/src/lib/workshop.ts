const W = '/media/workshop';

/** Real footage and photos from the RENOVA UF workshop, supplied by the team. */
export const WORKSHOP = {
  lacquer: { src: `${W}/workshop_lacquer_can.mp4`, poster: `${W}/workshop_lacquer_can_poster.jpg` },
  brushing: { src: `${W}/workshop_brushing_black.mp4`, poster: `${W}/workshop_brushing_black_poster.jpg` },
  pineShelf: `${W}/workshop_pine_shelf.jpg`,
  supplies: `${W}/workshop_supplies.jpg`,
};

export type Supply = { name: string; use: string; x: number; y: number };

/** What is visible in the team's supplies photo; x/y are % positions on that photo. */
export const SUPPLIES: Supply[] = [
  { name: 'Lackfärg', use: 'Ger möbeln en ny, blank yta.', x: 8, y: 56 },
  { name: 'Sealer', use: 'Grundar trä och metall så att färgen fäster.', x: 21, y: 57 },
  { name: 'Målartvätt', use: 'Rengör ytan innan vi målar.', x: 35, y: 42 },
  { name: 'Penslar', use: 'För jämna drag, även i hörn och skarvar.', x: 46, y: 32 },
  { name: 'Sandpapper', use: 'Slipar bort gammal, sliten yta.', x: 38, y: 69 },
  { name: 'Slipklossar', use: 'Ger en jämn slipning på plana ytor.', x: 60, y: 63 },
  { name: 'Nitrilhandskar', use: 'Skyddar händerna när vi arbetar.', x: 91, y: 60 },
];
