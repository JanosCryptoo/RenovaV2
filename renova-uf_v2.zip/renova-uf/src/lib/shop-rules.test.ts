import { describe, expect, it } from 'vitest';
import { checkoutReady, contactReady, validateCheckout, type ShopEnv } from './shop-rules';

const base: ShopEnv = {
  STRIPE_SECRET_KEY: 'sk_test_abc',
  STRIPE_WEBHOOK_SECRET: 'whsec_x',
  ORDER_TOKEN_SECRET: 'x'.repeat(32),
  SITE_URL: undefined,
  CHECKOUT_ENABLED: 'true',
  ALLOW_LIVE_PAYMENTS: 'false',
  STRIPE_ENABLE_SWISH: 'false',
  TURNSTILE_SECRET_KEY: 'secret',
  TURNSTILE_SITE_KEY: 'site',
};
const id = '11111111-1111-4111-8111-111111111111';

describe('activation guards', () => {
  it('keeps the contact form closed without the human check', () => {
    expect(contactReady({ ...base, TURNSTILE_SECRET_KEY: undefined })).toBe(false);
    expect(contactReady(base)).toBe(true);
  });
  it('keeps checkout off until CHECKOUT_ENABLED is exactly "true"', () => {
    expect(checkoutReady({ ...base, CHECKOUT_ENABLED: 'false' })).toBe(false);
    expect(checkoutReady({ ...base, CHECKOUT_ENABLED: undefined })).toBe(false);
    expect(checkoutReady(base)).toBe(true);
  });
  it('requires ALLOW_LIVE_PAYMENTS for live Stripe keys', () => {
    expect(checkoutReady({ ...base, STRIPE_SECRET_KEY: 'sk_live_abc' })).toBe(false);
    expect(
      checkoutReady({ ...base, STRIPE_SECRET_KEY: 'sk_live_abc', ALLOW_LIVE_PAYMENTS: 'true' }),
    ).toBe(true);
  });
  it('requires an order-link secret of at least 32 characters', () => {
    expect(checkoutReady({ ...base, ORDER_TOKEN_SECRET: 'x'.repeat(31) })).toBe(false);
  });
});

describe('checkout input', () => {
  const customer = { name: 'Test Person', email: 'Test@Example.com' };
  it('accepts one to ten distinct items and normalises the email', () => {
    const input = validateCheckout({ requestId: id, items: [{ productId: id, quantity: 1 }], customer });
    expect(input.customer.email).toBe('test@example.com');
  });
  it('rejects duplicates, empty carts and quantities outside 1–10', () => {
    expect(() => validateCheckout({ requestId: id, items: [], customer })).toThrow();
    expect(() =>
      validateCheckout({
        requestId: id,
        items: [
          { productId: id, quantity: 1 },
          { productId: id, quantity: 1 },
        ],
        customer,
      }),
    ).toThrow('en gång');
    expect(() =>
      validateCheckout({ requestId: id, items: [{ productId: id, quantity: 11 }], customer }),
    ).toThrow('antal');
  });
});
