import type { CartItem } from '../types';
export function parseCart(value: string | null): CartItem[] {
  try {
    const data: unknown = JSON.parse(value || '[]');
    if (!Array.isArray(data)) return [];
    const seen = new Set<string>();
    return data
      .filter((item): item is CartItem => {
        if (
          !item ||
          typeof item !== 'object' ||
          typeof item.productId !== 'string' ||
          !/^[a-f0-9-]{36}$/i.test(item.productId) ||
          !Number.isInteger(item.quantity) ||
          item.quantity < 1 ||
          item.quantity > 10 ||
          seen.has(item.productId)
        )
          return false;
        seen.add(item.productId);
        return true;
      })
      .slice(0, 20);
  } catch {
    return [];
  }
}
