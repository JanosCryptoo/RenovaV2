// Server-only helpers for RENOVA UF. Never import from components or routes directly.
import Stripe from "stripe";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { getRequest } from "@tanstack/react-start/server";
import { ApiError, type ShopEnv } from "./shop-rules";

/**
 * Runtime configuration. Values an admin saved on the admin page (encrypted in payment_settings)
 * win over project secrets, so the shop can be connected without touching hosting settings.
 */
export async function readEnv(): Promise<ShopEnv> {
  const env: ShopEnv = {
    STRIPE_SECRET_KEY: process.env["STRIPE_SECRET_KEY"],
    STRIPE_WEBHOOK_SECRET: process.env["STRIPE_WEBHOOK_SECRET"],
    ORDER_TOKEN_SECRET: process.env["ORDER_TOKEN_SECRET"],
    SITE_URL: process.env["SITE_URL"],
    CHECKOUT_ENABLED: process.env["CHECKOUT_ENABLED"],
    ALLOW_LIVE_PAYMENTS: process.env["ALLOW_LIVE_PAYMENTS"],
    STRIPE_ENABLE_SWISH: process.env["STRIPE_ENABLE_SWISH"],
    TURNSTILE_SECRET_KEY: process.env["TURNSTILE_SECRET_KEY"],
    TURNSTILE_SITE_KEY: process.env["TURNSTILE_SITE_KEY"],
  };
  const { loadPaymentSettings, decryptSecret } = await import("./payment-settings.server");
  const row = await loadPaymentSettings();
  if (!row) return env;
  const stripeKey = await decryptSecret(row.stripe_secret_key_enc);
  const webhook = await decryptSecret(row.stripe_webhook_secret_enc);
  const turnstileSecret = await decryptSecret(row.turnstile_secret_key_enc);
  if (stripeKey) env.STRIPE_SECRET_KEY = stripeKey;
  if (webhook) env.STRIPE_WEBHOOK_SECRET = webhook;
  if (turnstileSecret && row.turnstile_site_key) {
    env.TURNSTILE_SECRET_KEY = turnstileSecret;
    env.TURNSTILE_SITE_KEY = row.turnstile_site_key;
  }
  if (row.checkout_enabled) env.CHECKOUT_ENABLED = "true";
  if (row.allow_live_payments) env.ALLOW_LIVE_PAYMENTS = "true";
  if (row.enable_swish) env.STRIPE_ENABLE_SWISH = "true";
  return env;
}

export async function adminDb() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

/** Turns internal failures into safe Swedish messages for the browser. */
export async function guarded<T>(name: string, run: () => Promise<T>): Promise<T> {
  try {
    return await run();
  } catch (error) {
    if (error instanceof ApiError) throw new Error(error.message);
    // Never log bodies, emails, tokens or provider errors that could carry secrets.
    console.error(JSON.stringify({ event: "api_failure", fn: name }));
    throw new Error("Tjänsten kunde inte slutföra begäran. Försök igen senare.");
  }
}

/** Canonical site origin: SITE_URL when set, otherwise the current request's origin. */
export function siteOrigin(env: ShopEnv, request?: Request): string {
  if (env.SITE_URL) {
    try {
      const site = new URL(env.SITE_URL);
      if (site.protocol === "https:" || ["localhost", "127.0.0.1"].includes(site.hostname))
        return site.origin;
    } catch {
      /* fall through */
    }
    throw new ApiError(503, "Tjänsten är inte aktiverad ännu.");
  }
  const req = request ?? getRequest();
  const forwardedHost = req.headers.get("x-forwarded-host");
  const forwardedProto = req.headers.get("x-forwarded-proto");
  const url = new URL(req.url);
  if (forwardedHost) return `${forwardedProto || "https"}://${forwardedHost}`;
  return url.origin;
}

export function stripeClient(env: ShopEnv) {
  if (!env.STRIPE_SECRET_KEY) throw new ApiError(503, "Betalningar är inte aktiverade ännu.");
  return new Stripe(env.STRIPE_SECRET_KEY, {
    httpClient: Stripe.createFetchHttpClient(),
    maxNetworkRetries: 2,
  });
}

export async function verifyHuman(token: unknown, env: ShopEnv) {
  if (
    typeof token !== "string" ||
    token.length < 1 ||
    token.length > 2048 ||
    !env.TURNSTILE_SECRET_KEY
  )
    throw new ApiError(400, "Bekräfta att du är människa och försök igen.");
  const request = getRequest();
  const response = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      secret: env.TURNSTILE_SECRET_KEY,
      response: token,
      remoteip: request.headers.get("CF-Connecting-IP") || undefined,
    }),
  });
  if (!response.ok) throw new ApiError(503, "Verifieringen är tillfälligt otillgänglig.");
  const result = (await response.json()) as { success?: boolean; hostname?: string };
  if (!result.success || result.hostname !== new URL(siteOrigin(env, request)).hostname)
    throw new ApiError(400, "Verifieringen gick ut. Försök igen.");
}

export async function sha256(value: string) {
  return Array.from(
    new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value))),
  )
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("");
}

async function tokenKey(env: ShopEnv) {
  if (!env.ORDER_TOKEN_SECRET || env.ORDER_TOKEN_SECRET.length < 32)
    throw new ApiError(503, "Tjänsten är inte aktiverad ännu.");
  return crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(env.ORDER_TOKEN_SECRET),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"],
  );
}

export async function orderToken(orderId: string, env: ShopEnv) {
  const signature = await crypto.subtle.sign(
    "HMAC",
    await tokenKey(env),
    new TextEncoder().encode(`renova-order:${orderId}`),
  );
  return Array.from(new Uint8Array(signature))
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("");
}

export async function verifyOrderToken(orderId: string, token: unknown, env: ShopEnv) {
  if (typeof token !== "string" || !/^[a-f0-9]{64}$/.test(token))
    throw new ApiError(404, "Beställningen kunde inte hittas.");
  const signature = Uint8Array.from(token.match(/../g)!, (byte) => Number.parseInt(byte, 16));
  const ok = await crypto.subtle.verify(
    "HMAC",
    await tokenKey(env),
    signature,
    new TextEncoder().encode(`renova-order:${orderId}`),
  );
  if (!ok) throw new ApiError(404, "Beställningen kunde inte hittas.");
}

/** Verifies the caller holds the admin role, using their own RLS-scoped client. */
export async function assertAdmin(supabase: SupabaseClient<Database>, userId: string) {
  const { data, error } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
  if (error || data !== true) throw new ApiError(403, "Administratörsbehörighet krävs.");
}
