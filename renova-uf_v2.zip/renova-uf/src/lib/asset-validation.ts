/**
 * Validates uploaded file *contents* (not names or browser MIME hints).
 * Shared by the admin browser UI (early feedback) and the server (authoritative check).
 */
export type AssetKind = 'image' | 'model';
export type ValidatedAsset = { bucket: 'furniture-images' | 'furniture-models'; extension: string; mime: string };

export class AssetError extends Error {}

export const IMAGE_LIMIT = 8 * 1024 * 1024;
export const MODEL_LIMIT = 20 * 1024 * 1024;
const CODECS = ['KHR_draco_mesh_compression', 'EXT_meshopt_compression', 'KHR_texture_basisu'];

export function validateAsset(data: Uint8Array, kind: unknown): ValidatedAsset {
  if (kind === 'image') {
    if (data.length < 1) throw new AssetError('Filen måste vara mellan 1 byte och 8 MB.');
    if (data.length > IMAGE_LIMIT) throw new AssetError('Bilden får vara högst 8 MB.');
    const ascii = (start: number, end: number) => new TextDecoder().decode(data.slice(start, end));
    if (data[0] === 0xff && data[1] === 0xd8 && data[2] === 0xff)
      return { bucket: 'furniture-images', extension: 'jpg', mime: 'image/jpeg' };
    if ([137, 80, 78, 71, 13, 10, 26, 10].every((byte, index) => data[index] === byte))
      return { bucket: 'furniture-images', extension: 'png', mime: 'image/png' };
    if (ascii(0, 4) === 'RIFF' && ascii(8, 12) === 'WEBP')
      return { bucket: 'furniture-images', extension: 'webp', mime: 'image/webp' };
    throw new AssetError('Välj en riktig JPEG-, PNG- eller WebP-bild. SVG stöds inte.');
  }
  if (kind !== 'model' || data.length < 20 || data.length > MODEL_LIMIT)
    throw new AssetError('Välj en GLB-modell på högst 20 MB.');
  const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
  if (
    view.getUint32(0, true) !== 0x46546c67 ||
    view.getUint32(4, true) !== 2 ||
    view.getUint32(8, true) !== data.length ||
    view.getUint32(16, true) !== 0x4e4f534a
  ) {
    throw new AssetError('Filen är inte en giltig GLB 2.0-modell.');
  }
  const jsonLength = view.getUint32(12, true);
  if (jsonLength > 2 * 1024 * 1024 || jsonLength + 20 > data.length)
    throw new AssetError('Modellens beskrivning är ogiltig eller för stor.');
  let model: unknown;
  try {
    model = JSON.parse(
      new TextDecoder('utf-8', { fatal: true })
        .decode(data.slice(20, 20 + jsonLength))
        .replace(/[\0\s]+$/, ''),
    );
  } catch {
    throw new AssetError('Modellens beskrivning kunde inte läsas.');
  }
  // Keep models self-contained: remote textures/buffers could leak or track visitors.
  const queue: unknown[] = [model];
  let checked = 0;
  while (queue.length) {
    const value = queue.pop();
    if (++checked > 100000) throw new AssetError('Modellen är för komplex.');
    if (value && typeof value === 'object') {
      for (const [key, child] of Object.entries(value)) {
        if (CODECS.includes(key) || (typeof child === 'string' && CODECS.includes(child)))
          throw new AssetError(
            'Exportera GLB utan Draco, Meshopt eller KTX2. Använd inbäddade JPEG-/PNG-texturer.',
          );
        if (key.toLowerCase() === 'uri')
          throw new AssetError('Modellen måste innehålla alla material och texturer i samma GLB-fil.');
        if (child && typeof child === 'object') queue.push(child);
      }
    }
  }
  const asset = (model as { asset?: { version?: unknown } } | null)?.asset;
  if (!asset || asset.version !== '2.0') throw new AssetError('Modellen saknar GLTF 2.0-information.');
  return { bucket: 'furniture-models', extension: 'glb', mime: 'model/gltf-binary' };
}
