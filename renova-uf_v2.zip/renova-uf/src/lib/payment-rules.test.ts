import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { checkoutMissing, checkoutReady, keyHint, stripeKeyMode, webhookSecretValid, type ShopEnv } from './shop-rules';
import { decryptSecret, encryptSecret } from './payment-settings.server';

const base: ShopEnv = {
  STRIPE_SECRET_KEY: 'sk_test_' + 'a'.repeat(24),
  STRIPE_WEBHOOK_SECRET: 'whsec_' + 'b'.repeat(24),
  ORDER_TOKEN_SECRET: 'c'.repeat(40),
  SITE_URL: undefined,
  CHECKOUT_ENABLED: 'true',
  ALLOW_LIVE_PAYMENTS: undefined,
  STRIPE_ENABLE_SWISH: undefined,
  TURNSTILE_SECRET_KEY: '0x4AAAAAAAAAAAAAAAAAAAAAAA',
  TURNSTILE_SITE_KEY: '0x4BBBBBBBBBBBBBBBBBBB',
};

describe('Stripe key entered on the admin page', () => {
  it('accepts test and live secret keys', () => {
    expect(stripeKeyMode('sk_test_' + 'x'.repeat(30))).toBe('test');
    expect(stripeKeyMode('  sk_live_' + 'x'.repeat(30) + ' ')).toBe('live');
  });
  it('rejects the publishable key with a specific message', () => {
    expect(() => stripeKeyMode('pk_test_' + 'x'.repeat(30))).toThrow(/publicerbara/);
  });
  it('rejects anything else', () => {
    expect(() => stripeKeyMode('hello')).toThrow(/sk_test_/);
  });
  it('webhook secret must start with whsec_', () => {
    expect(webhookSecretValid(' whsec_' + 'y'.repeat(30))).toBe('whsec_' + 'y'.repeat(30));
    expect(() => webhookSecretValid('sk_test_' + 'y'.repeat(30))).toThrow(/whsec_/);
  });
  it('shows only the last four characters', () => {
    expect(keyHint('sk_test_abcdefgh1234')).toBe('••••1234');
  });
});

describe('checkout readiness', () => {
  it('opens with a test key once everything is connected', () => {
    expect(checkoutReady(base)).toBe(true);
    expect(checkoutMissing(base)).toEqual([]);
  });
  it('a live key needs explicit approval for real payments', () => {
    const live = { ...base, STRIPE_SECRET_KEY: 'sk_live_' + 'a'.repeat(24) };
    expect(checkoutReady(live)).toBe(false);
    expect(checkoutMissing(live)).toContain('Godkännande av riktiga betalningar');
    expect(checkoutReady({ ...live, ALLOW_LIVE_PAYMENTS: 'true' })).toBe(true);
  });
  it('stays closed without a webhook secret or spam protection', () => {
    expect(checkoutMissing({ ...base, STRIPE_WEBHOOK_SECRET: undefined })).toEqual(['Stripe webhook-hemlighet']);
    expect(checkoutMissing({ ...base, TURNSTILE_SECRET_KEY: undefined })).toEqual(['Spamskydd (Turnstile)']);
  });
});

describe('stored keys are encrypted', () => {
  let previous: string | undefined;
  beforeEach(() => {
    previous = process.env['PAYMENT_SETTINGS_KEY'];
    process.env['PAYMENT_SETTINGS_KEY'] = 'k'.repeat(64);
  });
  afterEach(() => {
    if (previous === undefined) delete process.env['PAYMENT_SETTINGS_KEY'];
    else process.env['PAYMENT_SETTINGS_KEY'] = previous;
  });
  it('round-trips without storing the plain key', async () => {
    const key = 'sk_test_' + 'z'.repeat(30);
    const stored = await encryptSecret(key);
    expect(stored).not.toContain(key);
    expect(await decryptSecret(stored)).toBe(key);
  });
  it('tampered ciphertext reads as not connected', async () => {
    const stored = await encryptSecret('sk_test_' + 'z'.repeat(30));
    expect(await decryptSecret(stored.slice(0, -4) + 'AAAA')).toBeUndefined();
  });
});
