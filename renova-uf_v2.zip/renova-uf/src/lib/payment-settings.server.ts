// Server-only. Encrypts payment credentials an admin enters on the admin page.
// AES-GCM with a key derived from the PAYMENT_SETTINGS_KEY project secret; the database only
// ever holds ciphertext, and the table has no browser grants at all.
import type { Database } from "@/integrations/supabase/types";

export type PaymentSettingsRow = Database["public"]["Tables"]["payment_settings"]["Row"];

let cachedKey: Promise<CryptoKey> | null = null;
function encryptionKey(): Promise<CryptoKey> {
  const secret = process.env["PAYMENT_SETTINGS_KEY"];
  if (!secret || secret.length < 32) throw new Error("PAYMENT_SETTINGS_KEY missing");
  cachedKey ??= crypto.subtle
    .digest("SHA-256", new TextEncoder().encode(`renova-payment-settings:${secret}`))
    .then((raw) => crypto.subtle.importKey("raw", raw, "AES-GCM", false, ["encrypt", "decrypt"]));
  return cachedKey;
}

const toBase64 = (bytes: Uint8Array) => btoa(String.fromCharCode(...bytes));
const fromBase64 = (text: string) => Uint8Array.from(atob(text), (c) => c.charCodeAt(0));

export async function encryptSecret(plain: string): Promise<string> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const cipher = new Uint8Array(
    await crypto.subtle.encrypt(
      { name: "AES-GCM", iv },
      await encryptionKey(),
      new TextEncoder().encode(plain),
    ),
  );
  const packed = new Uint8Array(iv.length + cipher.length);
  packed.set(iv);
  packed.set(cipher, iv.length);
  return `v1:${toBase64(packed)}`;
}

export async function decryptSecret(value: string | null | undefined): Promise<string | undefined> {
  if (!value?.startsWith("v1:")) return undefined;
  try {
    const packed = fromBase64(value.slice(3));
    const plain = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: packed.slice(0, 12) },
      await encryptionKey(),
      packed.slice(12),
    );
    return new TextDecoder().decode(plain);
  } catch {
    // A rotated PAYMENT_SETTINGS_KEY makes old ciphertext unreadable: treat it as "not connected".
    console.error(JSON.stringify({ event: "payment_settings_decrypt_failed" }));
    return undefined;
  }
}

export async function loadPaymentSettings(): Promise<PaymentSettingsRow | null> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("payment_settings")
    .select("*")
    .eq("id", 1)
    .maybeSingle();
  if (error) {
    console.error(JSON.stringify({ event: "payment_settings_read_failed" }));
    return null;
  }
  return data;
}
